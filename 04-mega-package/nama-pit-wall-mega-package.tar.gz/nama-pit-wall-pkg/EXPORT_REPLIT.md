# Export to Replit

Optimized for one-click clone + run in Replit.

## Step 1 — Create the Repl

1. Go to **replit.com → Create Repl → Import from upload**
2. Upload the entire `nama-pit-wall-pkg/` folder as a zip
3. Choose template: **Node.js** (Replit will detect the Vite project)

## Step 2 — Set the run command

Replit auto-detects Vite, but verify the `.replit` file (if not present, create it):

```toml
run = "cd src && npm install && npm run dev"
entrypoint = "src/index.html"

[nix]
channel = "stable-24_05"

[deployment]
build = ["sh", "-c", "cd src && npm install && npm run build"]
run = ["sh", "-c", "cd src && npx serve dist -l 5173"]

[[ports]]
localPort = 5173
externalPort = 80
```

## Step 3 — Run

Hit the **Run** button. Replit will:

1. Run `npm install` in `src/`
2. Start the Vite dev server
3. Open the webview at port 5173

You should see the Pit Wall load with the five-seat picker, telemetry strip, D3 forecast fan, and surface ring.

## Step 4 — Use the AI Agent feature

If your Repl has Replit AI enabled, paste this prompt into the agent panel:

```
This is the NAMA Pit Wall — a co-working forecasting platform.
Read README.md, ARCHITECTURE.md, PRD.md, and DESIGN_SPEC.md for full context.

Your job: extend the v2.4 scaffold to add the v3.0 delighters per ROADMAP.md:
1. Second-Opinion Agent (PRD FR-16)
2. Ghost Lap (PRD FR-17)
3. Championship Table (PRD FR-18)

Use the OpenAPI spec at docs/api/openapi.yaml as the API contract.
Use the schema at docs/schema/schema.sql as the data model.
Follow the design tokens in brand/tokens.css.
Honor the operating principle: agents do toil, humans do judgment.

Start with the Second-Opinion Agent panel — extend PitWall.tsx so the
analyst seat can invoke a second opinion on the current forecast set and
see the MDS, divergent factors, and routing recommendation.
```

## Tips

- **Database:** Replit has built-in Postgres via the **Database** sidebar. Run `docs/schema/schema.sql` to seed the v2.4 baseline (6 users, 5 reason codes, 1 forecast set, 7 agents).
- **Secrets:** Replit **Secrets** for any API keys (LLM provider keys for v3.0 Second-Opinion implementation).
- **Deployment:** Replit Deployments → Static for the demo; Autoscale for a full-stack version once you add a backend.
- **Custom domain:** Replit supports custom domains on deployed Repls.

## What works out of the box

- React + Vite + TypeScript dev server
- D3 quantile fan chart
- Five-seat persona swap
- Telemetry strip reframe per seat
- Surface ring reordering
- Activity feed filtering
- Race flow simulation
- Agent Studio (lean version)

## What you'll need to extend

- Real backend (the scaffold is frontend-only with mock data)
- Real LLM agent integrations (OpenAI / Anthropic / Litellm)
- Real authentication (currently no auth)
- Real HIBT writes (currently console.log only)

See `ARCHITECTURE.md` § Layer B for the service split.
