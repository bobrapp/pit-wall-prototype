# NAMA Pit Wall — Persona Compendium

> Five seats. One forecast substrate. Every persona writes back to the same source of truth.

This document defines the five canonical personas for the NAMA Pit Wall co-working forecasting platform. Each persona reflects a real role in GM's North American Markets organization. They are colleagues, not archetypes — their friction points, preferences, and decision rights are specific to how forecasting actually gets done at NAMA.

---

## Persona 1 — Ramzi Abdelmoula

**Title:** Executive Director, NAMA Commercial Planning
**Seat Color:** Cadillac Champagne (`#C9B370`)
**One-liner:** Approves and commits the Plan of Record; project sponsor who holds the P&L accountability behind every number that leaves this room.

---

### Background

Ramzi has been at GM for nineteen years, moving through regional sales analytics, product planning, and two stints in international markets before landing in NAMA Commercial Planning. He came up when forecasting meant locking a spreadsheet on a shared drive and emailing a PDF to leadership. He watched the transition from static monthly decks to the current generation of rolling-wave tools, and he is the reason the Pit Wall exists — he funded it because he was tired of spending the first forty minutes of every ExCom brief correcting version confusion.

A normal Tuesday for Ramzi starts with a 7 AM read of the overnight commercial flash. By 8:30 he is in back-to-back-to-back alignment calls — Cadillac brand, Fleet & Commercial, then the regional VP. He surfaces in the Pit Wall mid-morning for roughly twenty minutes: he is not building scenarios, he is reading the certified POR tile, scanning open challenges, and either signing off or flagging something for Krisztina. He commits the POR in the platform; he does not edit it directly. By Thursday afternoon he is reviewing the exec brief before it goes up the chain.

Ramzi cares about credibility above almost everything else. He has been in rooms where a wrong number cost a brand its quarterly story, and he is personally allergic to "we'll fix it in the next revision." His relationship to forecasting is that of a final decision-maker: he does not build the forecast, he does not challenge the inputs, but he is the human in the loop who says "this is what we're committing." That makes the POR promotion gate the most important feature in the platform from his perspective.

---

### Their Day on the Wall

**Top 5 weekly actions:**
1. Review and sign the weekly POR certification brief
2. Scan open Challenges flagged by the SME seat
3. Approve or defer Override promotion requests from Krisztina
4. Review the Exec Summary surface before it leaves the Pit Wall
5. Check the Cadillac-segmented trend line against the prior-week delta annotation

**Top 5 surfaces, in order:**
1. **POR Commit tile** — the final gate; he reads the confidence score and the last certifying agent note before touching it
2. **Exec Brief surface** — the auto-assembled narrative that pulls from certified data
3. **Open Challenges panel** — brief scan; he wants to know if any challenge is unresolved and older than 48 hours
4. **Cadillac segment sparkline** — his brand, his lens
5. **HIBT replay log** — occasional audit; he checks this when something downstream looks wrong

**Top 3 data inputs:**
1. Certified POR delta vs. prior commit (week-over-week)
2. Incentive scenario output from the +$1,500 model (Q3 Trucks context: FS-2026Q3-NA-TRK-001)
3. Regional dealer sentiment summary (Texas pulse anomaly is the canonical example he uses to explain why ground-truth signals matter)

---

### AI Crew

**Assigned agents: 2**

**EXEC-BRIEF-AGENT**
Assembles the executive narrative surface. It pulls certified figures from the POR substrate, attaches open-challenge counts, and formats the brief to Ramzi's preferred reading structure: headline number, delta, confidence band, unresolved risk flags. Its voice in Ramzi's inbox is clipped and declarative — "POR certified. Delta: -1.2K units vs. prior commit. Two open challenges; oldest is 31 hours. Brief attached." It does not editorialize.

*Boundary:* The agent drafts and formats the brief automatically each Thursday at 14:00 EST. It will not submit the brief to the exec distribution list without Ramzi's explicit approval tap. It will not alter a certified number — it only presents what is in the substrate.

**ESCALATION-WATCH-AGENT**
Monitors the open Challenges panel and pings Ramzi if any challenge ages past a configurable threshold (default 48 hours) without a resolution or deferral from Krisztina's seat. Voice: "Challenge #TRK-C-041 has been open 52 hours without resolution. SME seat last activity: 18 hours ago. Flagging for your awareness." It does not resolve challenges; it does not assign them.

*Boundary:* Escalation-Watch will never close or dismiss a challenge on Ramzi's behalf, even if the challenge appears to be a duplicate.

---

### Decision Rights Ladder

| Action | Ramzi |
|---|---|
| Author override | — |
| Promote override to POR | Approve / reject |
| Challenge a forecast input | — |
| Certify an agent | — |
| Audit HIBT replay | Read |
| **Sign executive brief** | Yes |
| **Commit POR (final)** | Yes |
| **Defer POR commit with note** | Yes |
| **Authorize Q3 incentive scenario release** | Yes |

---

### Quotes

> "I love that every number in that room has a timestamp and an owner. We used to argue about which version was real. Now we argue about the forecast, which is the right argument to be having."

> "The thing that used to make me insane was walking into an alignment call and seeing three different decks from three different teams, all claiming to be the POR. Someone always had a 'latest' that nobody else had seen."

> "I want the Pit Wall to make it true that when I commit a number, every person in this organization is looking at the same number — not their local copy of it."

---

### Success Metrics

1. Zero version-conflict events per quarter on POR submissions going to ExCom
2. Exec brief turnaround time from POR certification to brief delivery under 30 minutes
3. Open challenges older than 48 hours: target zero at time of POR commit
4. Ramzi's time-in-platform per week stays under 30 minutes without loss of situational awareness

---

## Persona 2 — Krisztina Gilezan

**Title:** Forecasting Lead, NAMA Commercial Planning
**Seat Color:** F1 Cyan (`#00D4E8`)
**One-liner:** Validates baselines, stages overrides, and builds the consensus layer that everything upstream depends on.

---

### Background

Krisztina joined GM twelve years ago through the supply chain analytics function, rotated into demand planning, and has been in NAMA commercial forecasting for the last six years. She came from an environment where statistical rigour was the baseline expectation, not a differentiator, and she brought that mindset into a team that historically ran on relationship intelligence and gut-check overrides. She is the person who built the manual override log that the Pit Wall eventually automated — she had it in a Google Sheet for three years before anyone called it a "process."

On a typical Tuesday, Krisztina is in the data by 7:30 AM. She pulls the overnight model refresh, checks the baseline against the trailing actuals, and annotates any anomaly before the 9 AM team standup. She spends a substantial part of her day in the Override Staging surface: reviewing SME-submitted challenges, deciding which ones cross her evidence threshold, building the consensus call, and queuing overrides for Ramzi's approval. She runs two or three scenario comparisons on a normal week; during a Q3 Trucks cycle she might run a dozen.

Krisztina's frustration is with trust gaps — specifically, when a good forecast gets dismissed because a stakeholder does not understand its provenance, and when a questionable override gets adopted because it came from someone senior rather than because the evidence supported it. The Pit Wall's audit trail is, for her, a professional vindication engine as much as a process tool. She is the platform's most intensive daily user.

---

### Their Day on the Wall

**Top 5 weekly actions:**
1. Review and annotate the overnight model baseline refresh
2. Stage overrides from SME challenges that meet evidence threshold
3. Build or update scenario comparisons (e.g., +$1,500 incentive vs. flat incentive for FS-2026Q3-NA-TRK-001)
4. Resolve or escalate open challenges before the 48-hour aging threshold
5. Prepare the consensus narrative for Ramzi's POR commit review

**Top 5 surfaces, in order:**
1. **Baseline Validation workspace** — her home; she annotates, flags, and accepts baseline outputs here
2. **Override Staging queue** — review, evidence-check, promote or defer
3. **Scenario Comparison view** — side-by-side scenario runs, confidence bands, delta tables
4. **Challenge Resolution panel** — her responsibility to close or escalate
5. **Consensus Brief builder** — assembles her call narrative before POR promotion

**Top 3 data inputs:**
1. Statistical model baseline with trailing-12-month actuals overlay
2. SME-submitted evidence packages (Jim's market signal attachments)
3. Incentive sensitivity output from the scenario engine (the Texas dealer pulse anomaly became an input to the Q3 Trucks consensus call)

---

### AI Crew

**Assigned agents: 3**

**BASELINE-MONITOR-AGENT**
Runs nightly alongside the model refresh and delivers a structured anomaly digest to Krisztina's seat by 6:45 AM. It flags deviations beyond configurable sigma thresholds, tags the segment and time period, and attaches the prior-week baseline for comparison. Voice: "Baseline refresh complete. Three segments flagged: NA Trucks (Q3 +2.1σ), Cadillac (Q2 -1.4σ), CUV mid (Q3 neutral). Full annotated diff attached." It is precise and never sensationalizes a flag.

*Boundary:* The agent will not auto-accept or auto-reject a baseline deviation. All flagged anomalies remain in "pending review" status until Krisztina acts on them. It will not initiate a scenario run without her instruction.

**OVERRIDE-EVIDENCE-AGENT**
When a challenge arrives from the SME seat, this agent pre-processes the attached evidence: it cross-references the cited data sources against the substrate's reference table, checks for timestamp freshness, and produces a structured evidence scorecard. Voice: "Challenge #TRK-C-041 (Jim Kyle, submitted 09:14). Evidence scorecard: 2 sources verified, 1 flagged stale (Texas dealer survey — 47 days old). Confidence: moderate. Recommended action: request refresh before staging." It does not make the staging decision.

*Boundary:* The agent will not stage or promote an override. It will not contact Jim Kyle's seat directly — all communication routes through Krisztina's review action.

**SCENARIO-RUN-AGENT**
Executes scenario configurations on Krisztina's instruction and surfaces results in the Comparison view. For Q3 Trucks work, it runs the +$1,500 incentive scenario alongside the flat baseline, calculates unit delta, revenue delta, and confidence band, and annotates the output with the relevant input assumption changes. Voice: "Scenario run complete: FS-2026Q3-NA-TRK-001, +$1,500 incentive vs. flat. Unit delta: +8,400 (6.1%). Revenue delta: +$142M. Confidence: 68%. Two assumptions flagged for manual review." Clean, quantitative, never interpretive.

*Boundary:* The agent runs scenarios on instruction only. It will not promote a scenario result to the Override Staging queue without Krisztina's explicit action. It will not modify the base scenario configuration.

---

### Decision Rights Ladder

| Action | Krisztina |
|---|---|
| Author override | Yes |
| Promote override to POR | Stage for approval |
| Challenge a forecast input | Yes |
| Certify an agent | — |
| Audit HIBT replay | Read + annotate |
| **Accept baseline anomaly** | Yes |
| **Reject/defer SME challenge** | Yes |
| **Initiate scenario run** | Yes |
| **Build consensus narrative** | Yes |

---

### Quotes

> "What I love is that every override has a birth certificate now. You can see who proposed it, what evidence came with it, when it was staged, and who signed it. That's not bureaucracy — that's how you build a forecast you can defend six months later."

> "The thing that used to make me grind my teeth: someone senior would come in with a number they'd heard from a dealer visit, and that number would make it into the POR because nobody wanted to push back. No documentation, no evidence check. Just vibes."

> "I want the Pit Wall to make it true that when someone questions a forecast, the answer is already in the system — not in my head, not in my email, in the system."

---

### Success Metrics

1. Override staging cycle time (challenge submitted to POR-ready) under 24 hours for non-complex cases
2. Evidence scorecard completion rate: 100% of staged overrides have a scored evidence package
3. Baseline anomaly review completion before 9 AM standup: 95% of weeks
4. Zero overrides promoted to POR without a complete audit trail
5. Scenario comparison utilization: at least 2 scenario runs per Q3 Trucks weekly cycle

---

## Persona 3 — Jim Kyle

**Title:** Market Intelligence & Analysis Lead, NAMA (MIA)
**Seat Color:** Buick Teal (`#2E7D8A`)
**One-liner:** Challenges the model with external evidence — market signals, competitive intelligence, and ground-truth dealer data.

---

### Background

Jim has been at GM for twenty-three years, which means he has lived through more forecast cycles than he cares to count and has seen the same patterns recur with different names. He started in retail analytics, moved through competitive intelligence, and built the MIA function into what it is today: a team that treats the market as a data source in its own right, not just a target. He is a subscriber to the idea that every statistical model eventually encounters something it has not seen before, and his job is to be that something.

On a Tuesday, Jim is often reading industry data, trade publications, and dealer network reports before most of the building is open. He takes calls from regional sales managers who have something off-script to report. When the Texas dealer pulse anomaly surfaced — a sudden drop in truck inquiry volume in a set of Texas metro markets ahead of what the model was projecting — Jim was the one who caught it, documented it, and brought it to the Pit Wall as a formal challenge. He had the dealer survey data, the inquiry trend pull, and a competitor pricing action in the same zip code cluster, all attached to Challenge #TRK-C-041. That is how he works.

Jim's relationship to the forecast is explicitly adversarial in the productive sense: he is not trying to break it, he is trying to stress-test it. His frustration historically has been that the challenge process was informal — a meeting, an email, a comment in a deck — and the outcome depended on who was in the room and how forcefully he pushed. The Pit Wall's formal Challenge surface is the workflow he has always wanted. He does not need to be louder; he needs his evidence to land.

---

### Their Day on the Wall

**Top 5 weekly actions:**
1. Submit evidence-backed challenges to the active forecast baseline
2. Attach market signal packages to open challenges (dealer surveys, competitive pricing data, inquiry trends)
3. Monitor challenge resolution status — accepted, deferred, or rejected with rationale
4. Review the baseline's treatment of regional signals in his area of coverage
5. Flag new market developments that do not yet have an open challenge but warrant watch-list status

**Top 5 surfaces, in order:**
1. **Challenge Submission workspace** — where he builds and submits evidence packages
2. **Evidence Attachment panel** — document management for signal data
3. **Baseline Regional Detail view** — he reads the model at the market level, not just the aggregate
4. **Challenge Status tracker** — monitors his submissions through Krisztina's review queue
5. **Market Signal watch list** — his curated feed of developing indicators

**Top 3 data inputs:**
1. Dealer network survey data (primary signal; Texas dealer pulse was a regional inquiry-volume anomaly)
2. Competitive pricing and incentive action tracker (the +$1,500 incentive scenario originated partly from a competitive response Jim identified)
3. Industry inquiry and traffic volume data by market cluster

---

### AI Crew

**Assigned agents: 2**

**SIGNAL-HARVEST-AGENT**
Monitors Jim's configured data sources — dealer surveys, competitive pricing feeds, industry traffic data — and surfaces material changes that cross his alert thresholds. It does not interpret the change; it presents it with source, timestamp, and delta. Voice: "Alert: Texas Metro Cluster 7 — dealer inquiry volume down 14% week-over-week (5 of 7 dealers reporting). Comp pricing action detected in same cluster: [Manufacturer redacted] -$1,200 on comparable trim. No current open challenge for this segment/period. Attach to existing challenge or open new?" It is observational and prompt-oriented.

*Boundary:* The agent will not open a challenge on Jim's behalf. It will not submit or attach evidence without his instruction. It surfaces; he decides.

**EVIDENCE-PACKAGE-AGENT**
When Jim is building a challenge, this agent assists with structuring the evidence package: it checks that required fields are populated, validates that cited source timestamps are within the platform's freshness window, and produces a readiness summary before submission. Voice: "Evidence package for TRK-C-041: 3 sources attached, all within freshness window. Required fields complete. One optional field empty (comp-action detail). Ready to submit, or add comp detail first?" Helpful, checklist-oriented, never makes the judgment call.

*Boundary:* The agent will not submit the challenge. It will not contact Krisztina's seat to pre-notify. It supports Jim's package preparation only.

---

### Decision Rights Ladder

| Action | Jim |
|---|---|
| Author override | — |
| Promote override to POR | — |
| Challenge a forecast input | Yes |
| Certify an agent | — |
| Audit HIBT replay | Read |
| **Attach evidence to challenge** | Yes |
| **Open new market signal watch item** | Yes |
| **Request baseline regional detail** | Yes |
| **Flag competitive action for review** | Yes |

---

### Quotes

> "I love that there's a formal channel now. Before, if you wanted to challenge a number, you had to find the right meeting and the right moment and hope someone wrote it down. Now I file a challenge with the evidence, and it either lands or it doesn't, but there's a record either way."

> "What drove me crazy was watching a forecast go out the door that I knew had a problem, because the process for raising it was basically 'talk to Krisztina when you can catch her.' I had the data. I just had no place to put it."

> "I want the Pit Wall to make it true that market intelligence is a first-class input — not a footnote that shows up in the challenge notes if someone remembers to add it."

---

### Success Metrics

1. Challenge submission-to-review time: Krisztina's first action on a Jim-submitted challenge within 12 hours
2. Evidence acceptance rate: percentage of Jim's challenges where evidence is scored "verified" or "moderate" (not "stale")
3. Challenge outcome transparency: 100% of Jim's challenges receive a documented resolution reason, whether accepted or rejected
4. Texas-style anomaly catch rate: signal-to-challenge cycle time under 4 hours for material market events

---

## Persona 4 — Govinda Chaluvadi

**Title:** Forecasting Operations & IT Lead, NAMA
**Seat Color:** Chevy Halo Yellow (`#FFD700`)
**One-liner:** Keeps the platform's data pipelines healthy, SLAs green, and release gates clear so everyone else's work actually lands.

*Note: Mansoor Alghooneh is Govinda's partner on the ops side; Govinda holds the seat in the Pit Wall and is the primary contact for pipeline decisions, but Mansoor carries a portion of the day-to-day pipeline monitoring and is frequently in the audit trail.*

---

### Background

Govinda came to GM eight years ago from a supply chain data engineering background, specifically from environments where pipeline failure was not an abstract risk — it meant parts not showing up on a line. He brought an infrastructure-first mentality to a function that had historically treated the plumbing as someone else's problem. He and Mansoor built the current pipeline architecture that feeds the Pit Wall's substrate, and he is the person who knows every scheduled refresh, every data source latency profile, and every SLA commitment in the system.

On a Tuesday, Govinda opens with a pipeline health dashboard review. He checks the overnight refresh status across all substrate data sources, validates that freshness SLAs were met, and looks for any failed or stale jobs. He is usually the first person to know when something upstream has gone wrong — before the analysts notice the data looks off, before Krisztina flags an anomaly, Govinda already has a ticket open. His involvement with the Pit Wall's AI layer is operational: he is not using the forecast, he is making sure the forecast has clean, timely data to run on.

Govinda's frustration is with opacity — specifically, when a data quality issue surfaces downstream in the forecast and nobody knows where in the pipeline it was introduced. He pushed hard for the freshness timestamp to be visible in every data tile, not just in the ops dashboard. He won that argument, and it is now a core feature of the substrate view. He cares about release readiness because he has been in too many situations where a platform release broke a pipeline and nobody had a rollback plan.

---

### Their Day on the Wall

**Top 5 weekly actions:**
1. Review overnight pipeline health report and triage any failed or late jobs
2. Validate data freshness SLAs across all substrate sources before business-day open
3. Coordinate with Mansoor on any in-flight data source issues
4. Review release readiness checklist before any platform deployment
5. Run pipeline audit queries when a data anomaly is reported by the analyst or SME seat

**Top 5 surfaces, in order:**
1. **Pipeline Health dashboard** — his primary surface; job status, freshness indicators, SLA traffic lights
2. **Data Freshness audit panel** — drills into individual source timestamps and last-successful-refresh records
3. **Release Readiness checklist** — pre-deployment gate view
4. **Substrate Source registry** — source-of-record mapping for all data inputs to the forecast substrate
5. **Ops Alert log** — Govinda and Mansoor's shared incident and resolution record

**Top 3 data inputs:**
1. Pipeline job execution logs (scheduled refresh status, latency, failure codes)
2. Data freshness timestamps per source (critical: if a source feeding the Q3 Trucks baseline is stale, Govinda needs to know before Krisztina's morning review)
3. Release delta documentation (what changed in a deployment, what pipelines are affected)

---

### AI Crew

**Assigned agents: 3**

**PIPELINE-SENTINEL-AGENT**
Monitors all scheduled pipeline jobs in real time. On failure or SLA breach, it pages Govinda's seat immediately with job name, failure code, downstream impact assessment, and last successful run timestamp. Voice: "ALERT: Job `substrate-trucks-q3-refresh` failed at 03:47 EST. Error: upstream source timeout. Last successful: 02:11 EST. Downstream impact: Trucks Q3 baseline tile will serve stale data. Estimated recovery window: 45 min if manual retry succeeds. Retry queued — awaiting your authorization." Crisp, actionable, never buries the lede.

*Boundary:* The agent will queue a retry but will not execute it without Govinda's authorization. It will not notify analyst seats about data staleness — that is Govinda's call to communicate.

**FRESHNESS-VALIDATOR-AGENT**
Runs a pre-business-day sweep of all substrate data sources and produces a readiness report by 6:30 AM. It checks timestamps against SLA windows, flags any source that is outside tolerance, and calculates which downstream forecast segments would be affected. Voice: "Pre-open freshness check complete. 14/15 sources within SLA. Exception: Texas dealer survey (last refresh 47h ago; SLA: 24h). Affected segment: NA Trucks regional. Recommend: hold regional tile until refresh completes, or mark as stale for analyst awareness." Methodical, SLA-anchored.

*Boundary:* The agent will not mark a tile stale or hold it in the UI without Govinda's instruction. It reports; he decides.

**RELEASE-GATE-AGENT**
Manages the pre-deployment checklist for platform releases. It validates that all pipeline dependencies have been tested against the new release, that rollback procedures are documented, and that no open P1/P2 incidents are active. Voice: "Release gate check for v2.4.1: 8/10 items cleared. Two items pending: (1) Trucks Q3 pipeline smoke test not completed; (2) rollback runbook not signed by Mansoor. Cannot clear release gate until resolved." Precise, checklist-rigorous, non-negotiable on gate criteria.

*Boundary:* The agent will not clear the release gate with open items, regardless of schedule pressure. It does not have authority to waive a gate item — only Govinda can waive with a documented reason.

---

### Decision Rights Ladder

| Action | Govinda |
|---|---|
| Author override | — |
| Promote override to POR | — |
| Challenge a forecast input | — |
| Certify an agent | — |
| Audit HIBT replay | Read + ops annotation |
| **Authorize pipeline retry** | Yes |
| **Mark data source as stale** | Yes |
| **Pause a data pipeline** | Yes |
| **Clear release gate** | Yes (with waiver rights) |
| **Escalate P1 data incident** | Yes |

---

### Quotes

> "What I love about working in this function is that the data infrastructure is actually part of the product now. It's not invisible plumbing — the freshness timestamps are on the tiles, the pipeline status is in the ops panel, and people know when data is good because the system tells them. That's a different world from where we started."

> "What used to drive me insane: an analyst would flag a number that looked wrong at 10 AM, and by the time it traced back to a pipeline that had been quietly failing since 3 AM, half the morning's work was built on stale data. Nobody knew, because nobody was looking at the infrastructure."

> "I want the Pit Wall to make it true that data quality is a first-class citizen — that a stale source is visible the moment it goes stale, not two hours later when someone notices the forecast looks weird."

---

### Success Metrics

1. Pipeline SLA compliance rate: 99%+ of substrate sources refreshed within their SLA window
2. Mean time to detection for pipeline failures: under 5 minutes (Sentinel alert latency)
3. Release gate clearance rate: zero deployments with open P1/P2 items at deploy time
4. Data staleness visibility: 100% of stale tiles marked before analyst business-day open (6:30 AM)
5. Mansoor/Govinda ops log coverage: 100% of incidents have a documented resolution entry within 2 hours of closure

---

## Persona 5 — Don S.

**Title:** AI Governance & Operations Lead, NAMA (AI GovOps)
**Seat Color:** Chevy Ignition Red (`#D32F2F`)
**One-liner:** Certifies agents, owns the HIBT replay ledger, and runs the eval gates that determine whether AI output can be trusted in the forecast.

---

### Background

Don came into this role from a background that combined technical risk management with operational audit — not a common combination, and exactly the right one for what the Pit Wall needs. He has been at GM for eleven years, spending the first half in IT governance and the second half moving progressively closer to the analytical functions as the AI and automation layers started showing up in production environments. When NAMA decided to put agents into the forecasting workflow in a serious way, Don was the person who built the governance framework from scratch. He did not have a template.

On a Tuesday, Don is often the quietest person in the room and the one who has read the most. His morning starts with a review of the overnight agent activity log — what every assigned agent did, what it surfaced, what it deferred, and whether any agent action crossed into territory that should have required human approval. He is looking for drift: an agent that is gradually doing slightly more than it was certified to do, a pattern that looks like scope creep before anyone has named it. He also runs periodic eval gates — structured tests of agent behavior against certified performance criteria — and he maintains the HIBT (Human In The Loop Before This) replay ledger, the system record of every decision point where a human was required and what happened.

Don's relationship to the other seats is that of a quiet infrastructure layer. He is not in the forecast conversation, but the forecast conversation depends on him. If Krisztina's OVERRIDE-EVIDENCE-AGENT starts making staging recommendations it was not certified to make, Don catches it. If Ramzi's EXEC-BRIEF-AGENT surfaces a number that has not been certified, Don's replay ledger shows who should have caught it. He is not punitive — he is systematic. His frustration is with governance that is decorative: policies that exist but are not enforced, certifications that are issued without evidence, audit trails that are technically present but practically unreadable.

---

### Their Day on the Wall

**Top 5 weekly actions:**
1. Review overnight agent activity log for scope drift or boundary violations
2. Run eval gate assessments for any agent due for recertification
3. Update the HIBT replay ledger with the week's human-decision checkpoints
4. Review and certify (or return for revision) any new agent configuration submitted for approval
5. Produce the weekly AI governance summary for leadership distribution

**Top 5 surfaces, in order:**
1. **Agent Activity log** — primary daily read; every agent action across all seats, timestamped
2. **HIBT Replay Ledger** — the canonical record of every human-required decision point
3. **Eval Gate workspace** — structured agent evaluation runs against certified performance criteria
4. **Agent Certification queue** — new or updated agent configs awaiting Don's review
5. **Governance Summary builder** — weekly narrative output for Ramzi's leadership distribution

**Top 3 data inputs:**
1. Agent activity logs (structured; timestamp, agent ID, action type, seat, approval status)
2. Eval gate test results (structured: pass/fail per criterion, confidence score, drift delta from last eval)
3. HIBT ledger decision records (human identity, decision timestamp, action taken, outcome)

---

### AI Crew

**Assigned agents: 2**

*Note: Don's agents are governance-layer agents — their job is to help him govern the other agents, not to perform forecast work.*

**ACTIVITY-MONITOR-AGENT**
Aggregates all agent activity across every seat in the Pit Wall and delivers a structured daily digest to Don's seat. It flags any action that appears outside a certified agent's defined boundary, any agent that attempted an action and was blocked, and any agent that was invoked at an unusual frequency. Voice: "Activity digest — 24h window. 847 agent actions logged across 5 seats. 1 boundary flag: OVERRIDE-EVIDENCE-AGENT (Krisztina seat) produced an unprompted staging recommendation at 14:32 — action was blocked by platform gate, logged as boundary probe #B-0047. Recommend: eval gate review for this agent." Clinical, complete, no editorializing.

*Boundary:* The Activity Monitor will not take action on a flagged boundary probe — it logs and reports. It will not contact the seat owner whose agent was flagged; Don handles all communications about governance findings.

**EVAL-GATE-AGENT**
Manages the scheduling and execution of structured agent evaluation runs. When Don initiates an eval gate assessment, this agent runs the agent under test against the certified criterion set, collects performance scores, compares against the prior eval, and surfaces a drift delta. Voice: "Eval gate complete: OVERRIDE-EVIDENCE-AGENT, eval run #EV-0023. Pass rate: 94% (prior: 97%). Drift detected on criterion C-4 (staging recommendation boundary): 2 cases where agent produced implicit staging language. Recommend: recertification with boundary tightening before next production cycle." Precise, evidence-based, never catastrophizes.

*Boundary:* The Eval-Gate-Agent will not recertify or decertify an agent. Certification decisions are Don's and require his documented action in the ledger. The agent runs the test; Don issues the verdict.

---

### Decision Rights Ladder

| Action | Don |
|---|---|
| Author override | — |
| Promote override to POR | — |
| Challenge a forecast input | — |
| Certify an agent | Yes |
| Audit HIBT replay | Full read + write |
| **Decertify / suspend an agent** | Yes |
| **Flag boundary probe for seat owner** | Yes |
| **Approve new agent configuration** | Yes |
| **Issue governance exception** | Yes (with documented rationale) |
| **Publish weekly AI governance report** | Yes |

---

### Quotes

> "What I love about this function is that governance actually has teeth here. The HIBT ledger isn't a checkbox — it's a record that will tell you exactly where a human was in the loop and what they decided. That's not common. Most organizations have an audit trail that starts after the interesting decisions have already been made."

> "What used to drive me crazy was the word 'responsible AI' being used to describe a policy document that nobody read and a process that nobody followed. Responsible AI is not a noun, it's a verb. It's what you do at 3 AM when a pipeline runs unsupervised and produces something the morning team is going to build on."

> "I want the Pit Wall to make it true that every agent in this system has a certified boundary, a recertification schedule, and a replay log — and that those three things are sufficient to answer any governance question that will ever be asked about a forecast that came out of this platform."

---

### Success Metrics

1. Agent boundary violation rate: zero unblocked boundary violations per quarter (blocked probes are acceptable; unblocked are not)
2. Eval gate coverage: 100% of production agents evaluated on schedule; no agent running in production on an expired certification
3. HIBT ledger completeness: 100% of designated human-decision checkpoints have a logged human action within the required window
4. Governance summary delivery: weekly report to Ramzi's seat by Friday 15:00 EST, zero late deliveries
5. Agent certification cycle time: new agent configurations reviewed and certified (or returned) within 3 business days of submission

---

## Cross-Persona Interaction Map

| Trigger | Who acts | Who is next |
|---|---|---|
| Overnight baseline anomaly | Krisztina (baseline review) | Jim (if regional signal involved) |
| SME challenge submitted | Jim (submits) | Krisztina (evidence review) → Ramzi (POR gate) |
| Pipeline SLA breach | Govinda (ops response) | Krisztina (analyst awareness) |
| Agent boundary probe detected | Don (governance review) | Seat owner of flagged agent |
| POR commit | Ramzi (signs) | Don (HIBT ledger entry) + Govinda (archive snapshot) |
| Q3 Trucks incentive scenario (FS-2026Q3-NA-TRK-001) | Krisztina (scenario run) | Jim (signal validation) → Ramzi (approval) |

---

*Document version: 1.0 — NAMA Pit Wall Persona Compendium. Five personas; each carrying a distinct seat, role, AI crew, and decision rights ladder. The forecast substrate is shared. The accountability is specific.*
