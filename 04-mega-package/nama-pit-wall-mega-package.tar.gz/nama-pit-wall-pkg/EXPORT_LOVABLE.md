# Export to Lovable

Lovable builds full-stack apps from natural language. Best results come from a clean PRD + design system + canonical sample data. This package is engineered to be Lovable-ready.

## Step 1 — Open a new Lovable project

Go to **lovable.dev → New Project**.

## Step 2 — Paste the bootstrap prompt

Copy the entire block below into the Lovable prompt box. This gives Lovable everything it needs in one shot.

````
Build the **NAMA Pit Wall** — a co-working forecasting platform for GM's North American Markets organization. This is a v2.4 scaffold with v3.0 delighters planned.

## Vision

One trusted forecast substrate. Five persona seats. Eight surfaces. Seven NAMA-certified AI agents. Two operating clocks (15-minute urgent race + monthly S&OP cycle). HIBT replay-prompt-ledger for full audit lineage.

**Operating principle:** Agents do the rework, the research, the toil. Humans do the judgment, the dissent, the commit.

## Tech stack

React + Vite + TypeScript. D3 v7 for the quantile fan chart. Plain CSS with design tokens (no Tailwind). Mock data on the frontend; backend deferred.

## Design system

GM consumer-brand cinematic + Formula 1 race-control energy.

```css
--void: #06080d;           /* page bg */
--carbon: #0e1119;
--pit: #171b27;
--ink: #f5f6f8;
--muted: #8a8f9e;

/* GM brand accents */
--chevy-red: #da1a2e;
--chevy-yellow: #ffc72c;
--cad-champagne: #c8b273;
--buick-teal: #7fb0bf;

/* F1 race-control palette */
--f1-amber: #ff6b00;
--f1-cyan: #00e5ff;
--start-green: #00d26a;

/* Seat-color bindings */
--seat-leadership: var(--cad-champagne);
--seat-analyst: var(--f1-cyan);
--seat-sme: var(--buick-teal);
--seat-ops: var(--chevy-yellow);
--seat-govops: var(--chevy-red);
```

Typography: Fraunces (variable serif) for headlines, Inter for body, JetBrains Mono for telemetry. Load via Google Fonts.

Cinematic dark substrate. Editorial typography. NO glowing particles, NO neon orbs, NO circuit-board textures. Real automotive photography preferred over AI-generated.

## Layout

1. **Topbar** — NAMA mark + brand name + brand sub-line ("Agentic Ensemble · v2.4")
2. **Race-control telemetry strip** — sticky 9 KPI cells, reframes per seat
3. **Seat picker** — 5 cards: Leadership / Analyst / SME / Ops / GovOps. Active seat highlighted in its accent color. Click swaps the workspace.
4. **The Pit Wall workbench** — 2-column grid. Left: Number Object hero (312,400 units U.S. Full-Size Trucks Q3 2026) + D3 quantile fan chart (P10/P50/P90 band + champagne consensus dashed line + yellow YTD actuals) + 3 scenario compare buttons (Base / +$1,500 incentive / Tariff shock). Right: seat-specific action panel (override / approval / challenge / pipeline / promote) + decision-rights ladder (✓ granted / ✕ denied).
5. **Surface ring** — 8 tiles (Outlook, Teams, Excel, SharePoint, Power BI, Glean, Workbench, Agent Studio). Each shows the same Number Object in its native idiom. Tile order shifts per seat to elevate that persona's primary surfaces.
6. **Activity feed** — 7 cross-surface events. Filtered per seat.
7. **15-minute race flow** — 5 pit stops (Signal / Agent prep / Review / Commit / Release) with race clock and Run/Reset controls. Active stop highlighted with race-amber top border.
8. **Agent Studio** — 3 panels: 7-agent roster · message-bus placeholder · 4-card human-in-loop work queue.

## Sample data

**Canonical forecast set:** FS-2026Q3-NA-TRK-001 · U.S. Full-Size Trucks · Q3 2026 · 312,400 units · P10 287.6k / P90 338.9k · confidence 0.71 · owner Krisztina Gilezan.

**Three scenarios:**
- Base: 312.4k
- +$1,500 incentive: 324.8k (recommended)
- Tariff shock: 289.1k

**People:**
- Ramzi Abdelmoula (Leadership)
- Krisztina Gilezan (Analyst)
- Jim Kyle (SME / MIA)
- Govinda Chaluvadi (Ops)
- Don S. (GovOps)
- Bob Rapp (Architect)

**7 NAMA-certified agents** — workbench-anomaly v3.5, personal-assistant v4.1, glean-copilot v2.7, intake-agent v1.9, narrative-drafter v2.3, guardrail-classifier v1.4, avista-agent v3.2.

## Build sequence

1. Set up the design tokens (tokens.css) and Google Fonts
2. Build the Topbar + Telemetry strip
3. Build the SeatPicker — make sure clicking a seat changes the body's data-persona attribute and the --accent CSS variable
4. Build the Pit Wall workbench with D3 quantile fan
5. Build the SurfaceRing with seat-aware reordering
6. Build the ActivityFeed with seat-aware filtering
7. Build the RaceFlow with simulated race clock
8. Build the AgentStudio with the 3 panels
9. Test all 5 seats — make sure each swap actually reframes the workspace

## What "done" looks like

When a user clicks any of the 5 seats:
- Accent color across the page changes
- Telemetry strip rebuilds with role-specific KPIs
- Action panel in the Pit Wall swaps (override / approval / challenge / pipeline / promote)
- Surface ring reorders to elevate that persona's primary tiles
- Activity feed filters to events visible to that seat
- Decision-rights ladder shows what that seat can and cannot do

Persist seat choice in localStorage.

## Stretch goal (after v2.4 ships)

Add the v3.0 delighters: Second-Opinion Agent, Ghost Lap, Championship Table. Specs in the PRD.

Start with the topbar and design tokens, then iterate seat-by-seat.
````

## Step 3 — Iterate

Lovable's strength is conversational iteration. After the first build, paste these follow-ups one at a time:

1. "Make the Telemetry strip persona-aware — different 9 KPIs per seat."
2. "Make clicking a seat actually swap the action panel content, not just the color."
3. "Add the 15-minute race with a Run button that animates the baton through the 5 pit stops."
4. "Add the v3.0 Second-Opinion Agent as a 6th seat-action variant."

## Tips for Lovable

- **One concept per message.** Lovable does better with focused asks than mega-prompts after the initial bootstrap.
- **Reference the design tokens explicitly** — e.g., "use --f1-amber for the active pit stop top border."
- **Use the sample data** — Lovable does much better when it has the canonical 312,400 / Silverado HD / Q3 Trucks numbers to render against.
- **When stuck, paste a code excerpt** from `src/components/` as a reference shape.

## What's in this package you can reference

- `PRD.md` § 4 (Solution shape) for the 5-layer structure
- `DESIGN_SPEC.md` § 6 (Component patterns) for visual specs
- `src/components/*.tsx` for working React reference implementations
- `brand/tokens.css` for the exact color tokens
- `docs/api/openapi.yaml` if you want Lovable to scaffold backend endpoints
