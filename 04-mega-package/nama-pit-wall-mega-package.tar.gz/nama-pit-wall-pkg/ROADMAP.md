# NAMA Pit Wall — Roadmap

**Updated:** 2026-05-12 · **Owner:** Bob Rapp

## Three horizons

| Horizon | Version | Window | Status |
|---------|---------|--------|--------|
| Now | **v2.4** | Shipped May 2026 | ✅ live |
| Next 90 days | **v3.0** | Q3 2026 build · GA week 7 | 🟡 PRD ratified, eng spec stub published |
| 6 months | **v3.5** | Q4 2026 / Q1 2027 | ⚪ vision only |

---

## v2.4 — what shipped (May 2026)

| Capability | Status |
|-----------|--------|
| 5 persona seats with role-aware decision rights | ✅ |
| 8 surfaces wired (Outlook, Teams, Excel, SharePoint, PBI, Glean, Workbench, Agent Studio) | ✅ |
| 7 NAMA-certified production agents | ✅ |
| 15-minute urgent race with baton-pass + pit-to-driver radio | ✅ |
| Monthly S&OP cycle with 3 state gates | ✅ |
| Forecast Workbench with D3 quantile fan + scenario compare + structured override | ✅ |
| HIBT replay-prompt-ledger v2.0 (in flight — 70% complete) | 🟡 |
| Race-control telemetry strip with persona-aware KPIs | ✅ |
| NAMA-certified agent gate (5-category eval) | ✅ |

---

## v3.0 — the delighters (next 90 days)

### Features

1. **Second-Opinion Agent** (16 ew, GA week 7) — adversarial-by-design review with divergent prompt pack; Material Disagreement Score; auto-trigger at Gate 3 for forecast sets ≥ $50M; structured-challenge routing to SME.
2. **Ghost Lap** (11 ew, GA week 6) — temporal overlay of prior cycle on current chart; recurring-challenge classifier; override-outcome trail; Gate-2 auto-diff report.
3. **Championship Table** (7 ew, GA week 5) — 4 leagues (Override Value-Add, Challenge Precision, Agent Improvement, Mentorship); monthly micros + quarterly Grand Prix; lap-clap recognition; anti-gaming guardrails.
4. **Constraint Twin** (4 ew, GA week 7) — supplier/plant constraint links surface in scenario compare alongside volume.

### Cross-cutting infra

- HIBT v2.0 finalization (3 ew remaining)
- Decision-Rights API extensions (2 ew)
- Feature flag service hardening (1 ew, 60s kill-switch SLA)
- Adversarial probe corpus (1 ew)
- Cost-budget enforcer per-seat extensions (1 ew)

### 7-week phased rollout

| Week | Phase |
|------|-------|
| 1–2 | Cross-cutting infra + 3 features P1 in parallel |
| 3 | First eval-gate review (all 3 P1 completions) |
| 4 | Championship Table P2 canary (lowest stakes first) |
| 5 | Championship Table GA · Ghost Lap P2 canary |
| 6 | Ghost Lap GA · Second-Opinion P2 canary |
| 7 | Second-Opinion GA · all features at 100% |
| 8–12 | Tune + calibrate phase (P5) |

### Staffing gap

42 ew demand vs. 35 ew capacity = **7 ew shortfall, concentrated in ML engineering**.

**Recommended fix:** Hire 1 dedicated ML engineer for v3.0+. Annualized $180k, within $2.4M v3.0 budget. Permanent capacity for v3.5 strategic-horizon ML.

### Funding

| Bucket | $ |
|--------|---|
| Second-Opinion Agent (most complex; biggest compute) | $0.9M |
| Ghost Lap | $0.6M |
| Championship Table | $0.4M |
| Cross-cutting infra | $0.5M |
| **Total** | **$2.4M** |

---

## v3.5 — strategic horizon (6 months out)

**Theme:** From operational to strategic. The Pit Wall expands from monthly S&OP into 3-5 year scenario planning, gets a global presence, and starts contributing back to upstream plant systems.

| Capability | Why |
|-----------|-----|
| Strategic scenario planning (3-5 year horizon) | Connect short-term forecasting to capital allocation and product roadmap |
| Auto-S&OP pre-read (agent-drafted) | Reduce sponsor prep time by 60%, surface insights earlier |
| External signal marketplace | Bring third-party signals (Glassdoor, Edmunds, IHS) into the substrate with NAMA-certified intake |
| Cross-region pit wall (NAMA + Europe + China) | Same operating model in global planning organizations; respect data residency |
| Plan-of-record API for plant systems | Bidirectional integration with plant planning — POR commit flows downstream |
| User-configurable prompt packs (advanced) | Power users can request bear / bull / bottom-up framing for Second-Opinion |

**Cost estimate:** $4.5M v3.5 build (not yet committed; subject to v3.0 success + sponsor signoff).

---

## Decision dates

| Decision | Date | Owner |
|----------|------|-------|
| v3.0 PRD ratification | 2026-05-26 | Ramzi |
| ML engineer hire approval | 2026-05-26 | Ramzi |
| v3.0 GA signoff | 2026-08-12 (end of week 7) | Ramzi + Bob + Don |
| Championship Table cultural review | 2026-07-15 (pre-launch) | Ramzi |
| v3.5 scope ratification | 2026-11-15 | Ramzi (post v3.0 retro) |

---

## Tracking

Weekly status posted in Slack `#nama-pit-wall-status`. Phase-transition gates require GovOps signoff (Don S.). Sponsor brief monthly. NAMA exec brief at v3.0 GA.

*See `EXEC_SUMMARY.md` for the funding ask details, `PRD.md` for v3.0 functional requirements, and `docs/adr/` for the architectural decisions that drive what's in/out of scope per horizon.*
