# Export to Claude Code

Claude Code is best at structured codebases with clear documentation. This package is engineered for that.

## Step 1 — Initialize the project

```bash
cd nama-pit-wall-pkg
claude  # starts Claude Code in this directory
```

## Step 2 — Open with the canonical brief

Paste this in your first message:

````
You are joining the NAMA Pit Wall project.

Read these first, in this order:
1. README.md (top-level overview)
2. EXEC_SUMMARY.md (1-page summary)
3. ARCHITECTURE.md (4-layer technical stack)
4. PRD.md (full requirements, especially § 5 functional reqs)
5. DESIGN_SPEC.md (brand + UX system)
6. docs/adr/ (5 architecture decision records)

Once you've read those, briefly summarize back to me:
- The 4 operating principles
- The 4 layers of the stack
- The 5 personas with their primary surfaces
- The 3 v3.0 delighter features
- The locked decisions you'll honor (from ADRs)

Then I'll give you a task.
````

This primes Claude Code with the entire project context before any work starts. Claude will read the docs and respond with a structured summary. You're then aligned.

## Step 3 — Common task openings

### Task A: Implement Second-Opinion Agent

```
Implement the Second-Opinion Agent service per:
- PRD.md § FR-16
- docs/adr/ADR-004-nama-certified-agent-gate.md
- The Second-Opinion design doc (referenced in ARCHITECTURE.md)

The service goes in a new directory `src/services/second-opinion-svc/`.
Use the OpenAPI spec at docs/api/openapi.yaml as the contract.
Use the schema at docs/schema/schema.sql for the data model.
Honor the locked decisions:
- Dedicated service, not config variant
- Different LLM provider for second opinion than primary
- MDS ≥ 0.3 raises a challenge
- Per-seat daily cost cap $4.00
- ≥98% replay determinism
- Never block the primary forecasting path

Start with the service skeleton (FastAPI), then the MDS calculator,
then the SME router. Write tests as you go.
```

### Task B: Wire up the existing scaffold to a real backend

```
The existing scaffold in src/ is frontend-only with mock data.
I want a real backend.

Build the Layer C Access API as a Node + Express service in src-backend/.
Use the OpenAPI spec at docs/api/openapi.yaml as the contract.
Use Postgres with the schema at docs/schema/schema.sql.
Wire the frontend's mock data to real API calls.
Add JWT auth with scope-based decision-rights enforcement.
Add a basic admin route for HIBT ledger inspection.

Run the schema migration first, then build the API, then update the
frontend. Generate types from the OpenAPI spec.
```

### Task C: Add a new persona seat

```
I want to add a 6th persona seat: "Plant Planner."

Make all the changes consistent with the existing 5-seat pattern:
- Add to SeatId type in src/types/index.ts
- Add config to SEATS in src/data/mockActivity.ts
- Add TELEMETRY entries
- Add ACTIVITY visibility
- Add SurfaceRing primaryTiles
- Update PitWall.tsx SeatActionPanel with the plant-planner variant
- Update RightsLadder with the right scopes
- Add a brand color to tokens.css
- Update docs/adr/ADR-002-five-seat-persona-model.md with the change (note: this ADR may need to be superseded; create ADR-006 if so)

Don't change the existing 5 seats. Don't change the API contract unless
necessary. If you change the schema, write a migration file.
```

## Step 4 — How to give Claude Code maximum context

Claude Code does extremely well when you point it at specific files. Use these patterns:

- **"Read X, then do Y"** — explicit reading anchors
- **"Honor the locked decisions in ADRs"** — protects against drift
- **"Match the pattern of [existing file]"** — propagates conventions
- **"Generate types from the OpenAPI"** — uses the spec as source of truth
- **"Write tests as you go"** — keeps quality high

## Step 5 — Recommended .clauderc

Drop this at the repo root if you want Claude Code to load with specific defaults:

```
{
  "context_priority_files": [
    "README.md",
    "ARCHITECTURE.md",
    "PRD.md",
    "DESIGN_SPEC.md",
    "docs/adr/ADR-001-one-trusted-substrate.md",
    "docs/adr/ADR-003-hibt-replay-ledger.md",
    "docs/adr/ADR-004-nama-certified-agent-gate.md"
  ],
  "always_honor": "The 6 locked decisions in Second-Opinion design doc, and the operating principle: agents do toil, humans do judgment."
}
```

## What you get from Claude Code

- Multi-file refactors that respect the project conventions
- Type generation from the OpenAPI spec
- ADR-aware decisions (won't violate locked architecture)
- Honest summaries of what changed
- Test scaffolding alongside implementation
- Runbook updates when behavior changes

## What works best

- One feature per task. Don't ask for "build v3.0" — break it into Second-Opinion → Ghost Lap → Championship.
- Reference specific FRs (e.g., "implement PRD FR-16") so the requirement is precise.
- Lean on the ADRs as guardrails. When Claude wants to deviate, ask for a new ADR.

## What to do before each session ends

```
Update the relevant docs:
- README if new files were added at top-level
- ARCHITECTURE if a new service was introduced
- ADRs if any architectural decision was made or superseded
- Per-feature design doc if scope changed
- HIBT_LOG.md with what was built this session
```

Claude Code is good at this if you remind it.
