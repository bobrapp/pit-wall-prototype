# NAMA Pit Wall — Architecture

**Version:** 2.4
**Date:** 2026-05-12
**Owner:** Bob Rapp (architect) · Mansoor Alghooneh (backend) · Govinda Chaluvadi (API/data)

This is the canonical architecture document. Read alongside the ADRs in `docs/adr/` for the decision-context behind each choice.

---

## 1. Operating principles

Four principles that govern every architectural choice. If a proposed change violates one of these, it requires sponsor signoff to land.

1. **One trusted substrate.** All forecast data writes go through one Layer A substrate (Databricks + Unity Catalog). No shadow spreadsheets, no parallel ledgers. Every surface reads/writes via the Layer C Access API.
2. **Persona keeps the surface, system keeps the truth.** Each persona uses the tool they prefer (Outlook, Teams, Excel, etc.). The substrate doesn't care which surface; the surface doesn't get to create a parallel truth.
3. **Replay or it didn't happen.** Every meaningful action (prompt, tool call, override, approval) is logged immutably in HIBT with full reproducibility. ≥98% replay determinism is a non-functional requirement.
4. **Agents magnify; humans commit.** Agents do rework, research, freshness checks, draft narratives, classify anomalies. Humans do override, challenge, commit. The Pit Wall enforces this at the API.

---

## 2. The four-layer stack

```
┌────────────────────────────────────────────────────────────────┐
│  LAYER D · PERSONA SURFACES                                    │
│                                                                │
│   Outlook · Teams/Slack · Excel · SharePoint                   │
│   Power BI · Glean · Forecast Workbench · Agent Studio + HIBT  │
└─────────────────────┬──────────────────────────────────────────┘
                      │  HTTP + WebSocket via Layer C API
                      ▼
┌────────────────────────────────────────────────────────────────┐
│  LAYER C · ACCESS API + EVENTS                                 │
│                                                                │
│   Planning Access API (OpenAPI 3.1)                            │
│   Event bus (AsyncAPI; anomaly · stale-state · challenge ·     │
│   approval · drift · plan-promoted)                            │
│   Role-aware decision rights enforced at edge                  │
└─────────────────────┬──────────────────────────────────────────┘
                      │
                      ▼
┌────────────────────────────────────────────────────────────────┐
│  LAYER B · PROCESS ENGINE                                      │
│                                                                │
│   State machines (number, scenario, forecast-set)              │
│   Trust scoring · approval routing · challenge workflows       │
│   AI agents:                                                   │
│     workbench-anomaly · pa-agent · glean-copilot ·             │
│     intake-agent · narrative-drafter · guardrail-classifier ·  │
│     avista-agent · (v3.0) second-opinion-svc · ghost-lap-svc · │
│     champ-svc                                                  │
└─────────────────────┬──────────────────────────────────────────┘
                      │
                      ▼
┌────────────────────────────────────────────────────────────────┐
│  LAYER A · PLANNING FABRIC                                     │
│                                                                │
│   Databricks Lakehouse + Unity Catalog                         │
│   Forecast Sets · Number Objects · Scenarios · Constraints     │
│   Overrides · Challenges · Approvals · Trust metadata          │
└─────────────────────┬──────────────────────────────────────────┘
                      │
                      ▼
┌────────────────────────────────────────────────────────────────┐
│  HIBT REPLAY-PROMPT-LEDGER v2.0  (cross-layer audit substrate) │
│                                                                │
│   Every prompt, tool call, override, approval, score           │
│   24+ months immutable history                                 │
│   Replay-by-action-id · drift-by-version · score-by-source     │
└────────────────────────────────────────────────────────────────┘
```

### Layer A — Planning Fabric

**Store:** Databricks Lakehouse (production). Postgres 15+ (dev / test / pilot).

**Core entities:**

- `forecast_sets` — a planning artifact with horizon, scenario, model version, data snapshot, owner, state, plan-of-record flag
- `number_objects` — a forecasted quantity tied to a forecast set, with P10/P50/P90 quantiles, confidence, owner, freshness
- `scenarios` — named assumption sets, compare-able, promotable, archivable
- `constraint_links` — supplier/plant/inventory/policy impacts on a number object
- `overrides` — structured user intervention with reason code + evidence
- `challenges` — structured dissent with reason code + evidence
- `approvals` — owner promotion of a scenario to plan-of-record
- `users` · `reason_codes` · `agents` (taxonomy + identity)

**State machine on number_object:**

```
   draft  ──→  updated  ──→  challenged  ──→  committed  ──→  final  ──→  reviewed
                  │              │                │
                  └──────────────┴────────────────┘
                  (transitions emit events on bus)
```

Full DDL in `docs/schema/schema.sql`.

### Layer B — Process Engine

State machines (per `number_object`, per `scenario`, per `forecast_set`) live here, along with:

- **Trust scoring** — per-number confidence band, drift detector, recurring-challenge classifier
- **Approval routing** — decision-rights graph; who can approve what under which conditions
- **Challenge workflows** — adversarial-but-positive review with reason codes
- **Agent orchestration** — each NAMA-certified agent runs as a stateless service that reads/writes through Layer C

**The 7 production agents:**

| Agent | Version | Seat served | Owner of toil |
|-------|---------|-------------|---------------|
| `workbench-anomaly` | v3.5 | Analyst | Drift detection, anomaly flagging |
| `personal-assistant` | v4.1 | Analyst | File comparison, validation, prep |
| `glean-copilot` | v2.7 | SME · Leadership | Deterministic forecast Q&A |
| `intake-agent` | v1.9 | SME | SharePoint tagging, evidence routing |
| `narrative-drafter` | v2.3 | Leadership | Exec brief drafting |
| `guardrail-classifier` | v1.4 | Ops | Stale-state pause, pipeline guard |
| `avista-agent` | v3.2 | SME | Dealer-pulse + cross-shop signals |

**The v3.0 additions:**

| Agent | Service | Seat served | Effort |
|-------|---------|-------------|--------|
| `second-opinion-svc` | dedicated service, Litellm + Redis | All (gates Gate 3) | 16 ew |
| `ghost-lap-svc` | service + nightly Databricks job | Analyst, Leadership | 11 ew |
| `champ-svc` | service + nightly scorer | All (read-mostly) | 7 ew |

### Layer C — Access API + Events

**The anti-fragmentation layer.** Every surface speaks through this single API. No surface gets to write directly to Layer A.

**Endpoints (v2.4 baseline + v3.0 additions):**

- `GET /forecasts/:id` · `GET /forecasts/:id/numbers` · `GET /forecasts/:id/replay`
- `POST /forecasts/:id/overrides` · `POST /forecasts/:id/challenges` · `POST /forecasts/:id/approvals`
- `GET /agents` · `GET /agents/:id/promotions`
- (v3.0) `POST /forecasts/:id/second-opinion` · `GET /forecasts/:id/ghost-lap` · `GET /championship/:season`

Full OpenAPI spec: `docs/api/openapi.yaml`.

**Event bus (AsyncAPI):**

- `anomaly.detected`
- `stale-state.alert`
- `challenge.raised`
- `approval.committed`
- `drift.detected`
- `plan.promoted`
- `second-opinion.raised` (v3.0)
- `ghost-issue.detected` (v3.0)
- `championship.season-closed` (v3.0)

**Decision rights** enforced at the API edge via JWT scopes:

- `forecast.read` · `override.author` · `challenge.raise` · `approval.commit`
- `agent.certify` · `audit.read` · `second-opinion.invoke`

Per-persona scope sets are bound at user provisioning.

### Layer D — Persona Surfaces

Eight surfaces. Each is a thin client of Layer C. No surface holds state beyond what's needed to render.

| Surface | Primary persona | Native idiom |
|---------|----------------|--------------|
| Outlook | Leadership | Email brief + adaptive cards |
| Teams / Slack | SME · Leadership | Adaptive cards with action buttons |
| Excel add-in | Analyst | Workbook slice, staging-only writes |
| SharePoint | SME (evidence) | Document drop, intake-agent tags it |
| Power BI | Leadership · Analyst | Tile + drill |
| Glean | All | Deterministic Q&A |
| Forecast Workbench | Analyst (primary cockpit) | D3 quantile fan, compare mode, override form |
| Agent Studio + HIBT | GovOps | Replay-ledger, promotion queue, eval board |

Each surface gets its own deployment package (Outlook add-in, Teams app, Excel add-in manifest, etc.). All speak Layer C.

### HIBT replay-prompt-ledger v2.0 — cross-layer audit substrate

Not a layer per se. Lives orthogonally to all four layers. Every meaningful action writes an entry.

**Entry shape:**

```ts
{
  id: string;                  // uuid v7
  actor: string;               // user_id OR agent_id@version
  surface: SurfaceId;          // outlook | teams | excel | ...
  action_type: ActionType;     // override | challenge | approval | prompt | ...
  payload: object;             // domain-specific
  prompt_sha: string | null;   // for agent actions: SHA of prompt template
  source_sha: string | null;   // for agent actions: SHA of source data snapshot
  model_version: string | null;// for agent actions
  reproducibility_hash: string; // hash that allows replay-from-source
  outcome: 'success' | 'failure' | 'dismissed' | 'routed';
  parent_entry_id: string | null; // for action chains
  created_at: TimestampTZ;
}
```

**SLO:** Write within 5s (p95). Replay-determinism ≥ 98% on random sample.

---

## 3. The two operating clocks

### Clock 1 — 15-minute urgent race

Used for high-urgency forecast events (market shock, exec request, anomaly threshold breach).

Five pit stops, one baton:

```
Min 0–2   Min 2–5   Min 5–9   Min 9–12   Min 12–15
SIGNAL  → PREP    → REVIEW  → COMMIT   → RELEASE
 Ops     Analyst   SME       Leadership GovOps
```

State transitions trigger pit-to-driver radio hand-offs (Teams adaptive card with "✓ Completed / → Next" summary).

### Clock 2 — Monthly S&OP cycle

The recurring rhythm. Three state gates:

```
Gate 1: ANALYST-READY    Gate 2: CHALLENGE-READY    Gate 3: PLAN-OF-RECORD
─ baseline run complete   ─ consensus draft built     ─ leadership commits
─ anomaly pack staged     ─ challenge window open     ─ all surfaces inherit
─ freshness validated     ─ evidence routed           ─ HIBT final + immutable
```

Six lanes (data / analysts / SMEs / leadership / ops / govops) traverse the three gates over ~3 weeks.

Both clocks share the same substrate; different gates fire, same Number Object touched.

---

## 4. Trust + decision rights model

| Action | Leadership | Analyst | SME | Ops | GovOps |
|--------|:----------:|:-------:|:---:|:---:|:------:|
| Read forecasts | ✓ | ✓ | ✓ | ✓ | ✓ |
| Author override | ✕ | ✓ | ✕ | ✕ | ✕ |
| Stage scenario | ✕ | ✓ | ✕ | ✕ | ✕ |
| Raise challenge | ✕ | ✓ (respond) | ✓ | ✕ | ✓ |
| Promote POR | ✓ | ✕ | ✕ | ✕ | ✕ |
| Sign exec brief | ✓ | ✕ | ✕ | ✕ | ✕ |
| Pause / retry pipeline | ✕ | ✕ | ✕ | ✓ | ✓ |
| Promote agent version | ✕ | ✕ | ✕ | ✕ | ✓ |
| Rollback agent | ✕ | ✕ | ✕ | ✕ | ✓ |
| Audit replay-ledger | ✓ (view) | ✓ (view) | ✓ (own scope) | ✓ (ops scope) | ✓ (full) |

Decision rights enforced at the Layer C API via scope checks. No persona surface can elevate privilege beyond their bound scopes.

---

## 5. NAMA-certified agent gate

Every agent that ships to a production NAMA surface passes five eval categories before promotion. GovOps (Don S.) owns the gate.

| Gate category | What it checks | Threshold |
|---------------|----------------|-----------|
| **Correctness** | Golden-set precision + recall | ≥ 85% / ≥ 80% |
| **Calibration** | Predicted scores vs. realized outcomes | R² ≥ 0.7 |
| **Adversarial robustness** | Designed-to-fool probes | ≥ 90% correct |
| **Performance + cost** | p95 latency + p95 cost | Spec-defined per agent |
| **Replay determinism** | Replay-from-source match | ≥ 98% |

Promotion = canary (24h) → expanded canary (1 week) → GA. Kill-switch via feature flag with 60s SLA at every phase.

See `docs/adr/ADR-004-nama-certified-agent-gate.md` for the decision context.

---

## 6. Non-functional requirements

| NFR | Target | Measurement |
|-----|--------|-------------|
| Surface consistency SLA | 2.4s p95 single-value | All surfaces show the same number within window |
| API availability | 99.9% (monthly) | Layer C uptime |
| Replay determinism | ≥ 98% | Weekly random replay sample |
| Cost per persona per month | ≤ $400 (v3.0) | LLM + compute + storage |
| Per-seat daily budget | $4.00 (Second-Opinion alone) | Enforced at agent layer |
| Eval gate cadence | Every PR + nightly | Run via CI |
| Drift watch cadence | Weekly | GovOps owns 4 drift watches |
| Feature flag kill-switch | 60s | Tested quarterly |
| HIBT retention | 24+ months full lineage | Older compressed |

---

## 7. Security, governance, compliance

- **SOX-relevant.** Forecast accuracy and plan-of-record commits affect revenue recognition. All state changes auditable via HIBT.
- **AI governance.** Every agent action logged; replay-from-source allows reconstruction. Agent eval gates enforce safety/calibration before production.
- **Data residency.** US-only for NAMA. Adjacent regions (Europe, China) deployed separately under their data-residency requirements.
- **PII.** Forecast data is commercial, not personal. User IDs are corporate identity. No external PII enters the system.
- **Decision rights.** Enforced at API edge; no privilege escalation possible from a surface.
- **Kill-switches.** Per-feature feature flags can disable any v3.0 capability within 60s if incident.

---

## 8. Performance + scale

- **Active users:** ~80 seats at v2.4 (NAMA), ~250 at full Europe + China expansion (v3.5)
- **Peak concurrency:** ~50 concurrent users during Gate 3 commit windows
- **Daily Layer C requests:** ~12,000 reads, ~1,800 writes
- **HIBT entries per day:** ~3,500 (agent actions + user actions)
- **Storage growth:** ~80 MB/cycle for ghost-lap projections; HIBT ~1 GB/month full lineage

Architecture sized for 5x current load without rearchitecture.

---

## 9. Deployment topology

```
                  ┌─────────────────────────────────────┐
                  │   Layer D · client deployments      │
                  │   ─ Outlook add-in (manifest)       │
                  │   ─ Teams app (manifest)            │
                  │   ─ Excel add-in (manifest)         │
                  │   ─ Workbench (React SPA → S3+CF)   │
                  │   ─ Agent Studio (React SPA)        │
                  └────────────────┬────────────────────┘
                                   │ TLS to api.pitwall.nama
                                   ▼
                  ┌─────────────────────────────────────┐
                  │   Layer C · API gateway             │
                  │   ─ AWS API Gateway / Azure APIM    │
                  │   ─ JWT validation + scope check    │
                  │   ─ Rate limiting + observability   │
                  └────────────────┬────────────────────┘
                                   │
                  ┌────────────────┴────────────────┐
                  ▼                                 ▼
        ┌──────────────────┐             ┌──────────────────┐
        │ Layer B services │             │ Event bus        │
        │ (Kubernetes)     │             │ (Kafka / EventBridge)
        │ ─ pitwall-api    │             │                  │
        │ ─ workbench-…    │             │                  │
        │ ─ second-opinion │             │                  │
        │ ─ ghost-lap-…    │             │                  │
        │ ─ champ-…        │             │                  │
        └────────┬─────────┘             └────────┬─────────┘
                 │                                │
                 ▼                                ▼
        ┌─────────────────────────────────────────────────┐
        │ Layer A · Databricks Lakehouse                   │
        │ ─ Unity Catalog (governed substrate)             │
        │ ─ Postgres (dev/pilot only)                      │
        │ ─ Redis (cache + budget tracking)                │
        │ ─ S3 (prompt packs + HIBT cold storage)          │
        └─────────────────────────────────────────────────┘
```

See `docs/deployment/DEPLOY.md` for env-specific details.

---

## 10. Observability + ops

Four Grafana dashboards (templates in `docs/observability/`):

- `pitwall-api` — Layer C latency, error rate, scope-denied rate
- `agent-fleet` — per-agent eval scores, drift, cost, latency
- `forecast-health` — MAPE, drift watch, override value-add, challenge-resolution time
- `v3-rollup` — feature-flag state per seat, cost budget utilization, eval gate status

Alerts route to PagerDuty + Slack `#nama-pit-wall-ops`. P1 conditions (privacy leakage, replay determinism failure, kill-switch trigger) page on-call eng + Govinda + Bob immediately.

---

## 11. Architecture decisions index

| ADR | Title |
|-----|-------|
| 001 | One trusted substrate |
| 002 | Five-seat persona model |
| 003 | HIBT replay-prompt-ledger as audit substrate |
| 004 | NAMA-certified agent gate |
| 005 | Dual cadence (15-min race + monthly S&OP) |

Each lives in `docs/adr/ADR-00X-*.md` with full context, alternatives, and consequences.

---

## 12. Glossary

- **Forecast Set** — A planning artifact for a horizon (e.g., Q3 2026 U.S. Trucks). Has scenarios, number objects, an owner, and a state.
- **Number Object** — A single forecasted quantity (e.g., Silverado HD Q3 = 87,400 units). Has P10/P50/P90 quantiles.
- **Scenario** — A named assumption set (e.g., +$1,500 incentive). Comparable, promotable to plan-of-record.
- **Override** — A structured human adjustment to a number with reason code + evidence.
- **Challenge** — Structured human dissent with reason code + evidence.
- **POR** — Plan-of-record. The committed forecast set version that all surfaces inherit.
- **HIBT** — How-I-Built-This. Replay-prompt-ledger v2.0. The immutable audit substrate.
- **MDS** — Material Disagreement Score. 0-1 score from Second-Opinion Agent.
- **Ghost issue** — A recurring `(SME × reason_code × nameplate)` challenge across N consecutive cycles.
- **Lap clap** — Lightweight peer recognition gesture in the Championship Table.

---

*This document is the architecture spine of the Pit Wall. All other technical artifacts derive from it.*
