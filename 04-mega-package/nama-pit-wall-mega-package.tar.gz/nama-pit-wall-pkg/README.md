# NAMA Pit Wall — Mega-Package

> **One planning brain. Many surfaces. Human judgment preserved.**

A complete, export-ready monorepo for the **NAMA Pit Wall** — a co-working forecasting platform for GM's North American Markets organization. Five persona seats, eight surfaces, seven NAMA-certified AI agents, one trusted forecast substrate.

This package contains everything needed to take the Pit Wall from concept to running code: PRD, MRD, FAQ, personas, architecture, design system, API spec, database schema, ADRs, working frontend scaffold, deployment plan, and per-platform export guides for Replit, Lovable, Claude Code, and OpenAI Codex.

---

## What's in this package

```
nama-pit-wall/
├── README.md                          ← you are here
├── EXEC_SUMMARY.md                    ← 1-page exec summary
├── ONE_PAGER.html                     ← printable cinematic one-pager
├── PRD.md                             ← full product requirements
├── PRD_FAQ.md                         ← Amazon-style working-backwards FAQ
├── MRD.md                             ← market requirements
├── PERSONAS.md                        ← 5 detailed personas
├── ARCHITECTURE.md                    ← 4-layer stack architecture
├── DESIGN_SPEC.md                     ← brand + UX + interaction system
├── ROADMAP.md                         ← v2.4 → v3.0 → v3.5 horizons
│
├── brand/
│   ├── tokens.css                     ← CSS custom properties
│   ├── tokens.json                    ← same tokens, JSON for tools
│   ├── pitch_deck.html                ← 12-slide cinematic deck
│   └── one_pager.html                 ← printable letter-portrait one-pager
│
├── docs/
│   ├── adr/                           ← 5 architecture decision records
│   │   ├── ADR-001-one-trusted-substrate.md
│   │   ├── ADR-002-five-seat-persona-model.md
│   │   ├── ADR-003-hibt-replay-ledger.md
│   │   ├── ADR-004-nama-certified-agent-gate.md
│   │   └── ADR-005-dual-cadence.md
│   ├── api/
│   │   └── openapi.yaml               ← Layer C Planning Access API
│   ├── schema/
│   │   └── schema.sql                 ← Postgres DDL with seed data
│   ├── runbooks/                      ← Ops runbook stubs
│   │   ├── budget_breach.md
│   │   ├── latency_spike.md
│   │   ├── replay_drift.md
│   │   └── calibration_drift.md
│   └── deployment/
│       └── DEPLOY.md                  ← env, kubernetes, rollout
│
├── src/                               ← runnable React + Vite + TS scaffold
│   ├── package.json
│   ├── vite.config.ts
│   ├── tsconfig.json
│   ├── index.html
│   ├── main.tsx
│   ├── App.tsx
│   ├── components/
│   │   ├── PitWall.tsx                ← main workbench (chart + scenarios + override)
│   │   ├── ForecastFan.tsx            ← D3 quantile fan chart
│   │   ├── SeatPicker.tsx             ← 5-seat selector
│   │   ├── TelemetryStrip.tsx         ← race-control KPIs
│   │   ├── SurfaceRing.tsx            ← 8 persona-surface tiles
│   │   ├── ActivityFeed.tsx           ← cross-surface activity stream
│   │   ├── RaceFlow.tsx                ← 15-minute race with baton-pass
│   │   ├── AgentStudio.tsx            ← AI GovOps message bus + work queue
│   │   └── HandoffToast.tsx           ← pit-to-driver radio overlay
│   ├── hooks/
│   │   ├── useSeat.ts                 ← persona seat state
│   │   └── useRaceClock.ts            ← 15-min race timer
│   ├── data/
│   │   ├── mockForecast.ts            ← FS-2026Q3-NA-TRK-001 sample
│   │   ├── mockAgents.ts              ← 7 NAMA-certified agents
│   │   └── mockActivity.ts            ← activity feed events
│   ├── styles/
│   │   ├── tokens.css                 ← brand tokens
│   │   └── globals.css                ← layout + reset
│   └── types/
│       └── index.ts                   ← TypeScript types for everything
│
├── EXPORT_REPLIT.md                   ← one-click Replit deploy guide
├── EXPORT_LOVABLE.md                  ← prompt-engineered Lovable bootstrap
├── EXPORT_CLAUDE_CODE.md              ← Claude Code session opening prompts
└── EXPORT_OPENAI_CODEX.md             ← Codex codebase tour + tasks
```

---

## Quick start

```bash
# 1. Install dependencies
cd src
npm install

# 2. Run the dev server
npm run dev
# → http://localhost:5173

# 3. Build for production
npm run build
```

Stack: **Vite + React + TypeScript + D3** for the frontend scaffold. Plain CSS with design tokens (no Tailwind, no styled-components — easier to port). No backend in the starter code — that's an architectural exercise; see `docs/api/openapi.yaml` and `docs/schema/schema.sql`.

---

## Project vision in 90 seconds

**The problem.** GM's NAMA forecasting organization runs ~22 cycles per month against ~$50B of revenue. Today, every seat brings their own spreadsheet. 38% of analyst time is rework. 14% of plan-of-record drift comes from version mismatches. Challenges take 4–7 days to resolve. Zero replayable agent actions.

**The vision.** One trusted substrate (Databricks + Unity Catalog). Five persona seats (Leadership / Analyst / SME / Ops / GovOps). Eight surfaces (Outlook, Teams, Excel, SharePoint, Power BI, Glean, Workbench, Agent Studio) — each writing back through one Access API. Seven NAMA-certified AI agents that handle the rework. Two clocks: a 15-minute urgent race and a monthly S&OP cycle. Every action immutable in the HIBT replay-prompt-ledger.

**The shape.** Two operating metaphors:

- **15-minute race.** Signal → Ops → Analyst → SME → Leadership → GovOps. Baton-pass at every stage. Pit-to-driver radio between seats. Plan-of-record committed and published to all surfaces within 15 minutes.
- **Monthly S&OP lap.** Three state gates: analyst-ready · challenge-ready · plan-of-record. Six lanes (data / analysts / SMEs / leadership / ops / govops). Agents handle mechanical prep; humans handle conflict, dissent, scenario choice, commit.

**The delighters (v3.0).** Second-Opinion Agent (adversarial review) · Ghost Lap (temporal overlay) · Championship Table (celebration, not eval). Detailed in `PRD.md` and the design doc.

**The principle.** *Agents do the rework, the research, the toil. Humans do the judgment, the dissent, the commit. The Pit Wall keeps them honest to each other.*

---

## Sponsorship + ownership

| Role | Owner |
|------|-------|
| Business sponsor | Ramzi Abdelmoula |
| Project architect | Bob Rapp |
| Forecasting lead | Krisztina Gilezan |
| Market signals · MIA | Jim Kyle |
| Data + ops | Mansoor Alghooneh · Govinda Chaluvadi |
| AI GovOps | Don S. |

---

## Reading order

If you're a **product reviewer**: start with `EXEC_SUMMARY.md` → `PRD_FAQ.md` → `PRD.md`.

If you're an **engineer building this**: start with `ARCHITECTURE.md` → `docs/adr/` → `docs/api/openapi.yaml` → `docs/schema/schema.sql` → `src/`.

If you're a **designer**: start with `DESIGN_SPEC.md` → `brand/tokens.css` → `brand/one_pager.html` → `src/components/PitWall.tsx`.

If you're a **sponsor**: open `brand/pitch_deck.html` and use ← → to navigate the 12 slides.

If you're **exporting to a coding tool**: see the matching `EXPORT_*.md` file for your target.

---

## Versions

| Version | Status | What ships |
|---------|--------|-----------|
| **v2.4** | shipped (May 2026) | 5 seats · 15-min race · monthly cycle · HIBT v2.0 · Agent Studio |
| **v3.0** | next 90 days | Second-Opinion Agent · Ghost Lap · Championship Table · Constraint twin |
| **v3.5** | 6 months out | Strategic horizon · auto-S&OP pre-read · external signal marketplace · cross-region wall |

See `ROADMAP.md` for detail.

---

## License + provenance

Internal GM artifact. Confidential. All work in this package logged in `docs/HIBT_LOG.md` (build provenance) per the AIGovOps Foundation `aigovops-foundation-rapp-how-i-built-this` rule.

---

*This README intentionally compact. Everything else is in the linked docs.*
