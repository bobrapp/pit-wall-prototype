# NAMA Pit Wall — Product Requirements Document

**Version:** 2.4 (with v3.0 forward references)
**Date:** 2026-05-12
**Owner:** Bob Rapp (architect)
**Sponsor:** Ramzi Abdelmoula

---

## 1. Vision

A co-working forecasting platform where every NAMA persona stays in the surface they prefer (Outlook, Teams, Excel, SharePoint, Power BI, Glean, Workbench) while every comment, challenge, override, and approval lands on the **same governed forecast substrate**. AI agents do the rework. Humans do the judgment. The Pit Wall keeps them honest to each other.

**Mission line:** *One planning brain. Many surfaces. Human judgment preserved.*

---

## 2. The customer

**Primary customers** (decision-makers, daily users):

- **NAMA forecasting analysts** (~30) — author baselines, stage overrides, build consensus
- **Subject-matter experts in MIA** (~20) — bring market signal, challenge with evidence
- **NAMA leadership** (~10) — commit plan-of-record, sign exec briefs
- **Ops + IT** (~15) — protect the pipelines, sign release-readiness
- **AI GovOps** (~5) — certify agents, own HIBT, run eval gates

**Secondary customers** (consume the output): plant planning, supply chain, pricing committee, dealer ops, CFO function.

**Sponsor:** Ramzi Abdelmoula (NAMA exec sponsor with budget authority).

---

## 3. The problem (with measurements)

Today, NAMA forecasting runs ~22 cycles per month against ~$50B of revenue. The cycle is fragmented:

| Symptom | Measurement | Source |
|---------|-------------|--------|
| Analyst time in rework, not analysis | **38%** | Q3 2026 retro |
| Plan-of-record drift from version mismatch | **14%** | Q1–Q2 2026 |
| Challenge resolution p50 | **4–7 days** | Q1–Q3 2026 |
| Replayable agent actions | **0** | No HIBT exists |
| Surfaces holding parallel truth | **8** | Current state |

**The cost of inaction.** Continued margin leakage from forecast accuracy gaps, plus unrecoverable analyst hours, plus AI-governance audit risk (no replay log for AI-assisted decisions = SOX exposure as those actions grow).

---

## 4. The solution (vision in shape)

### 4.1 One trusted substrate

Databricks + Unity Catalog. Every forecast, every number, every scenario, every override, every challenge, every approval — one source of truth. No shadow spreadsheets, no parallel ledgers.

### 4.2 Five persona seats

Each seat keeps the surfaces they already prefer. Each seat has role-aware decision rights enforced at the API edge.

| Seat | Surfaces | Decision rights |
|------|----------|-----------------|
| **Leadership** · Ramzi | Outlook · PBI · Teams · Morning Brief | Approve scenario · commit POR · sign exec brief |
| **Analyst** · Krisztina | Workbench · Excel · PA Agent · Compare | Author override · stage scenario · respond to challenge |
| **SME** · Jim Kyle | Teams · Glean · SharePoint · Avista | Raise challenge · attach evidence · comment |
| **Ops** · Govinda | Ops Control · PBI Health · Incidents · Guardrails | Pause / retry pipelines · signoff release-readiness |
| **AI GovOps** · Don S. | Agent Studio · HIBT · Eval Board · Replay | Promote / rollback agent · curate memory · audit replay |

### 4.3 Eight surfaces, one Number Object

Each surface (Outlook · Teams · Excel · SharePoint · Power BI · Glean · Workbench · Agent Studio) speaks its native idiom but writes back through the same Layer C Access API. The Number Object is the single anchor.

### 4.4 Seven NAMA-certified agents

| Agent | Version | Serves | Toil owned |
|-------|---------|--------|-----------|
| workbench-anomaly | v3.5 | Analyst | Drift + anomaly flagging |
| personal-assistant | v4.1 | Analyst | File comparison, prep |
| glean-copilot | v2.7 | SME · Leadership | Deterministic Q&A |
| intake-agent | v1.9 | SME | SharePoint tagging |
| narrative-drafter | v2.3 | Leadership | Exec brief drafting |
| guardrail-classifier | v1.4 | Ops | Stale-state auto-pause |
| avista-agent | v3.2 | SME | Dealer-pulse signals |

### 4.5 Two clocks

- **15-minute urgent race** — Ops → Analyst → SME → Leadership → GovOps. Baton-pass with pit-to-driver radio at every hand-off.
- **Monthly S&OP cycle** — 3 state gates (Analyst-ready · Challenge-ready · Plan-of-record) across 6 lanes.

### 4.6 HIBT replay-prompt-ledger v2.0

Every meaningful action logged immutably with reproducibility hash. ≥98% replay determinism is a hard NFR.

---

## 5. Functional requirements

### FR-1. Forecast Set lifecycle
The system MUST support the creation, versioning, and state-transition of forecast sets through six states: `draft → updated → challenged → committed → final → reviewed`.

### FR-2. Probabilistic forecasts
Every Number Object MUST expose P10, P50, P90 quantiles plus confidence (0–1) to every surface.

### FR-3. Structured override
Authors MUST submit overrides with a reason code (from `reason_codes` table), a value, an optional new P10/P90, evidence links, and a confidence level. Override writes to staging path only until approved.

### FR-4. Structured challenge
SMEs MUST be able to raise a challenge in under 90 seconds (action SLA) with a reason code, evidence links, and a recommended new value.

### FR-5. Scenario compare
Users MUST be able to compare ≥3 scenarios side-by-side on the same chart with delta indicators.

### FR-6. Plan-of-record commit
Only seats with the `approval.commit` scope MAY promote a scenario to plan-of-record. Commit MUST emit `plan.promoted` event and trigger downstream surface refresh.

### FR-7. Surface inheritance
On POR commit, all 8 surfaces MUST reflect the committed value within the surface-consistency SLA window (2.4s p95).

### FR-8. Risk-based review queues
The Process Engine MUST generate per-persona review queues based on agent-detected anomalies, drift scores, and challenge load.

### FR-9. Excel add-in
The Excel add-in MUST pull a forecast-set slice, render baseline/consensus/actuals columns, accept structured overrides written through Layer C, and never create a parallel truth.

### FR-10. Personal-assistant agent
The PA agent MUST pre-load file comparisons, validation flags, and cleaning suggestions for the analyst's Workbench session, writing all results to staging only.

### FR-11. Agent Development Lifecycle
Every NAMA-certified agent MUST pass the 5-category eval gate (correctness, calibration, adversarial, perf+cost, replay determinism) before any production promotion.

### FR-12. Decision-rights enforcement
The Layer C API MUST enforce decision rights via JWT scope claims on every write endpoint. No surface MAY elevate privilege.

### FR-13. HIBT integration
Every meaningful action MUST write a HIBT entry within 5s p95, including reproducibility hash.

### FR-14. 15-minute urgent race
The system MUST support a structured 5-stage urgent flow (Signal → Prep → Review → Commit → Release) with state transitions emitting events on the bus.

### FR-15. Monthly S&OP cycle
The system MUST support a recurring 6-lane swimlane with 3 state gates (analyst-ready, challenge-ready, plan-of-record) and per-gate signoff.

### FR-16. (v3.0) Second-Opinion Agent
On manual invoke or auto-trigger at Gate 3 for forecast sets ≥ $50M revenue impact, the system MUST invoke a divergent-prompt-pack agent and surface a Material Disagreement Score (MDS). If MDS ≥ 0.3, the system MUST raise a structured challenge and route to the SME by top divergent factor.

### FR-17. (v3.0) Ghost Lap
The system MUST offer a toggleable overlay of the prior cycle's forecast on the current Workbench chart, plus a recurring-challenge classifier that surfaces ghost issues at challenge raise time.

### FR-18. (v3.0) Championship Table
The system MUST track per-user contribution scores across 4 leagues (Override Value-Add, Challenge Precision, Agent Improvement, Mentorship) with monthly micros + quarterly Grand Prix, opt-in public visibility, and anti-gaming guardrails.

---

## 6. Non-functional requirements

| NFR | Target | Test |
|-----|--------|------|
| **Surface consistency SLA** | 2.4s p95 single-value | Synthetic check on every POR commit |
| **API availability** | 99.9% monthly | Standard uptime |
| **Replay determinism** | ≥ 98% | Weekly random sample of 50 production runs |
| **Per-seat daily cost cap** | $4.00 (Second-Opinion alone) | Enforced at agent layer |
| **Eval gate pass rate** | ≥ 96% sustained | Run every PR + nightly |
| **Feature flag kill-switch** | < 60s | Tested quarterly |
| **HIBT write SLA** | < 5s p95 | Synthetic check |
| **Drift watch cadence** | Weekly (calibration), nightly (replay) | GovOps owns |
| **NAMA-certified agent gate** | All 5 categories pass | Per agent before promotion |
| **Decision-rights enforcement** | 100% at API edge | Penetration test annually |

---

## 7. User stories (per persona)

### Leadership · Ramzi
- *As Ramzi*, I want to see only what moved, why, and what decision is needed, so I can approve fast and ship the exec brief.
- *As Ramzi*, I want to commit a scenario to POR and have it propagate to all surfaces within seconds, so I'm not chasing stragglers.
- *As Ramzi*, I want the exec brief pre-drafted by narrative-drafter so I edit a line instead of writing the page.

### Analyst · Krisztina
- *As Krisztina*, I want my Workbench to be pre-prepped by my PA agent when I sit down, so I'm reading anomaly summaries, not waiting for files to load.
- *As Krisztina*, I want to stage an override with a reason code and evidence link in under 30 seconds, so the structure is automatic.
- *As Krisztina*, I want compare mode to show last cycle's forecast as a ghost overlay, so I see drift over time without separate analysis.

### SME · Jim Kyle
- *As Jim*, I want to raise a challenge in Teams in under 90 seconds, so my market signal lands before consensus closes.
- *As Jim*, I want Glean to give me deterministic answers with cited sources, so my arguments are evidence-based not assertion-based.
- *As Jim*, I want to know when the same challenge keeps coming back across cycles (recurring ghost issue), so I'm not raising the same flag forever.

### Ops · Govinda
- *As Govinda*, I want guardrail-classifier to auto-pause publishing when upstream sources go stale, so I'm not chasing data after it's shipped.
- *As Govinda*, I want a pipeline-health view that mirrors the F1 pit-crew dashboard mental model, so I can see green-amber-red at a glance.

### GovOps · Don S.
- *As Don*, I want every agent action replayable from HIBT, so I can audit, debug, and certify.
- *As Don*, I want the eval gate enforced as a hard promotion blocker, so no agent ships untested.
- *As Don*, I want to roll back an agent version in ≤60 seconds via feature flag, so a bad promotion is recoverable.

---

## 8. Out of scope (v2.4 + v3.0)

- Strategic 3–5 year horizon planning (v3.5)
- Cross-region pit wall (NAMA + Europe + China) (v3.5)
- Plant planning system integration writes (v3.5)
- External signal marketplace (third-party data) (v3.5)
- User-configurable prompt packs (advanced) (v3.5+)
- Mobile-native apps (web responsive only at v2.4)

---

## 9. Success metrics

| Metric | v2.4 baseline | v3.0 target (6mo post-GA) | Source |
|--------|---------------|---------------------------|--------|
| Forecast accuracy MAPE | 8.2% | 7.6% (-0.6 pts) | HIBT actuals comparison |
| Challenge resolution p50 | 11 min (urgent), 2 days (monthly) | < 1 hr (urgent), < 1 day (monthly) | Process engine timestamps |
| Surface-consistency SLA | 2.4s p95 | Maintain | Synthetic checks |
| Override value-add | +1.9 pts YTD | +2.4 pts YTD | Counterfactual MAPE |
| Agent eval pass-rate | 96.4% | ≥ 96% sustained | Eval runner |
| Replay determinism | 98% | ≥ 98% | Weekly sample |
| Analyst time on rework | 38% | < 20% (-50%) | Annual analyst survey |
| Plan-of-record drift | 14% | < 5% | Version comparison |
| Adoption rate | n/a | ≥ 70% analyst sessions / week | Pit Wall telemetry |
| Sponsor NPS for the platform | n/a | ≥ 8 (1-10 scale) | Quarterly review |

---

## 10. Roadmap

See `ROADMAP.md` for the full timeline. Summary:

| Version | Window | What ships |
|---------|--------|-----------|
| **v2.4** | shipped May 2026 | 5 seats · 8 surfaces · 7 agents · 15-min race · monthly S&OP · HIBT v2.0 |
| **v3.0** | Q3 2026 (next 90 days) | Second-Opinion Agent · Ghost Lap · Championship Table · Constraint twin |
| **v3.5** | 6 months out | Strategic 3-5y · auto-S&OP pre-read · external signal marketplace · cross-region wall |

---

## 11. Constraints + assumptions

- **Substrate is committed:** Databricks + Unity Catalog. No migration to alternative substrate possible without sponsor signoff.
- **HIBT v2.0 is critical path:** ~70% complete; finalization gates v3.0. ML eng hire frees architecture bandwidth.
- **Budget:** $2.4M v3.0 build budget approved (subject to sponsor signoff post-PRD).
- **Team:** Bob (architect), Mansoor + Govinda (eng), Krisztina (forecasting), Jim (MIA), Don (GovOps), Ramzi (sponsor). One ML engineer hire targeting Q3 close.
- **NAMA-certified agent gate:** Owned by Don S. (GovOps). 5 categories, must all pass.
- **Per-seat budget cap:** $4.00/day for Second-Opinion Agent alone. Total agent compute budget ≤ $50K/month at v3.0 run-rate.

---

## 12. Open decisions (sponsor signoff required)

1. **ML engineer hire** — yes/no/timing. Recommendation: yes, close by end of week 1 of v3.0 build.
2. **$50M materiality threshold for Second-Opinion auto-trigger** — adjust per nameplate?
3. **Championship Table cultural-signoff process** — sponsor pre-launch review at week 4.
4. **HIBT retention beyond 24 months** — cold-store policy + cost.
5. **Cross-region expansion** — NAMA-only for v3.0; signal commitment for v3.5 timing.

---

## 13. Companion documents

| Doc | What it covers |
|-----|---------------|
| `PRD_FAQ.md` | Amazon-style working-backwards FAQ |
| `MRD.md` | Market requirements + competitive analysis |
| `PERSONAS.md` | 5 persona deep-dives |
| `ARCHITECTURE.md` | 4-layer technical architecture |
| `DESIGN_SPEC.md` | Brand + UX + interaction system |
| `ROADMAP.md` | v2.4 → v3.0 → v3.5 timeline |
| `docs/adr/` | 5 architecture decision records |
| `docs/api/openapi.yaml` | Layer C API contract |
| `docs/schema/schema.sql` | Layer A database DDL |

---

*This PRD is the canonical product spec. All implementation derives from it.*
