# NAMA Pit Wall — PRD-FAQ (Working-Backwards)
**Document type:** Amazon-style Working-Backwards FAQ
**Author:** Bob Rapp (Architect) on behalf of NAMA Forecasting
**Status:** Draft v1.0 — Pre-Launch
**Last updated:** 2026-05-12

---

## PRESS RELEASE

**FOR IMMEDIATE RELEASE — September 1, 2026**

**Contact:** NAMA Communications
**Dateline:** Detroit, MI

---

### NAMA Forecasting Modernizes Into a Co-Working Pit Wall, Replacing Shadow Spreadsheets with One Trusted Substrate

*General Motors' North American Markets organization launches a unified, agentic forecasting platform that eliminates rework, accelerates the 15-minute urgent override cycle, and gives every forecasting persona a single, auditable source of truth — accessed through whichever surface they already use.*

**Detroit, MI — September 1, 2026** — General Motors' North American Markets (NAMA) organization today announced the general availability of NAMA Pit Wall v3.0, a multi-surface agentic forecasting co-working platform that replaces years of fragmented shadow spreadsheets, disconnected email chains, and siloed tooling with one trusted forecast substrate. Every stakeholder — from the VP of Sales forecasting to the IT governance officer — accesses that substrate through the surface they already prefer: Outlook, Teams, Excel, SharePoint, Power BI, Glean, the Forecast Workbench, or Agent Studio. Seven purpose-built AI agents absorb the rework and research burden so that human forecasters can focus on the one thing that remains irreplaceable: judgment.

The platform centers on a structured forecast record — exemplified by FS-2026Q3-NA-TRK-001, the U.S. Full-Size Trucks Q3 2026 call of 312,400 units with a P10/P90 range of 287,600 to 338,900 — and advances that record through three monthly S&OP state gates while simultaneously supporting a 15-minute urgent override race when market signals demand it. Every override, every agent recommendation, and every exception is logged, classified, and traceable — giving AI GovOps the compliance record it requires and giving leadership the single number it can trust.

Version 3.0 introduces three headline delighters. The **Second-Opinion Agent** surfaces a probabilistic counter-estimate whenever a human override moves a forecast outside its historical confidence band, ensuring the analyst has seen the machine's view before committing. The **Ghost Lap** feature replays a forecaster's prior-period decision path against actual outcomes, enabling structured retrospective learning without blaming individuals. The **Championship Table** ranks forecast accuracy by region, product line, and persona over a rolling 12-month horizon, making excellence visible and creating healthy accountability.

NAMA Pit Wall was built with a $2.4 million investment for the v3.0 build. It is live across all eight surfaces as of today.

---

**Customer testimonial:**

> "Before Pit Wall, I would spend two hours every Monday morning reconciling three different Excel files just to understand what the current official number was — and I still wasn't sure I had the right one. Now I open the Forecast Workbench, the intake agent has already flagged the two anomalies worth my attention, and the narrative drafter has a first-pass rationale ready for me to edit. I can focus on whether the call is actually right. That's the job."
>
> — *Senior Demand Analyst, NAMA Trucks & Commercial Vehicles*

---

**Executive quote:**

> "NAMA Pit Wall is not an IT project. It is a strategic bet that the quality of our forecast — and the speed at which we can update it — is a competitive advantage. Shadow spreadsheets are a symptom of a broken process, not a solution to it. We fixed the process."
>
> — *Ramzi Abdelmoula, VP, NAMA Forecasting*

---

**Technical quote:**

> "The architectural challenge was not the agents — it was the substrate. We needed one canonical forecast state that Outlook, Teams, Excel, Power BI, Glean, and Workbench could all read from and write back to without diverging. Once we solved that with a unified event-sourced store and a thin API surface, the agent layer and the multi-surface rendering became straightforward. The Guardrail Classifier is what makes GovOps sleep at night: every agent action is classified before it commits."
>
> — *Bob Rapp, Principal Architect, NAMA Pit Wall*

---

## INTERNAL FAQ

*For executive sponsors, product leaders, and program stakeholders.*

---

### Q1. What is the customer problem we are solving?

NAMA forecasters — Analysts, SMEs, Ops staff, and the leadership team that relies on their outputs — spend a disproportionate fraction of their working time on coordination overhead rather than on forecast judgment. The root cause is that no single surface owns the canonical forecast state. A number originates in an analyst's Excel model, gets emailed to a distribution list, gets copied into a SharePoint deck, referenced in a Teams thread, and re-entered manually into the S&OP system. By the time leadership sees the number, there are four versions of it in four places, and nobody can reconstruct which one is authoritative or why it changed.

The 15-minute urgent override scenario makes this visible at its worst: when a significant market signal arrives — a competitor announcement, a supply disruption, a dealer order spike — the clock starts. Ops identifies the anomaly. The Analyst needs to assess it. The SME needs to validate the domain logic. Leadership needs to commit or hold. GovOps needs a compliant record of the decision. Today, that chain runs through email threads, ad-hoc Teams messages, and manual spreadsheet edits. The coordination overhead frequently exceeds the 15-minute window, and the audit trail is a reconstruct-after-the-fact exercise. That is the problem.

---

### Q2. Why now?

Three forces converged in 2025-2026. First, the agent tooling matured: large language model agents capable of reliable, auditable anomaly detection and narrative drafting became available at production cost levels that made a seven-agent architecture financially defensible. Second, the business pressure on forecast accuracy intensified: Q3 2025 saw two high-profile forecast misses in the trucks segment that were traced directly to version-control failures in shadow spreadsheets, not to analytical error. Third, NAMA leadership set a formal mandate in Q4 2025 to eliminate shadow spreadsheets organization-wide by end of 2026. The mandate created the organizational will; the technology maturity created the feasibility; the budget of $2.4M for v3.0 created the means. Waiting another cycle would mean a third year of compounding coordination debt and another set of avoidable misses.

---

### Q3. What is the simplest solution that solves the problem?

One canonical forecast state, a thin API surface that every existing tool can read from and write back to, and agents that absorb the mechanical rework between human decision points. The simplest version is not eight surfaces and seven agents — that is the full v3.0 build. The simplest version that actually solves the core problem is: a single event-sourced forecast store, one intake agent that classifies incoming signals, one workbench surface where analysts can see the canonical number and commit overrides, and one guardrail classifier that ensures every commit is logged and compliant. Everything else — Ghost Lap, Championship Table, Second-Opinion Agent, the Power BI integration, the Glean copilot — is value-added capability on top of that core. The core was delivered in v1.0. V3.0 is the full vision.

---

### Q4. What are the three things that must be true for this to succeed?

**1. Every persona trusts the substrate as the canonical number.** If a single senior SME continues to maintain a shadow spreadsheet "just in case," the network effect collapses and the platform loses its value. Adoption must be complete, not near-complete. This requires change management, not just tooling.

**2. The agents are right often enough that humans stop treating them as noise.** The workbench-anomaly agent must have a signal-to-noise ratio high enough that analysts act on its flags rather than dismissing them. A false-positive rate above roughly 20% will cause systematic ignore behavior. This is an ongoing calibration obligation, not a launch-day achievement.

**3. The 15-minute urgent cycle actually closes in 15 minutes.** If the platform replaces the email chain with a different coordination bottleneck, the business case erodes. The Ops-to-Analyst-to-SME-to-Leadership-to-GovOps handoff chain must be measurably faster than the status quo. Success requires not just the technology but the agreed-upon response SLAs for each persona.

---

### Q5. What happens if we do nothing?

The compounding costs of the status quo are not static. Each S&OP cycle that runs on shadow spreadsheets adds more version divergence, more manual reconciliation hours, and more organizational memory stored in individuals' local files rather than in a system of record. The two forecast misses in Q3 2025 cost NAMA a measurable volume of dealer confidence in the trucks segment. A third similar event in 2026 would not be treated as a process failure — it would be treated as an organizational competence failure. Beyond reputation, the regulatory environment for AI-assisted forecasting is tightening: the manual, undocumented override process that characterizes the status quo will be increasingly difficult to defend in an audit context by 2027. Doing nothing is not a neutral choice; it is a choice to absorb those costs.

---

### Q6. How will we know it is working? (Success metrics)

We will measure success on four dimensions at 90 days post-launch and again at 12 months:

- **Shadow spreadsheet elimination rate:** Target 100% of NAMA forecast personas accessing the canonical number exclusively through Pit Wall surfaces. Measured by IT access-log audit. Threshold for success at 90 days: 90% of active forecasters; 100% by month six.
- **15-minute cycle closure rate:** The percentage of urgent override events that complete the full Ops-to-GovOps handoff chain within 15 minutes. Baseline (status quo): estimated 35%. Target at 90 days: 70%. Target at 12 months: 85%.
- **Forecast accuracy delta:** Rolling 12-month MAPE (Mean Absolute Percentage Error) for NAMA forecasts versus the prior 12-month baseline. Target: 150 basis point improvement in MAPE at 12 months, validated against the FS-2026Q3-NA-TRK-001 class of records.
- **Analyst rework hours saved:** Self-reported and system-measured time spent on version reconciliation and manual re-entry per analyst per week. Baseline: estimated 3.5 hours/week per senior analyst. Target: under 30 minutes/week at 90 days.

---

### Q7. What are the top three risks and how do we mitigate them?

**Risk 1: Persona adoption failure.** The most technically complete platform fails if the Analyst persona or the SME persona does not trust it enough to abandon Excel as their system of record. Mitigation: the Excel surface is a first-class citizen — analysts do not have to leave Excel to interact with Pit Wall. The platform reads from and writes back to Excel through a certified add-in. Adoption is opt-in at the surface level; the canonical store is mandatory at the data level.

**Risk 2: Agent false positives eroding trust.** If the workbench-anomaly agent or the intake agent generate too many low-quality alerts, forecasters will learn to ignore them, and the platform's core value proposition — absorbing rework — collapses. Mitigation: the guardrail-classifier gates all agent outputs before they surface to any human persona. A confidence threshold below 75% suppresses the agent output entirely; it goes to a review queue for the AI GovOps persona (Don S.) rather than creating noise for the analyst. Thresholds are tunable per product line and per persona.

**Risk 3: Regulatory / audit non-compliance.** NAMA forecasting touches material planning and reporting. If the platform's agent actions cannot be fully audited — specifically, if the guardrail classifier's classification of an agent action cannot be reproduced — the platform creates legal and compliance exposure rather than eliminating it. Mitigation: every agent action is written to an immutable event log with a deterministic classification record. The avista-agent specifically handles regulatory retrieval and is designed for external audit readiness. Don S. has sign-off authority on the compliance architecture before any v3.0 go-live.

---

### Q8. How does this differ from what was attempted in 2023?

The 2023 initiative ("One Number") attempted to solve the canonical-state problem through a centralized data warehouse and a Power BI reporting layer. It failed for two reasons. First, it treated the forecast as a reporting artifact rather than a living collaboration substrate: it consumed data but did not support the override workflow, so analysts continued to maintain their Excel files as working documents and submitted them manually at cycle end. The warehouse was always a lagging read; it never achieved canonical authority. Second, it had no surface strategy: it assumed that if the data was accurate in Power BI, everyone would look at Power BI. They did not. NAMA Pit Wall inverts both assumptions: the forecast is a writable substrate accessible from the surface each persona already uses, and the override workflow is the primary interaction model, not reporting.

---

### Q9. What is in scope for v3.0 versus deferred?

**In scope for v3.0 (September 1, 2026 launch):**
- All eight surfaces (Outlook, Teams/Slack, Excel, SharePoint, Power BI, Glean, Forecast Workbench, Agent Studio/HIBT)
- All seven agents (workbench-anomaly, personal-assistant, glean-copilot, intake-agent, narrative-drafter, guardrail-classifier, avista-agent)
- The 15-minute urgent override cycle with full persona handoff chain
- The three monthly S&OP state gates
- Second-Opinion Agent, Ghost Lap, Championship Table (v3.0 delighters)
- Full immutable event log and compliance record for GovOps

**Deferred beyond v3.0:**
- International Markets expansion (SAMA, LAAM) — surface mapping and regulatory frameworks differ materially; scoped for 2027
- Dealer-tier direct access (currently read-only digest; full write access requires separate dealer data governance approval)
- Real-time streaming ingestion from factory production systems (current integration is batch at 15-minute intervals; true streaming is a platform infrastructure investment scoped separately)
- Automated S&OP gate advancement without human sign-off (regulatory guidance as of mid-2026 requires human confirmation at each gate; re-evaluate in 2027)

---

### Q10. How much will this cost, and what is the ROI?

The v3.0 build budget is **$2.4 million**, covering platform engineering, agent development, surface integrations, security review, change management, and the first year of operational support. Ongoing annual run cost is estimated at $620,000 (infrastructure, agent inference costs, and one dedicated platform engineer).

The quantifiable ROI case rests on three line items. Analyst rework reduction: if NAMA employs approximately 40 active forecasters averaging 3.5 hours per week of version-reconciliation rework at a fully-loaded cost of $85/hour, the status quo rework cost is approximately $620,000 per year. A 90% reduction yields $558,000 in recovered analyst time annually — nearly covering the full run cost. Forecast accuracy improvement: a 150 basis point MAPE improvement in the trucks segment alone, applied against the Q3 2026 volume forecast of 312,400 units and a contribution margin estimate, represents a material working-capital and production-scheduling benefit that exceeds the build cost within two cycles. Compliance risk reduction: unquantified but directionally significant given the trajectory of AI governance regulation.

---

### Q11. Who is the operating sponsor, and how are decisions made?

**Operating sponsor:** Ramzi Abdelmoula, VP NAMA Forecasting. Ramzi holds budget authority and is the single throat-to-choke for platform adoption.

**Architect and technical authority:** Bob Rapp. All surface integration decisions, agent architecture changes, and data model changes require Bob's sign-off.

**GovOps authority:** Don S. All changes to the guardrail classifier's ruleset, the compliance logging schema, or the agent action audit trail require Don's sign-off before deployment to production.

**Go/no-go decision structure:** A formal go/no-go gate is held 30 days before each major surface launch. The gate requires sign-off from Ramzi (business readiness), Bob (technical readiness), and Don S. (compliance readiness). Any one of the three can hold the launch.

---

### Q12. What is the go/no-go decision date?

The v3.0 go/no-go gate is scheduled for **August 1, 2026**, thirty days before the September 1 launch date. Prerequisites for a go decision: all eight surfaces passing integration testing against the canonical forecast store; the guardrail classifier achieving less than 5% false-negative rate on the compliance test suite; shadow-spreadsheet elimination pilot complete in the Trucks & Commercial Vehicles analyst cohort (the cohort that owns FS-2026Q3-NA-TRK-001); and Don S.'s formal compliance sign-off on the immutable event log architecture. If any prerequisite is unmet at August 1, the default decision is a four-week slip to October 1, not a scope reduction. Scope reduction is available only with Ramzi's explicit approval.

---

## EXTERNAL FAQ

*For frontline forecasters, SMEs, and the people who will use the platform daily.*

---

### Q1. Do I have to stop using Excel?

No. Excel is a first-class surface in NAMA Pit Wall. You will access the canonical forecast through a certified Excel add-in that connects your workbook directly to the platform's forecast store. You can continue to build scenarios, run sensitivities, and draft your override rationale in Excel exactly as you do today. The difference is that when you are ready to commit an override, you commit it through the add-in rather than by emailing a file. Your Excel file remains your working document; the platform becomes the system of record for the committed number. You do not have to learn a new tool on day one. You will need to stop maintaining a shadow file that lives only on your local drive — but the add-in is designed to make that feel like the easier path, not the harder one.

---

### Q2. Will my override be visible to people I do not know?

Your override rationale and the committed number will be visible to everyone in the NAMA forecasting chain who has access to the relevant forecast record — that includes your manager, the relevant SMEs, and leadership. This is intentional: one of the platform's core value propositions is that the reasoning behind every number is auditable. What is not broadcast indiscriminately is your in-progress work. While you are drafting an override in the Workbench or in Excel, your working notes are private until you choose to submit. The distinction is between a draft and a committed record. The Championship Table, which ranks forecast accuracy, displays results at the cohort and product-line level — it does not publish individual analyst names in a public leaderboard without that analyst's persona group's consent. Talk to your manager if you have specific concerns about visibility scope.

---

### Q3. What happens if the agent is wrong?

You override it. The agent's recommendation — whether it is the workbench-anomaly agent flagging an unusual volume signal or the narrative-drafter producing a first-pass rationale — is always a starting point for your judgment, never a final answer. The Second-Opinion Agent (new in v3.0) will surface a counter-estimate if your override moves the forecast outside its historical confidence band — not to block you, but to ensure you have seen the machine's view before you commit. You can override the agent's view with a single action. Your override takes precedence. Every agent action is classified by the guardrail classifier before it reaches you; actions that fail the compliance threshold do not reach you at all. If you believe an agent is systematically producing poor recommendations for your product line, that is a calibration issue — report it to your platform contact, and Don S.'s GovOps team will review the agent's confidence thresholds for that domain. The agents are tools in your hands, not authorities over your decisions.

---

### Q4. Can I undo a commit?

A committed override can be reversed, but not silently. The platform is built on an immutable event log — every commit is written and cannot be deleted. What you can do is submit a subsequent override that supersedes the earlier one, and both records will be visible in the audit trail with timestamps and rationale. This is a feature, not a limitation: it means you can correct a mistake quickly, and the record will show that you identified and corrected it. If you committed a number in error and need the canonical record to reflect the corrected number immediately, the intake agent can flag the revision as a priority update so that downstream consumers (Power BI dashboards, the S&OP gate record) refresh within the next 15-minute cycle. There is no "delete" — only "supersede." If this creates a concern for a specific workflow, raise it with Bob Rapp's team before go-live.

---

### Q5. Does this replace the monthly S&OP meeting?

No. The monthly S&OP meeting — and its three state gates — remains the governance heartbeat of NAMA forecasting. What NAMA Pit Wall changes is how much of that meeting is spent on reconciling versions rather than making decisions. Today, a significant fraction of S&OP preparation time is consumed by manual data assembly and version-control hygiene. With the platform, the data assembly is automated and the canonical number is unambiguous before the meeting starts. The meeting agenda shifts from "what is the number" to "is the number right and what do we do about it." The three S&OP state gates are modeled explicitly in the platform's workflow; the platform advances the forecast record through each gate and provides the supporting evidence. The gate itself — the human judgment and sign-off — remains a human activity. The platform supports it; it does not replace it.

---

### Q6. Who owns my data?

NAMA owns the forecast data. Your personal override rationale — the text you write to explain a commit — is attributed to you by name in the audit trail, but it is organizational data, not personal data. It is subject to GM's standard data governance policies. The platform does not use your forecast rationale or override history to train the underlying AI models without explicit organizational consent — that decision sits with Ramzi Abdelmoula and Don S., not with the platform vendor or the agent infrastructure team. If you have a specific question about data residency, retention periods, or your rights with respect to your attributed rationale, contact the AI GovOps team. The compliance architecture was designed with auditability and data ownership clarity as primary requirements, not afterthoughts.

---

*End of PRD-FAQ — NAMA Pit Wall v3.0*
*Prepared by Bob Rapp | Reviewed by NAMA Forecasting Leadership | Dated 2026-05-12*
