# NAMA Pit Wall — Design Spec

**Version:** 2.4
**Date:** 2026-05-12
**Owner:** Bob Rapp

---

## 1. Design philosophy

**Cinematic GM consumer-brand + Formula 1 race-control energy.**

The Pit Wall is an executive product. It must feel like a place serious people want to co-work, not a corporate intranet. Visual references draw from:

- **Chevy** — ignition red + halo yellow. Bold, energetic, fast.
- **Cadillac** — champagne + midnight. Refined, premium, executive.
- **Buick** — teal + platinum. Quiet sophistication.
- **F1 race control** — telemetry cyan + lap-time amber + starting-lights green. Real-time, high-stakes, choreographed.

Avoid: corporate blue, generic SaaS gradients, glowing AI-art clichés (particles, neon orbs, circuit-board textures), reflexive dark-mode-tech tropes.

Default mood: **cinematic dark, editorial typography, generous breathing room, real automotive photography where it grounds the brief.**

---

## 2. Color system

Full token list in `brand/tokens.css` and `brand/tokens.json`. Highlights:

### Base substrate (cinematic dark)
- `--void` #06080d — page background
- `--carbon` #0e1119 — panels
- `--pit` #171b27 — elevated surfaces

### Brand accents
- Chevy red `--chevy-red` #da1a2e · Chevy yellow `--chevy-yellow` #ffc72c
- Cadillac champagne `--cad-champagne` #c8b273
- Buick teal `--buick-teal` #7fb0bf
- F1 amber `--f1-amber` #ff6b00 · F1 cyan `--f1-cyan` #00e5ff · Start green `--start-green` #00d26a

### Seat-color binding (drives dynamic --accent)
| Seat | Token | Color |
|------|-------|-------|
| Leadership | `--seat-leadership` | Cadillac champagne |
| Analyst | `--seat-analyst` | F1 cyan |
| SME | `--seat-sme` | Buick teal |
| Ops | `--seat-ops` | Chevy yellow |
| GovOps | `--seat-govops` | Chevy red |

When a user selects a seat, `[data-persona="<seat>"]` on `<body>` swaps `--accent` to that seat's color. Every component using `var(--accent)` reskins automatically.

### State semantics
- `--good` #23d18b · `--warn` #ff9500 · `--risk` #ff453a

---

## 3. Typography

| Role | Family | Weights | Use |
|------|--------|---------|-----|
| **Display + headlines** | Fraunces (variable serif) | 500, 600, 700, 900 | Hero h1, section h2, scene titles |
| **Body + UI** | Inter | 400, 500, 600, 700 | Paragraphs, buttons, labels |
| **Telemetry + technical** | JetBrains Mono | 400, 500, 700 | Numbers, IDs, race clock, scene timestamps |

### Type scale
```
display:  clamp(48px, 7vw, 108px)     /* hero headlines */
h1:       clamp(38px, 5vw,  76px)
h2:       clamp(28px, 3.4vw, 46px)
h3:       24px
body-lg:  17px  (lead paragraphs)
body:     15px  (default)
body-sm:  13px
label:    11px  (mono uppercase, letterspacing 0.22em)
micro:    10px
```

### Typography rules
- Italic in headlines uses Fraunces with `font-style: italic; font-weight: 500;` — produces an editorial-magazine pull-quote feel
- Brand-color phrases in headlines (e.g. `<em>Many</em>` in cad-champagne, `<span class="amber">Zero</span>` in F1-amber) are encouraged for rhythm
- Mono labels always uppercase with letter-spacing 0.22em — feels like F1 telemetry / aviation HUD
- Body line-height 1.5–1.55; never tighter on long-form

---

## 4. Layout system

### Grid
- Max-width container: 1480px
- Standard padding: 24px desktop, 18px tablet, 14px mobile
- Section padding: 90px vertical desktop, 60px mobile
- Gutter: 18–24px

### Panels
Three elevation tiers:
1. **Panel** — bg `--carbon` to `--pit` linear-gradient, border `--line`, shadow `--shadow-soft`. Standard content.
2. **Cinematic panel** — bg `--carbon` + brand accent radial-glow, border `--line-strong`, shadow `--shadow`. Hero moments.
3. **Toast / overlay** — bg `rgba(8,10,14,.97)` + brand-color border, glow shadow, backdrop-blur(20px). Hand-off radio, modal alerts.

Radii: `--radius-sm` 8px (chips, buttons) · `--radius` 12px (cards) · `--radius-lg` 18px (panels)

### Layout primitives (in CSS Grid)
- **Pit Wall layout:** `grid-template-columns: 1.4fr 1fr` (chart + scenarios | presence + activity)
- **Surface ring:** `grid-template-columns: repeat(4, 1fr)` desktop; reordered via CSS `order` per active seat
- **Race stops:** `grid-template-columns: repeat(5, 1fr)` for the 5 pit stops
- **Swimlane:** custom HTML table with sticky lane column

---

## 5. Motion system

| Duration token | Use |
|----------------|-----|
| `--t-quick` 150ms | Hover state changes, button presses |
| `--t-norm` 250ms | Tab switches, panel reveals, accent recolor |
| `--t-slow` 450ms | Scene transitions, card flips |
| `--t-cinema` 650ms | Hero scene cross-fades, full-bleed reveals |

Ease curve: `cubic-bezier(0.4, 0, 0.2, 1)` — Material Design's standard ease, feels precise but not robotic.

### Specific patterns
- **Scene transitions** — opacity + 20px translate-y, 650ms
- **Seat swap** — accent CSS variable changes; tile elevation animates via `order` property in flex; 250ms transition
- **Race timer** — JetBrains Mono digital readout with subtle text-shadow amber glow; 100ms intervals
- **Baton chip glow** — box-shadow pulse on seat change; matches accent color
- **Hand-off radio toast** — translateY(-18px) → 0 with opacity 0 → 1; 350ms; auto-dismiss 4.5s
- **Activity feed** — items slide in from -6px translateY with opacity fade; 500ms; new items push down
- **Chart redraw** — D3 transitions on scenario switch, 350ms ease, paths morph smoothly

Reduce motion: respect `@media (prefers-reduced-motion: reduce)` by zeroing all transitions.

---

## 6. Component patterns

### State pills
Used for forecast-set state, agent status, surface health.
```html
<span class="state-pill committed">
  <span class="pip"></span>
  Committed · v2026.05B
</span>
```
States: `draft` (cyan), `challenged` (amber, pulsing pip), `committed` (green), `final` (champagne), `failed` (red).

### Telemetry pills (race-control strip)
Lap-timer-style chips. Mono uppercase label + bold value with optional color. LED dot left of each.
```html
<span class="tel-pill good">
  <span class="pip"></span>
  MAPE <span class="v">8.2%</span>
</span>
```

### Number Object hero card
The featured forecast number. Mono uppercase label, Fraunces 48px+ value, mono unit, delta chip.
```html
<div class="number-hero">
  <div class="label">Consensus volume — Q3 2026</div>
  <div class="big">312,400 <span class="unit">units</span></div>
  <div class="delta down">Δ -8,100 vs prior commit</div>
</div>
```

### Quantile fan chart (D3)
- P10–P90 shaded band in `rgba(0,229,255,0.16)`
- P50 median line in `--f1-cyan` weight 2
- Consensus override line in `--cad-champagne` weight 2.5, dashed `6,4`
- Actuals YTD in `--chevy-yellow` weight 3 with dot markers
- Commit marker in champagne dashed circle
- Separator line between historical and forecast horizon

### Race step
Per-stop card with race-amber top border (active), race-green (done), neutral (upcoming).
```
┌──────────────────────┐
│ Pit stop 3           │
│ Min 5–9              │
│ Human review         │  ← serif h5
│ Compare · challenge  │
│ Baton: SME           │  ← amber pill
└──────────────────────┘
```

### Seat card (5 seats)
Top border in seat color, mono persona number, serif role, mono brand-line, body summary, surface chips.

### Chapter card (demo reel)
Top border in F1 amber (active), cyan (played), neutral (upcoming). Mono chapter number, serif title, mono scene range + duration, progress fill at bottom edge.

### Hand-off radio toast
Top-center fixed overlay, race-amber border + glow, pulsing dot, FROM/TO route chips, ✓ Completed / → Next labels.

---

## 7. Interaction patterns

### Seat selection ("Take your seat")
- Click any of 5 seat cards → entire workspace recolors
- Action panel below the Pit Wall workbench swaps to that seat's primary action surface
- Activity feed filters to that seat's relevant events
- Surface ring reorders to elevate that seat's primary tools
- Telemetry strip rebuilds with KPIs that matter to that role
- Decision-rights ladder updates
- Choice persists in localStorage

### Scenario compare
- Click any scenario chip → chart redraws with that scenario's quantile fan
- Active scenario marked with accent border and `inset-shadow`
- Hover shows delta from base in tooltip

### Override staging
- Always staging-only writes
- Reason-code required (dropdown of taxonomy)
- Evidence link required (SharePoint URL or attached doc)
- Confidence radio (High / Medium / Low)
- "Open in Excel" button hands the staged override to Excel add-in for deeper edit

### Race playback
- Play / Pause / Prev / Next / Restart with keyboard shortcuts (Space, ←, →)
- Chapter picker for phase-level jump (Signal / Review / Commit / Release / Podium)
- Scene dots for fine-grain navigation
- Auto-advance toggle
- Narration toggle (audio-driven scene sync when on)
- Progress bar at top of controls
- Per-chapter progress fills smoothly during playback

### Agent Studio
- Live message-bus visualization (SVG with animated particles)
- Hover the bus to pause animation
- Work queue cards with ✓ Approve / ✎ Edit / ✕ Reject actions
- Click any action animates card out, queue advances

---

## 8. Imagery direction

### When to use real photography
- Hero shots that ground the brief in reality (GM vehicles, GM Renaissance Center, F1 pit walls, F1 telemetry screens, F1 pit stops)
- Always sourced via SearchImages from real GM media + motorsport sources
- Treated cinematically: dark overlay gradients, edge-light bloom, true-color preservation

### When to use AI-generated imagery
- Cinematic hero scenes that don't exist in the real world (Pit Wall command center reimagined as forecasting workbench, design studio overhead, Cadillac cockpit forecasting interior)
- Always Gemini Pro Image model, photographic style (not stylized illustration)
- Strict avoidance of glowing particles, neon orbs, circuit-board textures, generic AI clichés

### When NOT to use imagery
- Architecture diagrams (use ASCII or typography)
- Data visualization (D3 charts only)
- Decorative filler — never

### Imagery treatment
- Full-bleed hero: 21:9 cinematic with bottom gradient fade to page background
- Inset hero: 16:9 with border-radius and shadow
- Always alt-text and source attribution
- Background opacity 30–45% under text

---

## 9. Accessibility

- Color contrast: WCAG AA minimum (4.5:1 on body text, 3:1 on large text). Tokens validated against `--void` base.
- Keyboard: all interactive components keyboard-accessible; visible focus rings
- Screen reader: semantic HTML (`<main>`, `<section>`, `<nav>`, `<article>`), `aria-label` on icon-only buttons
- Motion: `@media (prefers-reduced-motion: reduce)` zeros animations
- Touch: tap targets ≥ 44×44px
- No info-only-by-color — all status indicators have a label or icon, not just a hue

---

## 10. Brand voice (copy guidelines)

| Voice trait | Example | Avoid |
|-------------|---------|-------|
| Decisive | "Ramzi commits Scenario B." | "Ramzi might want to consider committing..." |
| Specific | "MAPE -0.6 pts" | "Forecast accuracy improvements" |
| Real-world rooted | "Texas dealer pulse" | "Regional market sentiment indicator" |
| F1-energetic when fitting | "Lights out. Go go go." | "Initializing the operational cycle." |
| Editorial when serious | "The substrate stays one." | "Single source of truth!! 🎯" |
| Honest about tradeoffs | "Service failure NEVER blocks primary path." | (skipping tradeoffs entirely) |

Word inventory:
- Use: pit wall, lap, baton, seat, race, telemetry, signal, consensus, plan-of-record, ghost issue, championship, cycle
- Avoid: synergy, leverage (verb), proactive, leverage AI, ROI-positive, frictionless

---

## 11. Component naming

Components in `src/components/` follow PascalCase. Files match component name. Each component:
- One default export
- Props typed via interface declared at top of file
- CSS via co-located `.module.css` OR class-based using token CSS variables (token-driven preferred for portability)
- No styling libraries beyond CSS + design tokens

Examples:
- `PitWall.tsx` — main workbench layout
- `ForecastFan.tsx` — D3 quantile fan
- `SeatPicker.tsx` — 5-seat selector
- `TelemetryStrip.tsx` — race-control KPI strip
- `RaceFlow.tsx` — 15-min urgent race visualization
- `AgentStudio.tsx` — GovOps multi-panel view
- `HandoffToast.tsx` — pit-to-driver radio overlay
- `SurfaceRing.tsx` — 8 persona-surface tiles
- `ActivityFeed.tsx` — cross-surface event stream

---

## 12. Asset inventory

| Asset | Purpose | Source |
|-------|---------|--------|
| Pit wall command center hero (21:9) | Cover, closing | AI-generated (Gemini Pro) |
| Workbench cockpit overhead (16:9) | Section accents | AI-generated |
| Cadillac cockpit forecasting (16:9) | Leadership feel | AI-generated |
| Chevy Silverado EV exterior | Truck-segment hero | SearchImages (chevrolet.com) |
| Cadillac Escalade IQ interior | Leadership visual | SearchImages (cadillac.com) |
| Buick Wildcat EV concept | Buick line | SearchImages (gm.com news) |
| Corvette Z06 racing | Race energy | SearchImages |
| F1 pit wall telemetry | Strategy section | SearchImages |
| F1 pit stop choreography | 15-min race | SearchImages |
| F1 strategy engineer | Agent Studio | SearchImages |
| GM Renaissance Center aerial | Org anchor | SearchImages |

All URLs in the v2.4 application source. Re-source if any URL goes stale.

---

## 13. Brand checklist for new artifacts

Before publishing any new artifact in the Pit Wall ecosystem:

- [ ] Uses tokens.css OR equivalent token vars (no hardcoded hex)
- [ ] Fraunces for headlines, Inter for body, JetBrains Mono for telemetry
- [ ] Cinematic dark substrate (`--void` background)
- [ ] One brand-color accent dominant per section (not all five at once)
- [ ] Real photography or AI-generated cinematic hero — no generic stock
- [ ] Mono uppercase labels with 0.22em letter-spacing
- [ ] Motion respects `prefers-reduced-motion`
- [ ] WCAG AA contrast on body text
- [ ] Honors the operating principle: "agents do toil, humans do judgment"
- [ ] Has a HIBT log section at the bottom

---

*The aesthetic isn't decoration — it's how the operating philosophy shows up visually.*
