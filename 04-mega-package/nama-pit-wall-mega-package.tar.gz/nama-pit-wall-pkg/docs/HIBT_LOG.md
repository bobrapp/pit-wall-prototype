# HIBT · Build Provenance Log

Per the AIGovOps Foundation `aigovops-foundation-rapp-how-i-built-this` rule. Every meaningful build action logged.

## v2.4 Mega-Package · 2026-05-12 UTC

| Time | Actor | Action | Output |
|------|-------|--------|--------|
| 2026-05-12 09:00 PDT | Bob Rapp + Claude Opus 4.7 | Concept doc | NAMA Agentic Ensemble v2 |
| 2026-05-12 13:42 UTC | Bob + Claude | Build v2.4 interactive app | `nama_pit_wall.html` (artifact `cmp2q70rn0y2b07ad7hxdxpxi`) |
| 2026-05-12 14:00 UTC | Bob + Claude | Build pitch deck | `nama_pit_wall_deck.html` (artifact `cmp2qx5uw0z2l07adfxvr1jcc`) |
| 2026-05-12 14:30 UTC | Bob + Claude | Build executive one-pager | `nama_pit_wall_onepager.html` (artifact `cmp2r0ncw0ypj07adu0jzz4wz`) |
| 2026-05-12 14:55 UTC | Bob + Claude | PRD addendum for v3.0 delighters | Document `cmp2r8ado05kq06adeczn4lf8` |
| 2026-05-12 15:03 UTC | Bob + Claude | Engineering spec stub | Document `cmp2rg94l059q07ado1r8q03n` |
| 2026-05-12 15:51 UTC | Bob + Claude | Second-Opinion Agent design doc | Document `cmp2t5py111b807adak6l23cf` |
| 2026-05-12 16:00 UTC | Bob + Claude | End-to-end demo + Agent Studio | `nama_pit_wall_demo.html` (artifact `cmp2tfnam049e07adf6gyp1oi`) |
| 2026-05-12 16:30 UTC | Bob + Claude | Narration audio + sync | Audio `cmp2u4web091g07adon65nfd7` |
| 2026-05-12 17:00 UTC | Bob + Claude (+ 6 parallel subagents) | Mega-package assembly | This `/nama-pit-wall-pkg/` directory |

### Sub-agent contributions (parallel work)

- **Glint (PRD-FAQ):** 3,607 words · Amazon-style press release + internal/external FAQ
- **Glorb (Personas):** 5,706 words · 5 detailed persona deep-dives
- **Plonk (MRD):** 5,157 words · 8 sections including market sizing + competitive analysis
- **Sprocket (ADRs):** 4,822 words · 5 architecture decision records
- **Tunnel (OpenAPI):** 2,743 lines · 14 endpoints, 34 schemas, validated
- **Bolt (Schema):** 884 lines SQL · 22 tables, 66 indexes, 3 triggers, seed data

### Mega-package contents

**Top-level docs (Bob + Claude · primary):**
- `README.md` · `EXEC_SUMMARY.md` · `PRD.md` · `ARCHITECTURE.md` · `DESIGN_SPEC.md` · `ROADMAP.md`

**Subagent-authored docs:**
- `PRD_FAQ.md` · `MRD.md` · `PERSONAS.md`
- `docs/adr/ADR-001…005.md`
- `docs/api/openapi.yaml`
- `docs/schema/schema.sql`

**Brand artifacts:**
- `brand/tokens.css` · `brand/tokens.json` · `brand/pitch_deck.html` · `brand/one_pager.html`

**Starter code (React + Vite + TypeScript):**
- `src/package.json` · `src/vite.config.ts` · `src/tsconfig.json` · `src/index.html` · `src/main.tsx` · `src/App.tsx`
- 8 components (`PitWall`, `ForecastFan`, `SeatPicker`, `TelemetryStrip`, `SurfaceRing`, `ActivityFeed`, `RaceFlow`, `AgentStudio`, `HandoffToast`)
- Types · mock data · hooks · styles

**Deployment:**
- `docs/deployment/DEPLOY.md`
- `docs/runbooks/` (4 runbook stubs)

**Per-platform export guides:**
- `EXPORT_REPLIT.md` · `EXPORT_LOVABLE.md` · `EXPORT_CLAUDE_CODE.md` · `EXPORT_OPENAI_CODEX.md`

### Recreation notes

If this mega-package needs to be regenerated:

1. Start with the v2.4 concept doc and the 4-layer architecture
2. Preserve the 6 locked decisions from the Second-Opinion design doc
3. Preserve the operating principle: *Agents do the rework, the research, the toil. Humans do the judgment, the dissent, the commit.*
4. Use the canonical sample data (FS-2026Q3-NA-TRK-001 · 312,400 units · Texas dealer pulse anomaly · +$1,500 incentive scenario) consistently across all artifacts
5. Honor the GM consumer-brand + F1 race-control visual language; no generic AI clichés
6. Maintain the persona seat color binding: Leadership=champagne, Analyst=cyan, SME=teal, Ops=yellow, GovOps=red

### Owners

| Role | Owner |
|------|-------|
| Sponsor | Ramzi Abdelmoula |
| Architect | Bob Rapp |
| Forecasting | Krisztina Gilezan |
| MIA | Jim Kyle |
| Data & Ops | Mansoor Alghooneh · Govinda Chaluvadi |
| AI GovOps | Don S. |
