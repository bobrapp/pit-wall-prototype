# Runbook · Budget Breach

**Severity:** P2 (P1 if cascading)
**Trigger:** Per-seat daily LLM budget exceeded ($4.00/seat/day for Second-Opinion alone, $50K/month total v3.0)
**Owner:** Mansoor Alghooneh + Don S. (GovOps)

## Symptom

Users report 429 errors. Slack `#nama-pit-wall-ops` shows budget-warn alert at 80% then budget-exceeded at 110%.

## Likely causes

1. Spike in Gate 3 commits at month-end S&OP (expected periodic)
2. New user with high-volume usage pattern (genuine power user or gaming attempt)
3. LLM cost regression (provider pricing change not reflected in `est_cost`)
4. Bug: budget enforcer not deducting (check Redis key TTL)

## Immediate mitigation

- For affected user: respond in Slack with "Reset at midnight ET. Contact GovOps for raise if needed for active S&OP cycle."
- If multiple users affected: temporary global cap raise to $6.00/day, alert sponsor; revert after 24h
- If LLM cost regression suspected: pin LLM model to known-good dated version, redeploy

## Investigation

```bash
# Top users by cost today
psql -c "SELECT triggered_by_user_id, SUM(cost_usd) FROM second_opinion_runs
         WHERE created_at >= current_date GROUP BY 1 ORDER BY 2 DESC LIMIT 10;"

# Redis budget keys
redis-cli KEYS 'so_budget:*:'$(date +%Y-%m-%d)

# LLM provider dashboard
open https://platform.openai.com/usage  # or equivalent
```

## Permanent fix paths

- Recalibrate per-seat default cap if power-user pattern is legitimate
- Update `est_cost` estimator if LLM pricing changed
- Add anomaly detection for cost regression

## Escalation

- 1 hour with no resolution → page Mansoor + Govinda
- Sponsor alert via Slack DM if global cap raised
