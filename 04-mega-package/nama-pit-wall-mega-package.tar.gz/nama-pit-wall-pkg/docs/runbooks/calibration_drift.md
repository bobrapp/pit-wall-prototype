# Runbook · Agent Calibration Drift

**Severity:** P2 (P1 if persistent > 2 weeks)
**Trigger:** Weekly calibration eval shows R² < 0.6, OR SME-confirmation rate on raised challenges < 60%
**Owner:** Don S. (GovOps) + Krisztina G. (forecasting)

## Symptom

Calibration dashboard shows degraded R² between predicted MDS and realized SME-confirmation rate. SMEs increasingly dismiss raised challenges as "spurious" (DISM-1).

## Likely causes

1. **Domain shift** (forecasting context has materially changed; e.g., new vehicle launch shifts what "normal" looks like)
2. SME response quality degraded (overworked SMEs hitting dismiss without review)
3. MDS weights need recalibration (quarterly cycle missed)
4. Prompt pack drift (framing has become less divergent over time as primary improves)
5. Routing changes (top factors going to wrong SMEs who dismiss as not their domain)

## Immediate mitigation

- Trigger MDS recalibration manually: `kubectl exec deploy/eval-runner -- python -m calibrate.recalibrate_mds`
- Notify affected SMEs in Slack with calibration status — request thoughtful response cadence
- If routing is the cause: temporarily route everything to MIA / Jim K. while routing table is reviewed

## Investigation

```bash
# Confirmation rate by routed team
psql -c "SELECT route_team, AVG(CASE WHEN dismissal_reason IS NULL THEN 1 ELSE 0 END) AS confirm_rate, COUNT(*) AS n
         FROM second_opinion_runs JOIN so_dismissals ON so_dismissals.run_id = second_opinion_runs.id
         WHERE created_at > now() - interval '30 days'
         GROUP BY 1;"

# Dismissal velocity per SME (high velocity + DISM-1 = SME fatigue or wrong-SME)
psql -c "SELECT dismissed_by_user_id, COUNT(*) FILTER (WHERE reason_code = 'DISM-1') AS spurious_dismissals
         FROM so_dismissals WHERE created_at > now() - interval '30 days'
         GROUP BY 1 ORDER BY 2 DESC LIMIT 10;"

# Run calibration suite locally against last 4 weeks
make run-calibration-eval WINDOW=28d
```

## Permanent fix paths

- Weight recalibration via grid search on golden set + recent production data
- Routing table audit (Jim K. quarterly cadence)
- Prompt pack framing rotation (Don S. owns)
- SME workload audit — if dismissal velocity is the cause, that's an org problem not a tech one

## Escalation

- R² < 0.5 sustained 2 weeks → kill-switch the auto-trigger (manual remains available) until recalibration ships
- SME-confirmation rate < 40% sustained 1 week → P1 incident; sponsor brief
