# Runbook · Latency Spike

**Severity:** P2 (P1 if sustained > 1h on prod)
**Trigger:** p95 latency > 100s sustained 30 minutes (Second-Opinion). p95 Layer C latency > 4s sustained 5 minutes.
**Owner:** Mansoor + Govinda

## Symptom

Latency dashboard breach. Users report "second opinion still loading" or "PBI tile refresh stuck."

## Likely causes

1. LLM provider degradation (check provider status page)
2. Increased queue depth (auto-trigger fan-out during Gate 3 window)
3. Prompt pack growth (recently updated pack added too much context)
4. Postgres slow query (rare; check `pg_stat_statements`)
5. Network egress to LLM provider

## Immediate mitigation

- Check LLM provider status page; switch to fallback provider if degraded (`SO_MODEL_FALLBACK` env)
- Scale up service pods (2 → 6) if queue depth > 5
- If specific forecast set is responsible: mark it `so_disabled` temporarily
- If overall traffic is the cause: lower v3.0 percentage rollout from 50% → 25%

## Investigation

```bash
# Latency breakdown by step (Grafana panel)
open https://grafana.nama-internal/d/pitwall-api?var-step=llm_invocation

# Tail slow runs
kubectl logs -f deployment/second-opinion-svc | grep "duration_ms" | awk '$NF > 90000'

# Provider status
curl https://status.openai.com/api/v2/status.json
curl https://status.anthropic.com/api/v2/status.json
```

## Permanent fix paths

- Implement automatic LLM provider failover (currently manual)
- Enforce max-context check in CI (prompt pack growth)
- Implement priority queue (sync requests over auto-trigger)

## Escalation

- 30 min with no resolution → page Bob (architect)
- 2 hour sustained → sponsor alert; consider P4 → P3 rollback for v3.0 features
