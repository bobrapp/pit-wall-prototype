# Runbook · Replay Determinism Drift

**Severity:** P1 (architectural-grade NFR)
**Trigger:** Nightly replay determinism check shows < 98%
**Owner:** Don S. (GovOps) + Bob (architect)

## Symptom

Nightly replay-determinism dashboard < 98%. Some HIBT-logged runs no longer reproduce identical output when replayed from source.

## Likely causes

1. **LLM model version change** (most common — providers silently update underlying models)
2. Prompt pack changed without version bump (operator error)
3. Source data changed retroactively (rare; HIBT should snapshot)
4. Time-dependent input in prompt (e.g., "today" injected at runtime)
5. Random seed not pinned (model_params.yaml regression)

## Immediate mitigation

- Pin LLM model to specific dated version (e.g., `claude-opus-4.7-2026-05-01`)
- Verify prompt pack hash: `SELECT prompt_pack_hash FROM second_opinion_runs WHERE created_at > now() - interval '7 days'` and compare to current S3 object hash
- Pause Second-Opinion auto-trigger until replay rate recovers

## Investigation

```bash
# Identify drifted runs
psql -c "WITH replays AS (
  SELECT id, prompt_pack_hash, source_sha, model_version, reproducibility_hash, replay_match
  FROM hibt_entries
  WHERE created_at > now() - interval '7 days'
)
SELECT prompt_pack_hash, COUNT(*) FILTER (WHERE NOT replay_match)::float / COUNT(*) AS drift_rate
FROM replays GROUP BY 1 ORDER BY 2 DESC;"

# Check LLM provider model release notes
open https://docs.anthropic.com/en/release-notes/api
open https://platform.openai.com/docs/changelog
```

## Permanent fix paths

- Always pin to dated LLM model version, never use `latest`
- Enforce prompt pack hash check on every run; reject if mismatched
- Snapshot source data inputs into the run record (small overhead, big determinism win)
- Move "today" injection from prompt to structured input field

## Escalation

- Any single day < 95% drift → page Bob + Don
- 5% sustained 24h → consider full pack rollback to last known-good version
- 10% sustained 24h → P1 incident; sponsor + AI GovOps board notification
