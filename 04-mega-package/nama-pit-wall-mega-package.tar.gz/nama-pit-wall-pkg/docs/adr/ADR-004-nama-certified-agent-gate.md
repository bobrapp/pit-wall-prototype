# ADR-004: NAMA-Certified Gate for Agent Promotion

**Status:** Accepted — 2026-05-12
**Owner:** Bob Rapp

---

## Context

Seven AI agents are in scope for the NAMA Pit Wall platform. Each one can propose forecast changes, trigger alerts, surface recommendations to Leadership, or execute approved plans — actions with real downstream consequences on production decisions at scale. At the time of this writing, there is no standard process inside GM's North American Markets org for evaluating whether an AI agent is safe to promote to production. Teams have been shipping agents on a trust-and-monitor basis: deploy it, watch it, fix problems when they surface.

Trust-and-monitor is not an acceptable model here for two reasons. First, forecast errors in this domain are not cheap to catch post-hoc; by the time a bad recommendation surfaces in an S&OP review, decisions may already be in motion. Second, the HIBT replay-prompt-ledger (ADR-003) gives us the infrastructure to run rigorous pre-promotion evaluation — not using it would be a wasted capability.

GovOps is the natural owner of this gate. Don S. holds the GovOps seat and has been designated as the gate authority. The gate must be objective enough that Don can run it consistently, and documented enough that a future GovOps owner can inherit it without institutional knowledge loss.

---

## Decision

Every agent — new agents and materially updated existing agents — must pass a five-category evaluation gate before any promotion to the production environment. There are no exceptions and no provisional promotions. An agent that passes four categories but fails one is not promoted; it returns to development.

The five gate categories are:

**1. Correctness.** The agent's outputs on a held-out evaluation set must meet a defined accuracy threshold relative to analyst-produced ground truth. Threshold is set per agent based on domain; the minimum floor is 85% agreement on directional recommendations. Evaluated offline against historical scenarios.

**2. Calibration.** When the agent expresses confidence (e.g., "high confidence this region will underperform"), that confidence must be calibrated. Overconfidence in a forecast agent is a first-class failure mode. Evaluated by measuring stated confidence against realized outcomes on the evaluation set. Requires a minimum of 60 scored scenarios per agent.

**3. Adversarial robustness.** The agent must be tested against a suite of adversarial inputs designed to elicit hallucinated forecasts, prompt injection attacks, and attempts to bypass decision-right enforcement. The adversarial suite is maintained by GovOps and versioned alongside the gate. An agent that fails any adversarial test that produces a plausible-looking but wrong forecast is not promoted, regardless of performance on other categories.

**4. Performance and cost.** The agent must meet latency SLOs (p95 response time ≤ 8 seconds for interactive surfaces; ≤ 60 seconds for batch) and must not exceed the per-agent monthly cost ceiling defined in the platform budget. Cost is measured in the staging environment under representative load, not estimated from token counts alone.

**5. Replay determinism.** The agent must achieve ≥ 98% replay determinism on its evaluation set (consistent with the hard NFR in ADR-003). This is evaluated using the HIBT ledger's replay infrastructure. An agent that cannot reproduce its own reasoning reliably is not promoted.

Gate results are recorded in the HIBT ledger. Promotion is executed by GovOps (Don S.) via the Agent Studio surface. A promotion without a recorded gate result is a ledger violation and triggers an automated alert.

**Material update** is defined as: change to the agent's system prompt, change to the underlying model version, addition or removal of a tool, or any change to the agent's write-path permissions. Cosmetic changes (UI labels, notification text) do not trigger a re-gate.

---

## Consequences

**Positive:**
- Production agents have a documented, auditable proof of fitness. When an agent makes a wrong recommendation, the question "did we know this could happen?" has a defensible answer.
- The calibration category specifically addresses the LLM failure mode most dangerous in forecasting contexts: confident wrongness.
- GovOps ownership gives the gate a named authority who is not also responsible for building the agents. This separation of duties is meaningful.
- The gate creates a forcing function for good agent engineering practices: held-out evaluation sets, scenario libraries, load testing. These artifacts have value beyond the gate itself.

**Negative:**
- Gate overhead is real. Running all five categories for a new agent takes approximately 2-3 days of engineering time plus GovOps review. Teams that want to ship quickly will feel this cost. It is the right cost.
- The adversarial suite requires ongoing maintenance. If the suite is not updated as new attack patterns emerge, the adversarial category degrades to a checkbox. GovOps must budget for suite maintenance, not just gate execution.
- The 60-scenario minimum for calibration evaluation is a significant data requirement for agents in new domains where historical scenarios don't exist. A bootstrapping process for new-domain agents is needed and is deferred.

**Neutral / Deferred:**
- The specific accuracy thresholds per agent are not set in this ADR; they are set in each agent's certification specification.
- The process for retiring an agent that has been promoted but subsequently degrades is deferred to an operational runbook.

---

## Alternatives Considered

**1. Trust and audit (deploy, monitor, fix).** Deploy agents to production, watch their outputs, and remediate when problems surface. Rejected because in the NAMA forecasting context, "when problems surface" often means after a recommendation has influenced a production decision. The cost of a missed catch is asymmetric: catching a bad agent pre-promotion is cheap; catching it after it has influenced an S&OP outcome is expensive and potentially embarrassing externally.

**2. Shadow mode only (run in parallel, never write).** Agents run alongside human analysts, their outputs are visible but never committed. Rejected as a permanent state because it defeats the purpose of the platform (reducing analyst load, enabling faster decision cycles) and creates a second lineage problem — shadow outputs are not in the ledger, so they are not auditable, but they are visible to users who may informally act on them.

**3. Automated gate without GovOps sign-off.** All five categories run automatically; promotion triggers if all pass, no human approval required. Rejected because the adversarial category requires human judgment on novel attack patterns, and because automated approval without human sign-off is not consistent with GM's AI governance policy. The gate is designed to be fast-when-clean, not to eliminate human judgment.

---

## References

- NAMA Pit Wall Architecture Overview v0.9 (internal)
- ADR-002: Five-seat persona model (GovOps seat owns gate authority)
- ADR-003: HIBT replay-prompt-ledger (gate results recorded in ledger; replay determinism is category 5)
- NAMA Agent Certification Specification v1.0 (per-agent thresholds, evaluation set specifications)
- GM AI Governance Policy AIGOV-2025-01 (human sign-off requirement for production AI systems)
- Don S. — GovOps seat holder, gate authority (internal contact)
