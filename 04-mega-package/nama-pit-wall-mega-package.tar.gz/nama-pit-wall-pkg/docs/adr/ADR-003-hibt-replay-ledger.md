# ADR-003: HIBT Replay-Prompt-Ledger v2.0 as Immutable Audit Substrate

**Status:** Accepted — 2026-05-12
**Owner:** Bob Rapp

---

## Context

Traditional software audit logs record what happened: user X called endpoint Y at time Z with payload W. That is sufficient when the system's behavior is deterministic given inputs. It is insufficient when the system includes large language model agents, because the same inputs can produce different outputs across runs due to model versioning, temperature, tool-call non-determinism, and prompt injection. A log that says "Agent proposed override at 14:32" tells you nothing about why the agent proposed that override, whether the proposal was sound, or whether it could be reproduced and verified.

NAMA's regulatory context adds pressure. Forecasts that feed production planning decisions at GM's scale are subject to internal audit. When an auditor asks "why did the system recommend this volume change in March," the answer must be reproducible, not reconstructed from memory or inferred from a number in a spreadsheet.

The HIBT (How I Built This) replay-prompt-ledger was developed as a response to this gap. Version 2.0 is the first version that meets the bar required for production use in a regulated forecasting context.

---

## Decision

The HIBT replay-prompt-ledger v2.0 is adopted as the single, immutable audit substrate for all agent activity in the NAMA Pit Wall platform. Every prompt submitted to any of the 7 NAMA-certified agents, every tool call made by those agents, every human override, every approval or rejection, and every final forecast write is recorded in the ledger with:

- A **reproducibility hash** computed over the full prompt context, model version, tool call sequence, and output. The hash is deterministic given the same inputs.
- A **replay envelope** containing everything needed to re-execute the agent interaction against a pinned model version.
- An **event sequence number** that is monotonically increasing and gap-checked on ingest. A gap in sequence numbers triggers an alert; gaps are never silently tolerated.
- A **persona seat reference** linking each entry to the seat that initiated or approved the action (see ADR-002).

**Hard non-functional requirement:** replay determinism must be at or above 98% measured across a rolling 30-day window. Determinism is defined as: re-executing the replay envelope produces an output whose semantic content matches the original output as scored by a designated evaluator. A drop below 98% triggers a GovOps review; a sustained drop below 95% freezes agent promotion until root cause is resolved.

The ledger is append-only. No process, including GovOps, has a delete path. Corrections are recorded as new entries that reference the entry being corrected, not as modifications.

The ledger storage backend sits within Unity Catalog (consistent with ADR-001). The Events stream emitted by the Access API feeds the ledger ingestion pipeline. Ledger reads are exposed via a dedicated audit read path in Layer C; they are not mixed with forecast data reads.

---

## Consequences

**Positive:**
- Auditors get a complete, reproducible record. "Why did the agent recommend this" is answerable in minutes, not days.
- Replay capability enables regression testing when model versions change. Before promoting a new model version, replaying a representative sample of past interactions and comparing outputs is a first-class workflow.
- The reproducibility hash creates a natural integrity check. If the hash cannot be verified on replay, something in the environment has changed — that is valuable diagnostic information, not noise to suppress.
- The 98% determinism SLO forces the engineering team to be honest about which parts of the agent pipeline are non-deterministic and why.

**Negative:**
- Ledger ingest is on the write-path for every agent interaction. Ingest latency directly adds to agent response time. This must be kept below 50ms at p99; exceeding it requires async ledger write with synchronous hash commit.
- Storage cost is not trivial. Every tool call sequence is stored in full fidelity. Retention policy (currently 7 years per GM audit requirements) must be negotiated against storage cost explicitly.
- The 98% determinism requirement is operationally demanding. Achieving it requires pinned model versions in the replay envelope, deterministic tool call mocking for external APIs, and careful handling of time-sensitive context (e.g., "current date" in prompts).
- Append-only with no delete path means mistakes in the ledger are permanent. The correction-by-reference pattern must be well-understood by operators before go-live.

**Neutral / Deferred:**
- The specific evaluator used to score replay semantic equivalence is not defined in this ADR. It is deferred to the agent certification specification.
- Cross-tenant ledger federation for partner-org audit scenarios is deferred.

---

## Alternatives Considered

**1. Traditional structured audit log (no replay capability).** Standard practice: log the action, the user, the timestamp, and the payload. Rejected because it cannot answer "why" for LLM-generated recommendations. An auditor who asks why the agent proposed a 12% volume cut in a particular region cannot reconstruct the agent's reasoning from a log entry that says "AgentProposedOverride, region=MidWest, delta=-12%." The reasoning is not recoverable.

**2. Store full conversation transcripts without a reproducibility hash.** Capture everything the agent saw and said, but do not compute a hash or enforce replay determinism. Rejected because transcripts without hashes are not verifiable. A transcript can be selectively edited after the fact; without a hash there is no integrity guarantee. This is sufficient for informal debugging but not for regulated audit.

**3. External audit SaaS (third-party LLM observability platform).** Several platforms offer prompt logging and basic replay. Rejected because they do not meet GM's data residency requirements (prompt content includes internal forecast data), they cannot enforce the append-only constraint at the storage layer, and their replay determinism guarantees are not contractually auditable.

---

## References

- NAMA Pit Wall Architecture Overview v0.9 (internal)
- ADR-001: Single planning fabric (ledger stored in Unity Catalog)
- ADR-002: Five-seat persona model (seat reference required on every ledger entry)
- ADR-004: NAMA-certified agent gate (replay determinism tested as part of gate evaluation)
- HIBT Replay-Prompt-Ledger v2.0 specification (internal)
- GM Internal Audit Policy IA-2024-07 (7-year retention, integrity requirements)
