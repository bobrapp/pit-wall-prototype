# ADR-005: Dual Planning Cadence — 15-Minute Urgent + Monthly S&OP

**Status:** Accepted — 2026-05-12
**Owner:** Bob Rapp

---

## Context

Forecasting in NAMA operates at two fundamentally different time horizons that have, until now, lived in separate processes with separate tooling. The monthly S&OP cycle is structured, predictable, and human-paced: teams spend weeks building plans, converging on numbers, and presenting to leadership. The urgent cadence is the opposite: a market shock, an executive ask, or a supply disruption arrives with no notice and demands a credible response in minutes, not weeks.

These two rhythms have historically created a coordination problem. The S&OP plan is the "official" forecast, but by mid-cycle it is already stale relative to events that have happened since it was locked. Analysts maintain shadow adjustments — informal overlays — to bridge the gap. Those overlays are not in the system of record, which means agents cannot see them, auditors cannot trace them, and the HIBT ledger (ADR-003) cannot record them.

The platform must serve both rhythms on the same substrate. The risk is designing for one and degrading the other: optimize for the monthly cadence and urgent responses become slow and bureaucratic; optimize for event-driven urgency and the monthly S&OP process loses its structure and rhythm.

---

## Decision

Two planning clocks run simultaneously on the same substrate. They share the same data layer (ADR-001), the same persona model (ADR-002), and the same ledger (ADR-003). They differ in their state machine transitions and their triggering conditions.

**Urgent cadence (15-minute target):**
- Triggered by: Ops seat (manual trigger), agent-detected market event, or escalation from an inbound alert in Teams/Outlook.
- State machine: Draft → Review → Approved → Committed. Transitions can be compressed: an Analyst with a pre-approved scenario template can move from Draft to Committed in a single action if the GovOps seat has pre-authorized that template class.
- Time target: A credible, ledger-committed forecast update within 15 minutes of trigger. The 15 minutes includes agent scenario generation, Analyst review, and Leadership approval (for high-stakes overrides) or Ops execution (for pre-authorized updates).
- Surface routing: Urgent cycle events are pushed to Teams and Outlook immediately; Workbench shows the active urgent session; PBI dashboards refresh on commit rather than on schedule.
- Guardrail: An urgent commit cannot override a locked S&OP window without a Leadership approval. The lock exists to prevent urgent cadence from being used to bypass the S&OP governance process informally.

**Monthly S&OP cadence:**
- Triggered by: Calendar (first business day of month, automated); also triggerable manually by GovOps for off-cycle runs.
- State machine: Plan → Consolidate → Review → Lock. Lock is a hard state: no agent or persona below Leadership can write to the locked period without an explicit override that is recorded in the ledger.
- Surface routing: SharePoint hosts the structured review documents; PBI provides the comparison views; Workbench is the primary working surface for Analysts and SMEs during Consolidate.
- Cadence artifact: Each S&OP cycle produces a named snapshot in Unity Catalog that is immutable post-lock. Urgent commits made after lock are recorded as post-lock adjustments, not retroactively merged into the snapshot.

The two cadences share all infrastructure. An urgent commit made during an active S&OP Consolidate phase is visible to both state machines simultaneously; it does not pause the monthly cycle but is flagged as a mid-cycle adjustment in the S&OP artifact.

---

## Consequences

**Positive:**
- Urgent responses are no longer shadow work. They run through the same ledger, same decision rights, same agent infrastructure as monthly planning. Auditors see everything.
- The 15-minute target creates engineering accountability. It is a measurable SLO, not an aspiration. If the platform cannot meet it under realistic load, that is a failure to fix, not a negotiation to have.
- The monthly cadence retains its structure. The Lock state is not optional; it is enforced at the API layer (ADR-001). The S&OP process does not erode because urgent events can be handled without touching the locked plan.
- Pre-authorized scenario templates in the urgent cadence allow common response patterns to be approved in advance, dramatically reducing the human-in-the-loop latency for known event types (e.g., a standard tariff-shock response template).

**Negative:**
- Two state machines on one substrate are harder to reason about than one. During an active urgent session that overlaps with S&OP Consolidate, the system must correctly attribute writes to the right cadence. Bugs at this boundary are subtle and potentially damaging.
- The 15-minute SLO is aggressive for high-stakes overrides that require Leadership approval. If a Leadership persona is not reachable (time zone, travel), the urgent cadence degrades to "as fast as Leadership responds." The platform cannot fix organizational availability; it can only make the approval UI as frictionless as possible (mobile Teams, push notifications).
- Pre-authorized templates require upfront work to define and certify. Teams that do not invest in templates will find the urgent cadence slower than expected on first use.

**Neutral / Deferred:**
- The specific set of event types that can trigger an automated urgent session (versus requiring a manual Ops trigger) is deferred to the agent event-detection specification.
- Integration with external market data feeds for automated urgent triggers is deferred to a separate ADR.

---

## Alternatives Considered

**1. Single cadence (monthly S&OP only, urgent handled ad hoc).** Keep the S&OP process as the one true cadence; urgent responses are handled outside the system and reconciled at next cycle. Rejected because this is exactly the current state, which produces the shadow-overlay problem described in the context. The platform exists to fix this.

**2. Event-driven only (no fixed monthly cadence).** Build entirely around event triggers; abandon the monthly S&OP structure in favor of continuous forecast updates. Rejected because the monthly S&OP cycle is an organizational commitment, not a technical artifact. Leadership presentations, budget cycles, and partner communications are anchored to it. Removing it from the platform would not remove it from the organization; it would just move it back to spreadsheets.

**3. Two separate platforms, one per cadence.** Build a fast event-response tool and a structured planning tool independently, integrate them via API. Rejected because two substrates reintroduce the reconciliation problem from ADR-001. An agent that needs to incorporate the latest urgent commit when generating an S&OP scenario cannot do so reliably if urgent commits live in a different system. The value of the dual cadence is precisely that both clocks run on the same data.

---

## References

- NAMA Pit Wall Architecture Overview v0.9 (internal)
- ADR-001: Single planning fabric (both cadences write through the same Access API)
- ADR-002: Five-seat persona model (Ops triggers urgent; Leadership approves high-stakes urgent overrides; GovOps triggers off-cycle S&OP)
- ADR-003: HIBT replay-prompt-ledger (urgent commits are ledger entries, not out-of-band events)
- ADR-004: NAMA-certified agent gate (agents used in urgent scenarios must be gate-certified; pre-authorized templates require GovOps sign-off)
- NAMA S&OP process documentation v3.1 (monthly cadence structure and lock requirements)
- Platform SLO specification v0.4 (15-minute urgent target, p95 measurement methodology)
