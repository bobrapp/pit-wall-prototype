# ADR-002: Five Persona Seats with Role-Aware Decision Rights

**Status:** Accepted — 2026-05-12
**Owner:** Bob Rapp

---

## Context

Co-working forecasting platforms fail in one of two ways: they are too permissive (everyone can edit everything, so accountability diffuses to nobody) or too restrictive (approval chains are so long that people route around them with email threads). NAMA has experienced both. The current S&OP process has a documented ownership gap: it is not always clear who has the authority to accept a volume override versus who is merely flagging a concern.

When AI agents enter this environment the stakes go up. An agent that can propose a forecast change must have a well-defined human in the approval chain. "Whoever happens to be looking at the screen" is not a governance model. The system needs a small, fixed set of role types whose decision rights are enforced at the API layer, not left to social convention.

The forcing function is the NAMA-certified agent gate (ADR-004): the gate's approval workflow must reference a specific persona seat. Without defined seats, the gate cannot route approvals.

---

## Decision

The platform defines exactly five persona seats. Each seat carries a defined surface preference set (the surfaces that seat primarily uses) and a set of enforced decision rights — what that seat can read, propose, approve, override, and lock.

| Seat | Primary Surfaces | Core Decision Rights |
|---|---|---|
| **Leadership** | PBI, Teams, Outlook | Read all; approve high-stakes overrides; lock forecast windows |
| **Analyst** | Workbench, Excel, PBI | Read all; propose overrides; run agent scenarios; cannot self-approve |
| **SME** | Excel, SharePoint, Workbench | Read domain slice; propose domain-specific overrides; flag anomalies |
| **Ops** | Teams, Agent Studio, Workbench | Execute approved plans; trigger urgent cadence; cannot propose overrides |
| **GovOps** | Agent Studio, Workbench, all audit surfaces | Read all including ledger; approve/reject agent promotions; own the certified agent gate |

Decision rights are enforced by the Access API (Layer C), not by surface-level UI controls alone. A request carrying an SME token cannot approve a cross-domain override regardless of which surface it originates from.

Surface preferences are defaults, not restrictions. A Leadership user can open Workbench. The preferences drive default routing for notifications, alerts, and agent-generated summaries.

---

## Consequences

**Positive:**
- Approval workflows in the agent gate (ADR-004) have a named, typed approver. Routing is deterministic.
- Accountability is explicit. When a forecast override is accepted, the ledger records which seat accepted it.
- Onboarding is faster because new users slot into a known role rather than negotiating bespoke permissions.
- The five seats map cleanly onto the five primary stakeholder groups identified in the NAMA org review; no synthetic roles needed.

**Negative:**
- Real organizations are messy. Some individuals hold responsibilities that span two seats (an Analyst-SME hybrid is common). The platform handles this by allowing a user to hold multiple seats, but multi-seat users must explicitly switch context when acting in each role. This adds a small friction cost.
- Five seats means five sets of UI surface defaults to maintain. Any new surface added to the platform must define its position relative to all five.
- Changing seat definitions post-launch requires a coordinated migration of all existing role assignments and a re-audit of any in-flight agent approvals.

**Neutral / Deferred:**
- External personas (partner orgs, auditors) are not assigned seats in this model; their access pattern is deferred to a separate access policy ADR.
- The mapping from Microsoft Entra ID groups to persona seats is an implementation detail, not decided here.

---

## Alternatives Considered

**1. Free-form roles defined per deployment.** Maximum flexibility; organizations configure their own roles. Rejected because free-form roles cannot be referenced by name in the agent gate, make approval routing non-deterministic, and have historically produced permission sprawl in every platform that has tried it.

**2. Single super-user seat with feature flags.** One role type; capabilities gated by toggles. Rejected because it collapses the accountability model — the audit record shows "a user did X" rather than "an Analyst proposed X and a Leadership seat approved it." It also means any user with full flags can approve their own changes.

**3. RACI-matrix approach with 12-15 named roles.** More granular, maps more directly to the org chart. Rejected because granularity beyond five seats produced approval chain ambiguity in testing: when a forecast touched three domains, it was unclear which of six possible approver roles was authoritative. Five seats is the minimum that preserves accountability without creating routing puzzles.

---

## References

- NAMA Pit Wall Architecture Overview v0.9 (internal)
- ADR-001: Single planning fabric (Access API enforces seat-level rights at the write layer)
- ADR-004: NAMA-certified agent gate (gate approval workflow references GovOps seat explicitly)
- NAMA S&OP process documentation v3.1 (source of the five stakeholder group mapping)
- GM IAM policy IAM-2025-03 (Entra ID group structure constraints)
