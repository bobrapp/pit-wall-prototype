# ADR-001: Single Planning Fabric on Databricks + Unity Catalog

**Status:** Accepted — 2026-05-12
**Owner:** Bob Rapp

---

## Context

NAMA's forecasting work currently lives across at least four distinct surfaces: Excel workbooks circulated by email, a SharePoint list used informally as a version-control substitute, two Databricks notebooks with competing schemas, and a Power BI dataset that is refreshed on a schedule nobody fully trusts. Analysts reconcile these by hand before each S&OP cycle. The cost is not just time — it is epistemic: when two analysts present contradictory volume numbers in the same leadership review, the room spends 20 minutes debugging lineage rather than making decisions.

The forcing function is the introduction of AI agents. An agent that can write a forecast override or fire an alert must have exactly one authoritative place to write to and one authoritative read path for every downstream surface. There is no safe version of an agent that writes to "whichever surface happens to be in front of it."

---

## Decision

All forecast data writes go through a single planning fabric: Databricks with Unity Catalog as the governance layer. Every persona surface — Outlook/Teams, Excel, SharePoint, Power BI, Glean, Workbench, Agent Studio — reads and writes exclusively via Layer C (the Access API), never directly to storage. Shadow spreadsheets are not a supported workflow; any data that originates outside the fabric must be ingested through a defined onramp before it is acted upon.

Unity Catalog provides the column-level lineage, fine-grained ACLs, and audit trail that regulated forecasting data requires. Databricks provides the compute substrate for both the Process Engine and the Planning Fabric, collapsing the number of credential domains, network paths, and schema registries from four to one.

The Access API (Layer C) is the single choke point. It enforces persona-level decision rights, rate limits agent write operations, and emits the Events stream that feeds the HIBT replay-prompt-ledger. No surface bypasses it.

---

## Consequences

**Positive:**
- One schema, one lineage graph. When a number is questioned, the answer is always traceable.
- Agent writes are bounded and auditable by default. No agent can silently overwrite a forecast without a ledger entry.
- Onboarding a new surface (a ninth persona surface, a new integration) requires wiring to one API, not replicating a data contract across N stores.
- Unity Catalog row/column security means GDPR and internal data classification policies are enforced at the storage layer, not left to application logic.

**Negative:**
- Single point of failure. If the Access API is unavailable, all surfaces lose write capability simultaneously. This requires robust SLAs, circuit breakers, and a read-only graceful degradation mode.
- Migration cost is real. Existing Excel-native workflows will require change management. Some SME personas will experience friction before they experience benefit.
- Databricks licensing and Unity Catalog entitlements carry non-trivial cost. The cost is justified by eliminating reconciliation labor, but the line item is visible in a way that distributed shadow copies are not.

**Neutral / Deferred:**
- The onramp process for external data (partner feeds, market data) is defined architecturally here but its operational SLA is deferred to a separate ADR.
- Multi-region replication strategy is not decided in this ADR.

---

## Alternatives Considered

**1. Federated stores with a reconciliation layer.** Each team maintains its own store; a nightly job harmonizes them. Rejected because reconciliation jobs fail silently, the failure surface scales with team count, and agents cannot safely write to a substrate whose consistency model is "eventually, if the job ran."

**2. SharePoint as the single source of truth.** Already in the tenant, no new licensing. Rejected because SharePoint's versioning model is not fit for programmatic write paths, its API has rate limits incompatible with agent throughput, and it provides no column-level lineage.

**3. Hybrid: Databricks for compute, existing data warehouse for persistence.** Rejected because it reintroduces a second credential domain, a second schema registry, and latency in the write path that breaks the 15-minute urgent cadence (see ADR-005).

---

## References

- NAMA Pit Wall Architecture Overview v0.9 (internal)
- ADR-003: HIBT replay-prompt-ledger (audit substrate depends on this decision)
- ADR-005: Dual planning cadence (15-minute cadence requires low-latency writes to a single store)
- Databricks Unity Catalog documentation: Fine-grained access control and lineage
- GM Data Governance Policy DG-2024-11 (column classification requirements)
