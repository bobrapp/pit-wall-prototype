-- =============================================================================
-- NAMA Pit Wall Planning Fabric — Layer A Schema
-- =============================================================================
-- File    : schema.sql
-- Role    : Complete DDL for the Pit Wall dev/test Postgres backing store.
--           In production this schema is mirrored in Databricks + Unity Catalog;
--           Postgres (target v15+) serves as the canonical dev/test target and
--           supports the full demo surface including v2.4 baseline tables and
--           the v3.0 additions (Second-Opinion, Ghost Lap, Championship Table).
-- DB name : nama_pit_wall
-- Version : 3.0.0
-- Updated : 2026-05-12
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Extensions
-- -----------------------------------------------------------------------------
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";
-- pg_partman is used for monthly partitioning of hibt_entries
CREATE EXTENSION IF NOT EXISTS "pg_partman";

-- -----------------------------------------------------------------------------
-- Utility: auto-update updated_at trigger function (shared)
-- -----------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION set_updated_at()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

-- =============================================================================
-- DROP ORDER (reverse FK dependency)
-- =============================================================================
DROP TABLE IF EXISTS visibility_preferences       CASCADE;
DROP TABLE IF EXISTS lap_claps                    CASCADE;
DROP TABLE IF EXISTS championship_scores          CASCADE;
DROP TABLE IF EXISTS championship_seasons         CASCADE;
DROP TABLE IF EXISTS override_outcomes            CASCADE;
DROP TABLE IF EXISTS recurring_challenges         CASCADE;
DROP TABLE IF EXISTS ghost_lap_projections        CASCADE;
DROP TABLE IF EXISTS so_dismissals                CASCADE;
DROP TABLE IF EXISTS disagreement_scores          CASCADE;
DROP TABLE IF EXISTS second_opinion_runs          CASCADE;
DROP TABLE IF EXISTS agent_promotions             CASCADE;
DROP TABLE IF EXISTS agents                       CASCADE;
DROP TABLE IF EXISTS hibt_entries                 CASCADE;
DROP TABLE IF EXISTS approvals                    CASCADE;
DROP TABLE IF EXISTS challenges                   CASCADE;
DROP TABLE IF EXISTS overrides                    CASCADE;
DROP TABLE IF EXISTS constraint_links             CASCADE;
DROP TABLE IF EXISTS scenarios                    CASCADE;
DROP TABLE IF EXISTS number_objects               CASCADE;
DROP TABLE IF EXISTS forecast_sets                CASCADE;
DROP TABLE IF EXISTS reason_codes                 CASCADE;
DROP TABLE IF EXISTS users                        CASCADE;

-- =============================================================================
-- CORE TABLES (v2.4 baseline)
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 1. users
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name          TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    role          TEXT NOT NULL CHECK (role IN ('leadership','analyst','sme','ops','govops')),
    team          TEXT,
    on_call       BOOLEAN NOT NULL DEFAULT FALSE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  users              IS 'Platform users who participate in the Pit Wall workflow.';
COMMENT ON COLUMN users.id           IS 'UUID primary key.';
COMMENT ON COLUMN users.name         IS 'Display name.';
COMMENT ON COLUMN users.email        IS 'Unique corporate email, used as login identity.';
COMMENT ON COLUMN users.role         IS 'Functional role: leadership | analyst | sme | ops | govops.';
COMMENT ON COLUMN users.team         IS 'Organizational team (e.g. NA Trucks SME).';
COMMENT ON COLUMN users.on_call      IS 'TRUE when user is the on-call responder for their function.';
COMMENT ON COLUMN users.created_at   IS 'Row creation timestamp.';
COMMENT ON COLUMN users.updated_at   IS 'Last modification timestamp, maintained by trigger.';

CREATE TRIGGER trg_users_updated_at
    BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 2. reason_codes
-- -----------------------------------------------------------------------------
CREATE TABLE reason_codes (
    id          TEXT PRIMARY KEY,                  -- e.g. R-12
    name        TEXT NOT NULL,
    category    TEXT NOT NULL CHECK (
                    category IN ('incentive','inventory','tariff',
                                 'competitive','dealer','capacity',
                                 'macro','other')),
    description TEXT,
    active      BOOLEAN NOT NULL DEFAULT TRUE
);

COMMENT ON TABLE  reason_codes             IS 'Controlled vocabulary of business reason codes used in overrides and challenges.';
COMMENT ON COLUMN reason_codes.id          IS 'Short code, e.g. R-12. Used as display identifier and FK.';
COMMENT ON COLUMN reason_codes.name        IS 'Human-readable name, e.g. "Incentive Adjustment".';
COMMENT ON COLUMN reason_codes.category    IS 'High-level category bucket.';
COMMENT ON COLUMN reason_codes.description IS 'Extended guidance for when to apply this code.';
COMMENT ON COLUMN reason_codes.active      IS 'FALSE soft-disables the code from new usage.';

-- -----------------------------------------------------------------------------
-- 3. forecast_sets
-- -----------------------------------------------------------------------------
CREATE TABLE forecast_sets (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                TEXT NOT NULL,
    horizon             TEXT NOT NULL,                  -- e.g. Q3 2026
    scenario_id         UUID,                           -- FK added after scenarios table
    model_version       TEXT NOT NULL,
    data_snapshot_id    TEXT,                           -- opaque ref to upstream snapshot
    owner               UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    state               TEXT NOT NULL DEFAULT 'draft'
                            CHECK (state IN ('draft','updated','challenged',
                                             'committed','final','reviewed')),
    por_status          BOOLEAN NOT NULL DEFAULT FALSE, -- TRUE = Plan of Record
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    soft_delete         BOOLEAN NOT NULL DEFAULT FALSE
);

COMMENT ON TABLE  forecast_sets                   IS 'Top-level container for a forecast cycle (e.g. Q3 2026 NA Trucks).';
COMMENT ON COLUMN forecast_sets.id                IS 'UUID primary key.';
COMMENT ON COLUMN forecast_sets.name              IS 'Human-readable name, e.g. FS-2026Q3-NA-TRK-001.';
COMMENT ON COLUMN forecast_sets.horizon           IS 'Forecast horizon label, e.g. Q3 2026.';
COMMENT ON COLUMN forecast_sets.scenario_id       IS 'FK to current active scenario; nullable until a scenario is promoted.';
COMMENT ON COLUMN forecast_sets.model_version     IS 'Version tag of the model that produced this set.';
COMMENT ON COLUMN forecast_sets.data_snapshot_id  IS 'Opaque reference to upstream data snapshot used.';
COMMENT ON COLUMN forecast_sets.owner             IS 'FK to users — analyst responsible for this set.';
COMMENT ON COLUMN forecast_sets.state             IS 'Lifecycle state: draft → updated → challenged → committed → final → reviewed.';
COMMENT ON COLUMN forecast_sets.por_status        IS 'TRUE when this set is the active Plan of Record.';
COMMENT ON COLUMN forecast_sets.soft_delete       IS 'Logical delete flag; rows are never physically removed.';

CREATE TRIGGER trg_forecast_sets_updated_at
    BEFORE UPDATE ON forecast_sets
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 4. scenarios
-- -----------------------------------------------------------------------------
CREATE TABLE scenarios (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_set_id   UUID NOT NULL REFERENCES forecast_sets(id) ON DELETE CASCADE,
    name              TEXT NOT NULL,
    description       TEXT,
    assumptions       JSONB NOT NULL DEFAULT '{}',
    compare_state     TEXT NOT NULL DEFAULT 'draft'
                          CHECK (compare_state IN ('draft','active','promoted','archived')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  scenarios                  IS 'Alternative planning scenarios attached to a forecast set.';
COMMENT ON COLUMN scenarios.id               IS 'UUID primary key.';
COMMENT ON COLUMN scenarios.forecast_set_id  IS 'Parent forecast set.';
COMMENT ON COLUMN scenarios.name             IS 'Scenario label, e.g. "Upside — High Incentive".';
COMMENT ON COLUMN scenarios.description      IS 'Free-text narrative describing the scenario.';
COMMENT ON COLUMN scenarios.assumptions      IS 'JSONB bag of key assumptions (rates, volumes, events).';
COMMENT ON COLUMN scenarios.compare_state    IS 'Lifecycle: draft | active | promoted | archived.';

-- Now that scenarios exists, add the FK on forecast_sets.scenario_id
ALTER TABLE forecast_sets
    ADD CONSTRAINT fk_forecast_sets_scenario
    FOREIGN KEY (scenario_id) REFERENCES scenarios(id) ON DELETE SET NULL;

-- -----------------------------------------------------------------------------
-- 5. number_objects
-- -----------------------------------------------------------------------------
CREATE TABLE number_objects (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_set_id  UUID NOT NULL REFERENCES forecast_sets(id) ON DELETE CASCADE,
    nameplate        TEXT NOT NULL,                     -- e.g. Silverado HD
    month_label      TEXT NOT NULL,                     -- e.g. 2026-07
    p10              NUMERIC(14,2),
    p50              NUMERIC(14,2),
    p90              NUMERIC(14,2),
    baseline         NUMERIC(14,2),
    consensus        NUMERIC(14,2),
    confidence       NUMERIC(4,3) CHECK (confidence BETWEEN 0 AND 1),
    owner            UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    freshness_at     TIMESTAMPTZ,
    comments_count   INTEGER NOT NULL DEFAULT 0,
    state            TEXT NOT NULL DEFAULT 'draft'
                         CHECK (state IN ('draft','updated','challenged',
                                          'committed','final','reviewed')),
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  number_objects                  IS 'Individual volume number for one nameplate × month within a forecast set.';
COMMENT ON COLUMN number_objects.id               IS 'UUID primary key.';
COMMENT ON COLUMN number_objects.forecast_set_id  IS 'Parent forecast set.';
COMMENT ON COLUMN number_objects.nameplate        IS 'Vehicle nameplate identifier.';
COMMENT ON COLUMN number_objects.month_label      IS 'ISO year-month label for the forecast period.';
COMMENT ON COLUMN number_objects.p10              IS '10th-percentile volume estimate.';
COMMENT ON COLUMN number_objects.p50              IS '50th-percentile (median) volume estimate.';
COMMENT ON COLUMN number_objects.p90              IS '90th-percentile volume estimate.';
COMMENT ON COLUMN number_objects.baseline         IS 'Statistical baseline before SME input.';
COMMENT ON COLUMN number_objects.consensus        IS 'Consensus value after collaborative review.';
COMMENT ON COLUMN number_objects.confidence       IS 'Submitter confidence in range 0–1.';
COMMENT ON COLUMN number_objects.freshness_at     IS 'Timestamp when underlying data was last refreshed.';
COMMENT ON COLUMN number_objects.comments_count   IS 'Denormalized count of threaded comments.';

CREATE TRIGGER trg_number_objects_updated_at
    BEFORE UPDATE ON number_objects
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- -----------------------------------------------------------------------------
-- 6. constraint_links
-- -----------------------------------------------------------------------------
CREATE TABLE constraint_links (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    number_object_id  UUID NOT NULL REFERENCES number_objects(id) ON DELETE CASCADE,
    constraint_type   TEXT NOT NULL CHECK (
                          constraint_type IN ('supplier','plant','inventory','policy')),
    constraint_id     TEXT NOT NULL,
    impact_severity   NUMERIC(4,3) CHECK (impact_severity BETWEEN 0 AND 1),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  constraint_links                  IS 'Links a number object to an external supply-chain or policy constraint.';
COMMENT ON COLUMN constraint_links.constraint_type  IS 'Type of constraint: supplier | plant | inventory | policy.';
COMMENT ON COLUMN constraint_links.constraint_id    IS 'Opaque ID of the constraint in the source system.';
COMMENT ON COLUMN constraint_links.impact_severity  IS 'Estimated fractional impact on volume (0–1).';

-- -----------------------------------------------------------------------------
-- 7. overrides
-- -----------------------------------------------------------------------------
CREATE TABLE overrides (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    number_object_id  UUID NOT NULL REFERENCES number_objects(id) ON DELETE CASCADE,
    actor_user_id     UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    reason_code       TEXT NOT NULL REFERENCES reason_codes(id) ON DELETE RESTRICT,
    new_value         NUMERIC(14,2) NOT NULL,
    new_p10           NUMERIC(14,2),
    new_p90           NUMERIC(14,2),
    confidence        NUMERIC(4,3) CHECK (confidence BETWEEN 0 AND 1),
    evidence_links    TEXT[],
    state             TEXT NOT NULL DEFAULT 'draft'
                          CHECK (state IN ('draft','staged','applied','dismissed')),
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    applied_at        TIMESTAMPTZ,
    dismissed_at      TIMESTAMPTZ,
    dismissal_reason  TEXT
);

COMMENT ON TABLE  overrides                  IS 'SME-submitted value overrides on number objects.';
COMMENT ON COLUMN overrides.actor_user_id    IS 'User who submitted the override.';
COMMENT ON COLUMN overrides.reason_code      IS 'FK to reason_codes — business justification.';
COMMENT ON COLUMN overrides.new_value        IS 'Proposed replacement consensus value.';
COMMENT ON COLUMN overrides.evidence_links   IS 'Array of URLs or document references supporting the override.';
COMMENT ON COLUMN overrides.state            IS 'Lifecycle: draft → staged → applied | dismissed.';
COMMENT ON COLUMN overrides.applied_at       IS 'Timestamp when state transitioned to applied.';
COMMENT ON COLUMN overrides.dismissed_at     IS 'Timestamp when state transitioned to dismissed.';
COMMENT ON COLUMN overrides.dismissal_reason IS 'Free-text reason for dismissal.';

-- -----------------------------------------------------------------------------
-- 8. challenges
-- -----------------------------------------------------------------------------
CREATE TABLE challenges (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    number_object_id    UUID NOT NULL REFERENCES number_objects(id) ON DELETE CASCADE,
    actor_user_id       UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    reason_code         TEXT NOT NULL REFERENCES reason_codes(id) ON DELETE RESTRICT,
    description         TEXT NOT NULL,
    evidence_links      TEXT[],
    state               TEXT NOT NULL DEFAULT 'open'
                            CHECK (state IN ('open','responded','resolved','dismissed')),
    recommended_value   NUMERIC(14,2),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at         TIMESTAMPTZ
);

COMMENT ON TABLE  challenges                    IS 'Formal challenges raised against a number object value.';
COMMENT ON COLUMN challenges.actor_user_id      IS 'User who raised the challenge.';
COMMENT ON COLUMN challenges.reason_code        IS 'FK to reason_codes — why the number is being challenged.';
COMMENT ON COLUMN challenges.recommended_value  IS 'Challenger''s suggested corrected value.';
COMMENT ON COLUMN challenges.state              IS 'Lifecycle: open → responded → resolved | dismissed.';

-- -----------------------------------------------------------------------------
-- 9. approvals
-- -----------------------------------------------------------------------------
CREATE TABLE approvals (
    id               UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_set_id  UUID NOT NULL REFERENCES forecast_sets(id) ON DELETE CASCADE,
    scenario_id      UUID REFERENCES scenarios(id) ON DELETE SET NULL,
    actor_user_id    UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    action           TEXT NOT NULL CHECK (action IN ('promote','reject','defer')),
    exec_brief_id    TEXT,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  approvals                   IS 'Leadership approval actions on forecast sets.';
COMMENT ON COLUMN approvals.actor_user_id     IS 'Leadership user performing the action.';
COMMENT ON COLUMN approvals.action            IS 'promote | reject | defer.';
COMMENT ON COLUMN approvals.exec_brief_id     IS 'Opaque reference to the executive brief document presented.';

-- -----------------------------------------------------------------------------
-- 10. hibt_entries  (replay-prompt-ledger, partitioned by month)
-- -----------------------------------------------------------------------------
CREATE TABLE hibt_entries (
    id                    UUID NOT NULL DEFAULT gen_random_uuid(),
    actor                 TEXT NOT NULL,          -- user_id or agent_id (text for flexibility)
    surface               TEXT NOT NULL,
    action_type           TEXT NOT NULL,
    payload               JSONB NOT NULL DEFAULT '{}',
    prompt_sha            TEXT,                   -- SHA-256 of prompt for agent actions
    source_sha            TEXT,                   -- SHA of source data at time of action
    model_version         TEXT,
    reproducibility_hash  TEXT,
    outcome               TEXT,
    parent_entry_id       UUID,                   -- self-referential chain (FK defined below)
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW()
) PARTITION BY RANGE (created_at);

COMMENT ON TABLE  hibt_entries                       IS 'Immutable replay-prompt-ledger. Every human and agent action is appended here. Partitioned monthly.';
COMMENT ON COLUMN hibt_entries.actor                 IS 'User UUID or agent string ID of the acting principal.';
COMMENT ON COLUMN hibt_entries.surface               IS 'UI or API surface that generated the event.';
COMMENT ON COLUMN hibt_entries.action_type           IS 'Semantic action label, e.g. override_submitted.';
COMMENT ON COLUMN hibt_entries.payload               IS 'Full event payload as JSONB.';
COMMENT ON COLUMN hibt_entries.prompt_sha            IS 'SHA-256 of the agent prompt used, enabling replay.';
COMMENT ON COLUMN hibt_entries.source_sha            IS 'SHA of upstream data snapshot at action time.';
COMMENT ON COLUMN hibt_entries.reproducibility_hash  IS 'Composite hash enabling deterministic replay.';
COMMENT ON COLUMN hibt_entries.outcome               IS 'Observed outcome after action, populated async.';
COMMENT ON COLUMN hibt_entries.parent_entry_id       IS 'FK to parent ledger entry for chained actions.';

-- Default partition to catch unpartitioned writes during dev
CREATE TABLE IF NOT EXISTS hibt_entries_default
    PARTITION OF hibt_entries DEFAULT;

-- Pre-create monthly partitions for 2026
CREATE TABLE IF NOT EXISTS hibt_entries_2026_01 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-01-01') TO ('2026-02-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_02 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-02-01') TO ('2026-03-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_03 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-03-01') TO ('2026-04-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_04 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-04-01') TO ('2026-05-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_05 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-05-01') TO ('2026-06-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_06 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-06-01') TO ('2026-07-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_07 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-07-01') TO ('2026-08-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_08 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-08-01') TO ('2026-09-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_09 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-09-01') TO ('2026-10-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_10 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-10-01') TO ('2026-11-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_11 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-11-01') TO ('2026-12-01');
CREATE TABLE IF NOT EXISTS hibt_entries_2026_12 PARTITION OF hibt_entries
    FOR VALUES FROM ('2026-12-01') TO ('2027-01-01');

-- Composite PK on partitioned table
ALTER TABLE hibt_entries ADD PRIMARY KEY (id, created_at);

-- Self-referential FK cannot be deferred across partitions in PG15, store as plain column
-- (parent_entry_id references id conceptually; enforced at app layer)

-- HIBT immutability trigger
CREATE OR REPLACE FUNCTION deny_hibt_mutation()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
BEGIN
    RAISE EXCEPTION 'hibt_entries is immutable — UPDATE and DELETE are forbidden.';
END;
$$;

CREATE TRIGGER trg_hibt_no_update
    BEFORE UPDATE ON hibt_entries
    FOR EACH ROW EXECUTE FUNCTION deny_hibt_mutation();

CREATE TRIGGER trg_hibt_no_delete
    BEFORE DELETE ON hibt_entries
    FOR EACH ROW EXECUTE FUNCTION deny_hibt_mutation();

-- -----------------------------------------------------------------------------
-- 11. agents
-- -----------------------------------------------------------------------------
CREATE TABLE agents (
    id                TEXT PRIMARY KEY,            -- e.g. workbench-anomaly
    version           TEXT NOT NULL,
    status            TEXT NOT NULL DEFAULT 'canary'
                          CHECK (status IN ('canary','promoted','rolled-back')),
    eval_score        NUMERIC(5,4),
    last_evaluated_at TIMESTAMPTZ,
    owner_team        TEXT NOT NULL,
    nama_certified    BOOLEAN NOT NULL DEFAULT FALSE,
    seat_assignments   TEXT[]
);

COMMENT ON TABLE  agents                   IS 'Registry of Pit Wall AI agents.';
COMMENT ON COLUMN agents.id               IS 'Stable slug identifier, e.g. workbench-anomaly.';
COMMENT ON COLUMN agents.version          IS 'Semantic version of the deployed agent.';
COMMENT ON COLUMN agents.status           IS 'Deployment status: canary | promoted | rolled-back.';
COMMENT ON COLUMN agents.eval_score       IS 'Latest evaluation score (0–1).';
COMMENT ON COLUMN agents.nama_certified   IS 'TRUE when agent has passed NAMA certification gate.';
COMMENT ON COLUMN agents.seat_assignments IS 'Array of forecast_set IDs or nameplate slugs this agent monitors.';

-- -----------------------------------------------------------------------------
-- 12. agent_promotions
-- -----------------------------------------------------------------------------
CREATE TABLE agent_promotions (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    agent_id            TEXT NOT NULL REFERENCES agents(id) ON DELETE CASCADE,
    from_version        TEXT NOT NULL,
    to_version          TEXT NOT NULL,
    eval_scores         JSONB NOT NULL DEFAULT '{}',
    promoted_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    status              TEXT NOT NULL DEFAULT 'canary'
                            CHECK (status IN ('canary','promoted','rolled-back')),
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    promoted_at         TIMESTAMPTZ,
    rolled_back_at      TIMESTAMPTZ,
    rollback_reason     TEXT
);

COMMENT ON TABLE  agent_promotions                      IS 'Audit trail of agent version promotions and rollbacks.';
COMMENT ON COLUMN agent_promotions.eval_scores          IS 'JSONB snapshot of evaluation metrics at time of promotion.';
COMMENT ON COLUMN agent_promotions.promoted_by_user_id  IS 'Human approver who executed the promotion.';
COMMENT ON COLUMN agent_promotions.rollback_reason      IS 'Free-text reason if status transitions to rolled-back.';

-- =============================================================================
-- v3.0 ADDITION TABLES
-- =============================================================================

-- -----------------------------------------------------------------------------
-- 13. second_opinion_runs
-- -----------------------------------------------------------------------------
CREATE TABLE second_opinion_runs (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_set_id       UUID NOT NULL REFERENCES forecast_sets(id) ON DELETE CASCADE,
    trigger               TEXT NOT NULL,
    triggered_by_user_id  UUID REFERENCES users(id) ON DELETE SET NULL,
    prompt_pack           TEXT,
    prompt_pack_hash      TEXT,
    primary_value         NUMERIC(14,2),
    primary_p10           NUMERIC(14,2),
    primary_p90           NUMERIC(14,2),
    second_value          NUMERIC(14,2),
    second_p10            NUMERIC(14,2),
    second_p90            NUMERIC(14,2),
    mds                   NUMERIC(6,4),            -- Model Disagreement Score
    mds_components        JSONB NOT NULL DEFAULT '{}',
    source_overlap_pct    NUMERIC(5,2),
    cost_usd              NUMERIC(10,6),
    latency_ms            INTEGER,
    status                TEXT NOT NULL DEFAULT 'pending'
                              CHECK (status IN ('pending','running','complete','failed','dismissed')),
    failure_reason        TEXT,
    challenge_id          UUID REFERENCES challenges(id) ON DELETE SET NULL,
    rationale             TEXT,
    hibt_entry_id         UUID,                    -- logical FK to hibt_entries
    created_at            TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    completed_at          TIMESTAMPTZ
);

COMMENT ON TABLE  second_opinion_runs                      IS 'Records of Second-Opinion agent runs triggered on number objects.';
COMMENT ON COLUMN second_opinion_runs.trigger              IS 'What initiated the run: auto_mds | human_request | challenge_linked.';
COMMENT ON COLUMN second_opinion_runs.prompt_pack          IS 'Name of the prompt pack used by the second-opinion agent.';
COMMENT ON COLUMN second_opinion_runs.prompt_pack_hash     IS 'SHA-256 of the prompt pack for reproducibility.';
COMMENT ON COLUMN second_opinion_runs.mds                  IS 'Composite Model Disagreement Score (0–1).';
COMMENT ON COLUMN second_opinion_runs.mds_components       IS 'Breakdown of MDS sub-factors as JSONB.';
COMMENT ON COLUMN second_opinion_runs.source_overlap_pct   IS 'Percentage overlap of data sources between primary and second model.';
COMMENT ON COLUMN second_opinion_runs.hibt_entry_id        IS 'Logical reference to the HIBT ledger entry for this run.';

-- -----------------------------------------------------------------------------
-- 14. disagreement_scores
-- -----------------------------------------------------------------------------
CREATE TABLE disagreement_scores (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id          UUID NOT NULL REFERENCES second_opinion_runs(id) ON DELETE CASCADE,
    factor          TEXT NOT NULL,
    category        TEXT NOT NULL,
    weight          NUMERIC(5,4),
    evidence_links  TEXT[],
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  disagreement_scores             IS 'Per-factor MDS breakdown for a second-opinion run.';
COMMENT ON COLUMN disagreement_scores.factor      IS 'Name of the disagreement factor, e.g. seasonality_lag.';
COMMENT ON COLUMN disagreement_scores.category    IS 'Grouping category for the factor.';
COMMENT ON COLUMN disagreement_scores.weight      IS 'Weight of this factor in the composite MDS.';

-- -----------------------------------------------------------------------------
-- 15. so_dismissals
-- -----------------------------------------------------------------------------
CREATE TABLE so_dismissals (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    run_id               UUID NOT NULL REFERENCES second_opinion_runs(id) ON DELETE CASCADE,
    dismissed_by_user_id UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    reason_code          TEXT NOT NULL CHECK (reason_code IN ('DISM-1','DISM-2','DISM-3')),
    note                 TEXT,
    hibt_entry_id        UUID,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  so_dismissals                      IS 'Records human dismissal of a second-opinion run result.';
COMMENT ON COLUMN so_dismissals.reason_code          IS 'Controlled dismissal code: DISM-1 data stale | DISM-2 model mismatch | DISM-3 deliberate override.';
COMMENT ON COLUMN so_dismissals.hibt_entry_id        IS 'Logical reference to HIBT ledger entry for audit.';

-- -----------------------------------------------------------------------------
-- 16. ghost_lap_projections
-- -----------------------------------------------------------------------------
CREATE TABLE ghost_lap_projections (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    forecast_set_id   UUID NOT NULL REFERENCES forecast_sets(id) ON DELETE CASCADE,
    current_cycle_id  TEXT NOT NULL,
    prior_cycle_offset INTEGER NOT NULL DEFAULT 1,
    prior_cycle_id    TEXT NOT NULL,
    baseline_series   NUMERIC[],
    consensus_series  NUMERIC[],
    p10_series        NUMERIC[],
    p90_series        NUMERIC[],
    actual_series     NUMERIC[],
    committed_value   NUMERIC(14,2),
    actual_at_horizon NUMERIC(14,2),
    mape_current      NUMERIC(8,6),
    mape_prior        NUMERIC(8,6),
    computed_at       TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    ttl_seconds       INTEGER NOT NULL DEFAULT 86400,
    hibt_lineage_id   UUID
);

COMMENT ON TABLE  ghost_lap_projections                    IS 'Side-by-side trajectory overlays of current vs prior forecast cycles.';
COMMENT ON COLUMN ghost_lap_projections.prior_cycle_offset IS 'How many cycles back the ghost represents (default 1 = last cycle).';
COMMENT ON COLUMN ghost_lap_projections.mape_current       IS 'Mean Absolute Percentage Error for the current cycle trajectory.';
COMMENT ON COLUMN ghost_lap_projections.mape_prior         IS 'MAPE for the prior (ghost) cycle.';
COMMENT ON COLUMN ghost_lap_projections.ttl_seconds        IS 'Cache TTL in seconds; projection should be recomputed when expired.';
COMMENT ON COLUMN ghost_lap_projections.hibt_lineage_id    IS 'Logical reference to HIBT entry that triggered computation.';

-- -----------------------------------------------------------------------------
-- 17. recurring_challenges
-- -----------------------------------------------------------------------------
CREATE TABLE recurring_challenges (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    sme_user_id         UUID NOT NULL REFERENCES users(id) ON DELETE RESTRICT,
    reason_code         TEXT NOT NULL REFERENCES reason_codes(id) ON DELETE RESTRICT,
    nameplate           TEXT NOT NULL,
    cycles_open         INTEGER NOT NULL DEFAULT 1,
    first_raised_cycle  TEXT NOT NULL,
    last_raised_cycle   TEXT NOT NULL,
    last_resolution     TEXT,
    status              TEXT NOT NULL DEFAULT 'open'
                            CHECK (status IN ('open','monitoring','resolved')),
    detected_at         TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    resolved_at         TIMESTAMPTZ
);

COMMENT ON TABLE  recurring_challenges                   IS 'Tracks SMEs who repeatedly challenge the same nameplate for the same reason code across cycles.';
COMMENT ON COLUMN recurring_challenges.cycles_open       IS 'Count of consecutive cycles this challenge pattern has appeared.';
COMMENT ON COLUMN recurring_challenges.first_raised_cycle IS 'Cycle label when the pattern was first detected.';
COMMENT ON COLUMN recurring_challenges.last_resolution   IS 'Description or outcome of the most recent resolution attempt.';

-- -----------------------------------------------------------------------------
-- 18. override_outcomes
-- -----------------------------------------------------------------------------
CREATE TABLE override_outcomes (
    id                        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    override_id               UUID NOT NULL REFERENCES overrides(id) ON DELETE CASCADE,
    similar_prior_override_id UUID REFERENCES overrides(id) ON DELETE SET NULL,
    similarity_score          NUMERIC(4,3),
    outcome                   TEXT NOT NULL CHECK (outcome IN ('correct','overruled','cycled','dismissed')),
    mape_with_override        NUMERIC(8,6),
    mape_without_override     NUMERIC(8,6),
    value_add_pts             NUMERIC(8,4),
    finalized_at              TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  override_outcomes                             IS 'Post-hoc evaluation of override accuracy relative to actuals.';
COMMENT ON COLUMN override_outcomes.similar_prior_override_id  IS 'FK to the most similar historical override used as a benchmark.';
COMMENT ON COLUMN override_outcomes.similarity_score           IS 'Cosine or Jaccard similarity to the prior override (0–1).';
COMMENT ON COLUMN override_outcomes.value_add_pts              IS 'MAPE improvement points attributable to this override.';

-- -----------------------------------------------------------------------------
-- 19. championship_seasons
-- -----------------------------------------------------------------------------
CREATE TABLE championship_seasons (
    id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    season_type  TEXT NOT NULL CHECK (season_type IN ('monthly','quarterly')),
    opens_at     TIMESTAMPTZ NOT NULL,
    closes_at    TIMESTAMPTZ NOT NULL,
    closed_at    TIMESTAMPTZ,
    podium       JSONB NOT NULL DEFAULT '[]',    -- [{rank, user_id, score}, ...]
    created_at   TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT   chk_season_dates CHECK (closes_at > opens_at)
);

COMMENT ON TABLE  championship_seasons             IS 'Defines scoring seasons for the Championship Table (monthly or quarterly).';
COMMENT ON COLUMN championship_seasons.podium      IS 'JSONB snapshot of top-3 podium once the season closes.';
COMMENT ON COLUMN championship_seasons.closed_at   IS 'Actual close timestamp; NULL while season is active.';

-- -----------------------------------------------------------------------------
-- 20. championship_scores
-- -----------------------------------------------------------------------------
CREATE TABLE championship_scores (
    id                   UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id              UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    league               TEXT NOT NULL,
    season_id            UUID NOT NULL REFERENCES championship_seasons(id) ON DELETE CASCADE,
    raw_score            NUMERIC(10,4) NOT NULL DEFAULT 0,
    rank                 INTEGER,
    quartile             INTEGER CHECK (quartile BETWEEN 1 AND 4),
    contribution_count   INTEGER NOT NULL DEFAULT 0,
    qualified            BOOLEAN NOT NULL DEFAULT FALSE,
    computed_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    hibt_replay_id       UUID
);

COMMENT ON TABLE  championship_scores                    IS 'Per-user rolling championship scores within a season and league.';
COMMENT ON COLUMN championship_scores.league             IS 'Segmentation league, e.g. sme_trucks | analyst_global.';
COMMENT ON COLUMN championship_scores.raw_score          IS 'Unranked points total for the user in this season.';
COMMENT ON COLUMN championship_scores.quartile           IS 'Rank quartile 1–4 within the league.';
COMMENT ON COLUMN championship_scores.qualified          IS 'TRUE when user meets minimum contribution threshold.';
COMMENT ON COLUMN championship_scores.hibt_replay_id     IS 'HIBT entry that last triggered a score recomputation.';

-- -----------------------------------------------------------------------------
-- 21. lap_claps
-- -----------------------------------------------------------------------------
CREATE TABLE lap_claps (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    giver_user_id       UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    recipient_user_id   UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    target_type         TEXT NOT NULL CHECK (target_type IN ('override','challenge','agent_improvement')),
    target_id           UUID NOT NULL,
    season_id           UUID NOT NULL REFERENCES championship_seasons(id) ON DELETE CASCADE,
    note                TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    CONSTRAINT chk_clap_no_self CHECK (giver_user_id <> recipient_user_id)
);

COMMENT ON TABLE  lap_claps                     IS 'Peer recognition claps for quality contributions. Capped at 5 given / 20 received per user per season.';
COMMENT ON COLUMN lap_claps.target_type         IS 'Entity type being recognised: override | challenge | agent_improvement.';
COMMENT ON COLUMN lap_claps.target_id           IS 'UUID of the specific override, challenge, or agent_promotion being clapped.';

-- Cap-enforcement trigger function
CREATE OR REPLACE FUNCTION enforce_clap_caps()
RETURNS TRIGGER LANGUAGE plpgsql AS $$
DECLARE
    given_count    INTEGER;
    received_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO given_count
    FROM lap_claps
    WHERE giver_user_id = NEW.giver_user_id
      AND season_id     = NEW.season_id;

    IF given_count >= 5 THEN
        RAISE EXCEPTION 'Clap cap exceeded: user % has already given 5 claps in season %.', NEW.giver_user_id, NEW.season_id;
    END IF;

    SELECT COUNT(*) INTO received_count
    FROM lap_claps
    WHERE recipient_user_id = NEW.recipient_user_id
      AND season_id         = NEW.season_id;

    IF received_count >= 20 THEN
        RAISE EXCEPTION 'Clap cap exceeded: user % has already received 20 claps in season %.', NEW.recipient_user_id, NEW.season_id;
    END IF;

    RETURN NEW;
END;
$$;

CREATE TRIGGER trg_lap_claps_cap
    BEFORE INSERT ON lap_claps
    FOR EACH ROW EXECUTE FUNCTION enforce_clap_caps();

-- -----------------------------------------------------------------------------
-- 22. visibility_preferences
-- -----------------------------------------------------------------------------
CREATE TABLE visibility_preferences (
    user_id              UUID PRIMARY KEY REFERENCES users(id) ON DELETE CASCADE,
    championship_public  BOOLEAN NOT NULL DEFAULT TRUE,
    ghost_lap_default    TEXT NOT NULL DEFAULT 'all'
                             CHECK (ghost_lap_default IN ('all','team','private')),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

COMMENT ON TABLE  visibility_preferences                      IS 'Per-user privacy preferences for Championship Table and Ghost Lap surfaces.';
COMMENT ON COLUMN visibility_preferences.championship_public  IS 'TRUE = score visible to all users.';
COMMENT ON COLUMN visibility_preferences.ghost_lap_default    IS 'Default Ghost Lap visibility: all | team | private.';

CREATE TRIGGER trg_visibility_preferences_updated_at
    BEFORE UPDATE ON visibility_preferences
    FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- =============================================================================
-- INDEXES
-- =============================================================================

-- users
CREATE INDEX idx_users_role         ON users(role);
CREATE INDEX idx_users_team         ON users(team);
CREATE INDEX idx_users_on_call      ON users(on_call) WHERE on_call = TRUE;

-- forecast_sets
CREATE INDEX idx_fs_owner           ON forecast_sets(owner);
CREATE INDEX idx_fs_state           ON forecast_sets(state);
CREATE INDEX idx_fs_por_status      ON forecast_sets(por_status) WHERE por_status = TRUE;
CREATE INDEX idx_fs_horizon         ON forecast_sets(horizon);
CREATE INDEX idx_fs_soft_delete     ON forecast_sets(soft_delete) WHERE soft_delete = FALSE;

-- scenarios
CREATE INDEX idx_scenarios_fset     ON scenarios(forecast_set_id);
CREATE INDEX idx_scenarios_state    ON scenarios(compare_state);

-- number_objects
CREATE INDEX idx_no_fset            ON number_objects(forecast_set_id);
CREATE INDEX idx_no_nameplate       ON number_objects(nameplate);
CREATE INDEX idx_no_month           ON number_objects(month_label);
CREATE INDEX idx_no_owner           ON number_objects(owner);
CREATE INDEX idx_no_state           ON number_objects(state);
CREATE INDEX idx_no_nameplate_month ON number_objects(nameplate, month_label);

-- constraint_links
CREATE INDEX idx_cl_no_id           ON constraint_links(number_object_id);
CREATE INDEX idx_cl_type            ON constraint_links(constraint_type);

-- overrides
CREATE INDEX idx_ov_no_id           ON overrides(number_object_id);
CREATE INDEX idx_ov_actor           ON overrides(actor_user_id);
CREATE INDEX idx_ov_state           ON overrides(state);
CREATE INDEX idx_ov_reason          ON overrides(reason_code);

-- challenges
CREATE INDEX idx_ch_no_id           ON challenges(number_object_id);
CREATE INDEX idx_ch_actor           ON challenges(actor_user_id);
CREATE INDEX idx_ch_state           ON challenges(state);
CREATE INDEX idx_ch_reason          ON challenges(reason_code);

-- approvals
CREATE INDEX idx_ap_fset            ON approvals(forecast_set_id);
CREATE INDEX idx_ap_actor           ON approvals(actor_user_id);
CREATE INDEX idx_ap_action          ON approvals(action);

-- reason_codes
CREATE INDEX idx_rc_category        ON reason_codes(category);
CREATE INDEX idx_rc_active          ON reason_codes(active) WHERE active = TRUE;

-- hibt_entries (indexes on all partitions via parent)
CREATE INDEX idx_hibt_actor         ON hibt_entries(actor);
CREATE INDEX idx_hibt_surface       ON hibt_entries(surface);
CREATE INDEX idx_hibt_action_type   ON hibt_entries(action_type);
CREATE INDEX idx_hibt_created_at    ON hibt_entries(created_at);
CREATE INDEX idx_hibt_parent        ON hibt_entries(parent_entry_id);

-- agents
CREATE INDEX idx_agents_status          ON agents(status);
CREATE INDEX idx_agents_nama_certified  ON agents(nama_certified) WHERE nama_certified = TRUE;

-- agent_promotions
CREATE INDEX idx_ap_agent_id        ON agent_promotions(agent_id);
CREATE INDEX idx_ap_status          ON agent_promotions(status);
CREATE INDEX idx_ap_promoted_by     ON agent_promotions(promoted_by_user_id);

-- second_opinion_runs
CREATE INDEX idx_so_fset            ON second_opinion_runs(forecast_set_id);
CREATE INDEX idx_so_status          ON second_opinion_runs(status);
CREATE INDEX idx_so_trigger         ON second_opinion_runs(trigger);
CREATE INDEX idx_so_challenge       ON second_opinion_runs(challenge_id);
CREATE INDEX idx_so_mds             ON second_opinion_runs(mds);

-- disagreement_scores
CREATE INDEX idx_ds_run_id          ON disagreement_scores(run_id);
CREATE INDEX idx_ds_category        ON disagreement_scores(category);

-- so_dismissals
CREATE INDEX idx_sodism_run_id      ON so_dismissals(run_id);
CREATE INDEX idx_sodism_user        ON so_dismissals(dismissed_by_user_id);

-- ghost_lap_projections
CREATE INDEX idx_glp_fset           ON ghost_lap_projections(forecast_set_id);
CREATE INDEX idx_glp_cycle          ON ghost_lap_projections(current_cycle_id);
CREATE INDEX idx_glp_computed_at    ON ghost_lap_projections(computed_at);

-- recurring_challenges
CREATE INDEX idx_rc_sme             ON recurring_challenges(sme_user_id);
CREATE INDEX idx_rc_nameplate       ON recurring_challenges(nameplate);
CREATE INDEX idx_rc_status          ON recurring_challenges(status);

-- override_outcomes
CREATE INDEX idx_oo_override        ON override_outcomes(override_id);
CREATE INDEX idx_oo_outcome         ON override_outcomes(outcome);

-- championship_seasons
CREATE INDEX idx_cs_type            ON championship_seasons(season_type);
CREATE INDEX idx_cs_opens_at        ON championship_seasons(opens_at);

-- championship_scores
CREATE INDEX idx_csc_user_season    ON championship_scores(user_id, season_id);
CREATE INDEX idx_csc_league         ON championship_scores(league);
CREATE INDEX idx_csc_rank           ON championship_scores(rank);

-- lap_claps
CREATE INDEX idx_lc_giver_season    ON lap_claps(giver_user_id, season_id);
CREATE INDEX idx_lc_recipient_season ON lap_claps(recipient_user_id, season_id);
CREATE INDEX idx_lc_target          ON lap_claps(target_type, target_id);

-- =============================================================================
-- SEED DATA
-- =============================================================================

-- -----------------------------------------------------------------------------
-- Users (6)
-- -----------------------------------------------------------------------------
INSERT INTO users (id, name, email, role, team, on_call) VALUES
    ('a1000000-0000-0000-0000-000000000001', 'Ramzi Al-Farsi',      'ramzi.alfarsi@nama.example',    'leadership', 'NA Trucks Leadership',    FALSE),
    ('a1000000-0000-0000-0000-000000000002', 'Krisztina Varga',     'krisztina.varga@nama.example',  'analyst',    'Demand Intelligence',      TRUE),
    ('a1000000-0000-0000-0000-000000000003', 'Jim Kowalski',        'jim.kowalski@nama.example',     'sme',        'NA Full-Size Trucks SME',  TRUE),
    ('a1000000-0000-0000-0000-000000000004', 'Govinda Rajan',       'govinda.rajan@nama.example',    'ops',        'Pit Wall Ops',             FALSE),
    ('a1000000-0000-0000-0000-000000000005', 'Mansoor Al-Rashidi',  'mansoor.alrashidi@nama.example','govops',     'Governance & Compliance',  FALSE),
    ('a1000000-0000-0000-0000-000000000006', 'Don Ehrlich',         'don.ehrlich@nama.example',      'analyst',    'Competitive Intelligence',  FALSE);

-- -----------------------------------------------------------------------------
-- Reason codes (5)
-- -----------------------------------------------------------------------------
INSERT INTO reason_codes (id, name, category, description, active) VALUES
    ('R-04', 'Inventory Correction',   'inventory',    'Adjustment for excess or depleted dealer stock.', TRUE),
    ('R-09', 'Tariff / Trade Policy',  'tariff',       'Impact from announced or anticipated tariff changes.', TRUE),
    ('R-12', 'Incentive Adjustment',   'incentive',    'Customer cash or financing program effect on retail demand.', TRUE),
    ('R-18', 'Competitive Action',     'competitive',  'Competitive model launch, price action, or supply event.', TRUE),
    ('R-21', 'Dealer Pulse',           'dealer',       'Ground-level dealer sell-down or order pattern signal.', TRUE);

-- -----------------------------------------------------------------------------
-- Forecast set: FS-2026Q3-NA-TRK-001
-- -----------------------------------------------------------------------------
INSERT INTO forecast_sets
    (id, name, horizon, model_version, owner, state, por_status)
VALUES
    ('b2000000-0000-0000-0000-000000000001',
     'FS-2026Q3-NA-TRK-001 · U.S. Full-Size Trucks · Q3 2026',
     'Q3 2026',
     'NADT-v4.2.1',
     'a1000000-0000-0000-0000-000000000002',
     'draft',
     FALSE);

-- -----------------------------------------------------------------------------
-- Number object: Silverado HD Q3 2026 = 87,400
-- -----------------------------------------------------------------------------
INSERT INTO number_objects
    (id, forecast_set_id, nameplate, month_label, p50, p10, p90, baseline, consensus, confidence, owner, state)
VALUES
    ('c3000000-0000-0000-0000-000000000001',
     'b2000000-0000-0000-0000-000000000001',
     'Silverado HD',
     '2026-Q3',
     87400,
     81000,
     93500,
     84200,
     87400,
     0.720,
     'a1000000-0000-0000-0000-000000000003',
     'draft');

-- -----------------------------------------------------------------------------
-- Agents (7, all NAMA-certified)
-- -----------------------------------------------------------------------------
INSERT INTO agents (id, version, status, eval_score, last_evaluated_at, owner_team, nama_certified, seat_assignments) VALUES
    ('workbench-anomaly',        '2.1.0', 'promoted',   0.9410, NOW() - INTERVAL '3 days',  'Demand Intelligence',   TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('second-opinion',           '3.0.2', 'promoted',   0.9200, NOW() - INTERVAL '1 day',   'Demand Intelligence',   TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('ghost-lap',                '3.0.1', 'promoted',   0.9350, NOW() - INTERVAL '2 days',  'Demand Intelligence',   TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('exec-brief-composer',      '2.4.0', 'promoted',   0.9050, NOW() - INTERVAL '5 days',  'Leadership Services',   TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('challenge-pattern-scout',  '1.2.3', 'canary',     0.8790, NOW() - INTERVAL '1 day',   'Governance',            TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('override-outcome-scorer',  '1.5.0', 'promoted',   0.9150, NOW() - INTERVAL '4 days',  'Demand Intelligence',   TRUE, ARRAY['FS-2026Q3-NA-TRK-001']),
    ('championship-ledger',      '3.0.0', 'promoted',   0.9600, NOW() - INTERVAL '2 days',  'Pit Wall Ops',          TRUE, ARRAY['global']);

-- =============================================================================
-- END OF SCHEMA
-- =============================================================================
