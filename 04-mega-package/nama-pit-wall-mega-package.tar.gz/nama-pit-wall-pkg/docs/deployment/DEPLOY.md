# Deployment

**Audience:** Engineering team deploying the Pit Wall to dev / staging / prod.
**Owner:** Mansoor Alghooneh + Govinda Chaluvadi.

## Environments

| Env | Cluster | Database | LLM access |
|-----|---------|----------|-----------|
| **dev** | k8s `pw-dev` | Postgres (managed) | Mock LLM via fixtures |
| **staging** | k8s `pw-staging` | Postgres (managed) | Real LLM, synthetic forecast data |
| **canary** | k8s `pw-prod-canary` | Databricks read-replica + Postgres | Real LLM, 10% prod traffic |
| **prod** | k8s `pw-prod` | Databricks Lakehouse + Unity Catalog | Real LLM, full traffic |

## First-time setup (dev)

```bash
# 1. Clone the package
git clone <repo-url> nama-pit-wall && cd nama-pit-wall

# 2. Bring up Postgres locally
docker run -d --name pw-postgres -p 5432:5432 -e POSTGRES_PASSWORD=dev postgres:15

# 3. Apply the schema
psql -h localhost -U postgres -d postgres -f docs/schema/schema.sql

# 4. Install + run frontend
cd src && npm install && npm run dev
```

Visit `http://localhost:5173`. The five-seat picker should appear.

## Production rollout

We use **kubectl + Helm** in production. Chart at `infra/helm/pitwall/`.

```bash
# Canary deploy
helm upgrade --install pitwall-api \
  oci://registry.nama-internal/charts/pitwall \
  --version 2.4.0 \
  --namespace pw-prod-canary \
  --set image.tag=2.4.0 \
  --set replicaCount=2 \
  --set features.secondOpinion=false \
  --set features.ghostLap=false \
  --set features.championship=false

# After 24h canary holds, promote to prod
helm upgrade pitwall-api \
  oci://registry.nama-internal/charts/pitwall \
  --version 2.4.0 \
  --namespace pw-prod \
  --set replicaCount=3
```

## Feature flags

`pw.second-opinion`, `pw.ghost-lap`, `pw.championship` — all default OFF until v3.0 phase rollouts. See `ROADMAP.md` for the staggered GA timeline.

**Kill switch SLA:** 60 seconds. Operationally tested quarterly.

## Required secrets

| Secret | Where | Notes |
|--------|-------|-------|
| `LLM_API_KEY_PRIMARY` | Vault | OpenAI key for primary agents |
| `LLM_API_KEY_SECONDARY` | Vault | Anthropic key for Second-Opinion |
| `LITELLM_BASE_URL` | env | LLM gateway |
| `PG_CONN_STRING` | Vault | Postgres (dev/staging); Databricks token in prod |
| `JWT_SIGNING_KEY` | Vault | API auth |
| `HIBT_WRITE_TOKEN` | Vault | HIBT ledger writes |
| `SLACK_BOT_TOKEN` | Vault | Hand-off radio Teams/Slack notifications |

## Capacity (v2.4 sizing)

| Resource | Count | Notes |
|----------|-------|-------|
| pitwall-api pods | 3 (prod), 2 (canary) | 1 vCPU, 2 GB each |
| Postgres replicas | 2 (read), 1 (write) | Plus 3rd read for v3.0 champ-svc |
| Redis | 8 GB working set | +16 GB for v3.0 (ghost-lap cache + champ leaderboard) |
| LLM QPS allocation | 12/s | +6/s for v3.0 Second-Opinion |
| Databricks job slots | 4 nightly | +2 for v3.0 precompute jobs |

## Observability

Four Grafana dashboards. Templates in `docs/observability/dashboards/`:

- `pitwall-api` — Layer C metrics
- `agent-fleet` — Per-agent eval scores, drift, cost, latency
- `forecast-health` — MAPE, override value-add, challenge resolution
- `v3-rollup` — Feature-flag state, cost budget utilization

Alerts to PagerDuty + Slack `#nama-pit-wall-ops`. P1 conditions (privacy leakage, replay determinism failure, kill-switch trigger) page on-call.

## Runbook stubs

- `docs/runbooks/budget_breach.md` — Per-seat budget exceeded
- `docs/runbooks/latency_spike.md` — p95 latency breach
- `docs/runbooks/replay_drift.md` — Replay determinism < 98%
- `docs/runbooks/calibration_drift.md` — SME-confirmation rate drops

## Rollback

Rollback dimensions ordered by speed:

1. **Feature flag off** (≤60s) — stop new invocations
2. **Service drain + previous image redeploy** (≤5min) — `helm rollback pitwall-api`
3. **Prompt pack rollback** (≤2min) — env var switch to previous pack version
4. **Schema rollback** (manual, rare) — v3.0 tables are additive; safe to drop

## Pre-flight checklist before any v3.0 phase transition

- [ ] All 5 eval gate categories green for 7 days
- [ ] Cost ≤ target sustained 7 days
- [ ] SLO burn rate < 10% of error budget
- [ ] Runbook reviewed by on-call this quarter
- [ ] Feature flag tested OFF→ON→OFF cycle in canary
- [ ] GovOps signoff (Don S.)
- [ ] Sponsor brief sent at least 48h prior
