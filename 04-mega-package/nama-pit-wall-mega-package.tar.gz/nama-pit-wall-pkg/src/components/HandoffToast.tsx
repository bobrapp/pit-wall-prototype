import { useEffect } from 'react';

interface Props {
  from: string;
  to: string;
  completed: string;
  next: string;
  show: boolean;
  onDismiss: () => void;
}

/**
 * Pit-to-driver radio toast. Slides in from the top during baton-pass
 * transitions in the race flow. Auto-dismiss after 4.5s; click × to close.
 */
export function HandoffToast({ from, to, completed, next, show, onDismiss }: Props) {
  useEffect(() => {
    if (!show) return;
    const t = setTimeout(onDismiss, 4500);
    return () => clearTimeout(t);
  }, [show, onDismiss]);

  return (
    <div
      role="status"
      aria-live="polite"
      style={{
        position: 'fixed',
        top: 128,
        left: '50%',
        transform: `translateX(-50%) translateY(${show ? 0 : -18}px)`,
        zIndex: 200,
        width: 'min(660px, 92vw)',
        padding: '20px 24px 18px',
        borderRadius: 14,
        background: 'rgba(8,10,14,0.97)',
        border: '1px solid var(--f1-amber)',
        boxShadow: `0 0 0 1px var(--f1-amber), 0 30px 80px rgba(0,0,0,0.55), 0 0 60px rgba(255,107,0,0.18)`,
        opacity: show ? 1 : 0,
        pointerEvents: show ? 'auto' : 'none',
        transition: 'opacity 0.35s ease, transform 0.35s ease',
        backdropFilter: 'blur(20px)',
      }}
    >
      <button
        onClick={onDismiss}
        aria-label="dismiss"
        style={{
          position: 'absolute',
          top: 14,
          right: 14,
          width: 26,
          height: 26,
          borderRadius: '50%',
          background: 'rgba(255,255,255,0.05)',
          border: '1px solid var(--line)',
          color: 'var(--muted)',
          fontSize: 16,
          cursor: 'pointer',
        }}
      >
        ×
      </button>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.22em', textTransform: 'uppercase', color: 'var(--f1-amber)', fontWeight: 700, marginBottom: 12 }}>
        <span style={{ width: 8, height: 8, borderRadius: '50%', background: 'var(--f1-amber)', boxShadow: '0 0 12px var(--f1-amber)' }} />
        NAMA Pit Wall · Hand-off Radio
      </div>

      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 14, flexWrap: 'wrap' }}>
        <span style={{ padding: '6px 12px', borderRadius: 8, fontFamily: 'var(--mono)', fontSize: 11.5, fontWeight: 700, background: 'rgba(255,255,255,0.05)', border: '1px solid var(--line-strong)', color: 'var(--ink-2)' }}>{from}</span>
        <span style={{ color: 'var(--f1-amber)', fontFamily: 'var(--mono)', fontWeight: 700, fontSize: 14 }}>→</span>
        <span style={{ padding: '6px 12px', borderRadius: 8, fontFamily: 'var(--mono)', fontSize: 11.5, fontWeight: 700, background: 'var(--f1-amber)', color: '#1a0f00', border: '1px solid var(--f1-amber)' }}>{to}</span>
      </div>

      <div style={{ fontSize: 14, lineHeight: 1.55, color: 'var(--ink)' }}>
        <span style={{ display: 'block', fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', fontWeight: 700, marginBottom: 4, color: 'var(--good)' }}>✓ Completed</span>
        {completed}
        <span style={{ display: 'block', fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', fontWeight: 700, margin: '10px 0 4px', color: 'var(--f1-amber)' }}>→ Next</span>
        {next}
      </div>
    </div>
  );
}
