import type { SeatId } from '../types';
import { ACTIVITY } from '../data/mockActivity';

const AVATAR_BG: Record<string, string> = {
  cyan: 'linear-gradient(135deg, #0a4a55, #003540)',
  amber: 'linear-gradient(135deg, #4a2d0d, #2b1a05)',
  champagne: 'linear-gradient(135deg, #3d3725, #1f1c12)',
  teal: 'linear-gradient(135deg, #1d3b44, #0c1e23)',
  yellow: 'linear-gradient(135deg, #4a3a05, #2b220a)',
  red: 'linear-gradient(135deg, #4a0d15, #28080c)',
};

interface Props {
  seat: SeatId;
}

/**
 * Cross-surface activity feed. Per-seat filtering shows only events
 * relevant to the active persona.
 */
export function ActivityFeed({ seat }: Props) {
  const visible = ACTIVITY.filter((e) => e.visibleTo.includes(seat));

  return (
    <div className="panel" style={{ marginTop: 18 }}>
      <div className="panel-head">
        <div>
          <h3>Activity</h3>
          <div className="sub">Filtered for {seat} · last 18 min · all surfaces</div>
        </div>
      </div>
      <div style={{ display: 'grid', gap: 10 }}>
        {visible.map((e) => (
          <div
            key={e.id}
            style={{
              padding: 14,
              border: `1px solid ${e.kind === 'commit' ? 'rgba(35,209,139,0.28)' : e.kind === 'challenge' ? 'rgba(255,149,0,0.28)' : e.kind === 'agent' ? 'rgba(0,229,255,0.24)' : 'var(--line)'}`,
              borderRadius: 12,
              background: e.kind === 'commit' ? 'rgba(35,209,139,0.04)' : e.kind === 'challenge' ? 'rgba(255,149,0,0.04)' : e.kind === 'agent' ? 'rgba(0,229,255,0.04)' : 'rgba(255,255,255,0.02)',
              display: 'grid',
              gridTemplateColumns: '34px 1fr auto',
              gap: 12,
              alignItems: 'start',
            }}
          >
            <div
              style={{
                width: 34,
                height: 34,
                borderRadius: '50%',
                background: AVATAR_BG[e.actorColor],
                display: 'grid',
                placeItems: 'center',
                fontFamily: 'var(--mono)',
                fontSize: 11,
                fontWeight: 700,
                color: 'var(--ink)',
              }}
            >
              {e.actor === 'Workbench agent' || e.actor === 'Glean copilot' ? 'AI' : e.actor.split(' ').map((s) => s[0]).join('').slice(0, 2)}
            </div>
            <div style={{ fontSize: 13, lineHeight: 1.5 }}>
              <div>
                <span style={{ fontWeight: 600 }}>{e.actor}</span>{' '}
                <span style={{ color: 'var(--muted)' }}>{e.verb}</span>{' '}
                <span style={{ fontFamily: 'var(--mono)', fontSize: 12, color: 'var(--accent)' }}>{e.target}</span>
              </div>
              {e.note && (
                <div style={{ color: 'var(--ink-2)', fontSize: 12.5, marginTop: 6, paddingLeft: 10, borderLeft: '2px solid var(--line-strong)' }}>
                  {e.note}
                </div>
              )}
            </div>
            <div style={{ fontFamily: 'var(--mono)', fontSize: 10, color: 'var(--muted)', letterSpacing: '0.04em', textTransform: 'uppercase', whiteSpace: 'nowrap' }}>
              {e.ts}
            </div>
          </div>
        ))}
        {visible.length === 0 && (
          <div style={{ padding: 30, textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--mono)', fontSize: 12 }}>
            No activity visible for {seat} seat. Switch seats to see more.
          </div>
        )}
      </div>
    </div>
  );
}
