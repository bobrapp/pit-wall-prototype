import { useEffect, useRef } from 'react';
import * as d3 from 'd3';
import { FAN_SERIES, type ScenarioKey } from '../data/mockForecast';

interface Props {
  scenario: ScenarioKey;
}

/**
 * D3 quantile fan chart.
 *
 * Renders P10-P90 band, P50 median line, dashed champagne consensus override,
 * yellow YTD actuals, and a champagne commit marker at the Q3 horizon.
 * Redraws cleanly on scenario change.
 */
export function ForecastFan({ scenario }: Props) {
  const svgRef = useRef<SVGSVGElement | null>(null);

  useEffect(() => {
    if (!svgRef.current) return;
    drawFan(svgRef.current, scenario);
    const onResize = () => svgRef.current && drawFan(svgRef.current, scenario);
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, [scenario]);

  return <svg ref={svgRef} viewBox="0 0 760 340" preserveAspectRatio="none" style={{ width: '100%', height: 340, display: 'block' }} role="img" aria-label="Quantile fan forecast chart" />;
}

function drawFan(node: SVGSVGElement, scenario: ScenarioKey) {
  const svg = d3.select(node);
  const W = node.clientWidth || 760;
  const H = 340;
  svg.attr('viewBox', `0 0 ${W} ${H}`).selectAll('*').remove();

  const m = { top: 16, right: 24, bottom: 32, left: 44 };
  const innerW = W - m.left - m.right;
  const innerH = H - m.top - m.bottom;
  const g = svg.append('g').attr('transform', `translate(${m.left},${m.top})`);

  const data = FAN_SERIES[scenario];
  const x = d3.scalePoint().domain(FAN_SERIES.labels as unknown as string[]).range([0, innerW]).padding(0.2);
  const y = d3.scaleLinear().domain([80, 130]).range([innerH, 0]);

  /* gridlines */
  y.ticks(5).forEach((t) => {
    g.append('line')
      .attr('x1', 0)
      .attr('x2', innerW)
      .attr('y1', y(t)!)
      .attr('y2', y(t)!)
      .attr('stroke', 'rgba(255,255,255,0.05)')
      .attr('stroke-dasharray', '2,3');
  });

  /* P10-P90 band */
  const band = d3
    .area<number>()
    .x((_, i) => x(FAN_SERIES.labels[i])!)
    .y0((_, i) => y(data.p10[i])!)
    .y1((_, i) => y(data.p90[i])!)
    .curve(d3.curveCatmullRom.alpha(0.6));
  g.append('path')
    .datum(data.p50)
    .attr('d', band as unknown as string)
    .attr('fill', 'rgba(0,229,255,0.16)')
    .attr('stroke', 'rgba(0,229,255,0.22)')
    .attr('stroke-width', 1);

  /* P50 median */
  const line = d3
    .line<number>()
    .x((_, i) => x(FAN_SERIES.labels[i])!)
    .y((d) => y(d)!)
    .curve(d3.curveCatmullRom.alpha(0.6));
  g.append('path')
    .datum(data.p50)
    .attr('d', line as unknown as string)
    .attr('fill', 'none')
    .attr('stroke', 'rgba(0,229,255,0.85)')
    .attr('stroke-width', 2);

  /* consensus override (champagne dashed) */
  g.append('path')
    .datum(data.consensus)
    .attr('d', line as unknown as string)
    .attr('fill', 'none')
    .attr('stroke', '#c8b273')
    .attr('stroke-width', 2.5)
    .attr('stroke-dasharray', '6,4');

  /* actuals YTD (yellow solid) */
  const actuals = FAN_SERIES.actual
    .map((v, i) => (v == null ? null : { v, i }))
    .filter((p): p is { v: number; i: number } => p !== null);

  g.append('path')
    .datum(actuals.map((p) => p.v))
    .attr(
      'd',
      d3
        .line<number>()
        .x((_, i) => x(FAN_SERIES.labels[actuals[i].i])!)
        .y((d) => y(d)!)
        .curve(d3.curveCatmullRom.alpha(0.6)) as unknown as string,
    )
    .attr('fill', 'none')
    .attr('stroke', '#ffc72c')
    .attr('stroke-width', 3);

  g.selectAll('circle.actual')
    .data(actuals)
    .enter()
    .append('circle')
    .attr('cx', (d) => x(FAN_SERIES.labels[d.i])!)
    .attr('cy', (d) => y(d.v)!)
    .attr('r', 4)
    .attr('fill', '#ffc72c')
    .attr('stroke', '#0a0c10')
    .attr('stroke-width', 2);

  /* commit marker on Q3 (September) */
  const commitIdx = 8;
  g.append('circle')
    .attr('cx', x(FAN_SERIES.labels[commitIdx])!)
    .attr('cy', y(data.consensus[commitIdx])!)
    .attr('r', 8)
    .attr('fill', 'none')
    .attr('stroke', '#c8b273')
    .attr('stroke-width', 2)
    .attr('stroke-dasharray', '3,2');
  g.append('text')
    .attr('x', x(FAN_SERIES.labels[commitIdx])!)
    .attr('y', y(data.consensus[commitIdx])! - 18)
    .attr('fill', '#c8b273')
    .attr('font-family', 'JetBrains Mono, monospace')
    .attr('font-size', '10px')
    .attr('text-anchor', 'end')
    .attr('letter-spacing', '0.14em')
    .text('COMMIT · Q3');

  /* x axis */
  const ax = g.append('g').attr('transform', `translate(0,${innerH})`);
  FAN_SERIES.labels.forEach((lbl) => {
    ax.append('text')
      .attr('x', x(lbl)!)
      .attr('y', 20)
      .attr('fill', '#5e6373')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-size', '10px')
      .attr('text-anchor', 'middle')
      .attr('letter-spacing', '0.1em')
      .text(lbl.toUpperCase());
  });

  /* y axis */
  y.ticks(5).forEach((t) => {
    g.append('text')
      .attr('x', -10)
      .attr('y', y(t)! + 4)
      .attr('fill', '#5e6373')
      .attr('font-family', 'JetBrains Mono, monospace')
      .attr('font-size', '10px')
      .attr('text-anchor', 'end')
      .text(t + 'k');
  });

  /* historical/forecast separator */
  const sepX = x(FAN_SERIES.labels[4])! + (x(FAN_SERIES.labels[5])! - x(FAN_SERIES.labels[4])!) / 2;
  g.append('line')
    .attr('x1', sepX)
    .attr('x2', sepX)
    .attr('y1', 0)
    .attr('y2', innerH)
    .attr('stroke', 'rgba(255,255,255,0.12)')
    .attr('stroke-dasharray', '3,4');
  g.append('text')
    .attr('x', sepX + 6)
    .attr('y', 14)
    .attr('fill', '#8a8f9e')
    .attr('font-family', 'JetBrains Mono, monospace')
    .attr('font-size', '9.5px')
    .attr('letter-spacing', '0.18em')
    .text('FORECAST →');
}
