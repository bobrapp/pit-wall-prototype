import type { SeatId, SurfaceId } from '../types';
import { SEATS } from '../data/mockActivity';

interface Props {
  seat: SeatId;
}

interface SurfaceTile {
  id: SurfaceId;
  name: string;
  icon: string;
  body: string;
  color: string;
}

const TILES: SurfaceTile[] = [
  { id: 'outlook',      name: 'Outlook',           icon: '⌘O', body: 'Q3 Trucks · −8.1k consensus shift. Pre-read with delta, P10/P90, owner. Tap to open Number Room.', color: '#5fb3ff' },
  { id: 'teams',        name: 'Teams / Slack',     icon: '⌘T', body: 'Adaptive challenge card. Buttons: Open Workbench · Challenge · Approve.', color: '#a5a7e0' },
  { id: 'excel',        name: 'Excel add-in',      icon: '∑',  body: 'Workbook NAMA-Q3-Trucks.xlsx · Baseline · Consensus · Actuals. Overrides write to staging only.', color: '#5fd29a' },
  { id: 'sharepoint',   name: 'SharePoint',        icon: '⌘S', body: '/MIA/Q3-2026/dealer-pulse-week19.pptx · intake-agent tagged · routed to Krisztina.', color: '#5fc8cb' },
  { id: 'pbi',          name: 'Power BI',          icon: '⏶',  body: 'Exec tile shows urgent-revision badge · current 312.4k · prior 320.5k · freshness 42 min.', color: '#f1b434' },
  { id: 'glean',        name: 'Glean',             icon: 'G',  body: 'Ask "What changed and why?" Routed to forecast copilot · deterministic answer · 4 citations.', color: '#b09bff' },
  { id: 'workbench',    name: 'Forecast Workbench',icon: '◐',  body: 'Primary analyst cockpit. Compare mode · anomaly queue · scenario lab. 14 live.', color: '#9beeff' },
  { id: 'agent-studio', name: 'Agent Studio',      icon: '⌬',  body: 'GovOps cockpit · HIBT replay-ledger · agent promotions · NAMA-certified gate.', color: '#ffc193' },
];

export function SurfaceRing({ seat }: Props) {
  const config = SEATS.find((s) => s.id === seat)!;
  const primaryTiles = new Set(config.primaryTiles);

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(4, 1fr)',
        gap: 14,
        marginTop: 24,
      }}
    >
      {TILES.map((t) => {
        const isPrimary = primaryTiles.has(t.id);
        return (
          <div
            key={t.id}
            style={{
              order: isPrimary ? config.primaryTiles.indexOf(t.id) : 99,
              padding: 18,
              border: `1px solid ${isPrimary ? `var(--accent)` : 'var(--line)'}`,
              borderRadius: 'var(--radius-lg)',
              background: 'linear-gradient(180deg, var(--carbon), var(--pit))',
              minHeight: 220,
              display: 'flex',
              flexDirection: 'column',
              boxShadow: isPrimary ? `0 0 0 1px var(--accent), 0 20px 60px rgba(0,229,255,0.18)` : 'none',
              opacity: isPrimary ? 1 : 0.6,
              transition: 'all var(--t-norm) var(--ease)',
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div
                style={{
                  width: 32,
                  height: 32,
                  borderRadius: 8,
                  background: `${t.color}22`,
                  border: `1px solid ${t.color}66`,
                  display: 'grid',
                  placeItems: 'center',
                  fontFamily: 'var(--mono)',
                  fontSize: 11,
                  color: t.color,
                  fontWeight: 700,
                }}
              >
                {t.icon}
              </div>
              <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--muted)' }}>{t.name}</span>
            </div>
            <p style={{ flex: 1, fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.55 }}>{t.body}</p>
            <div style={{ marginTop: 12, display: 'flex', gap: 6, flexWrap: 'wrap', fontFamily: 'var(--mono)', fontSize: 9.5, color: 'var(--good)' }}>
              <span>● synced 2.4s ago</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}
