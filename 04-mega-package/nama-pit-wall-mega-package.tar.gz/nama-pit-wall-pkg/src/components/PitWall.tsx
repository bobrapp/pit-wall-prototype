import { useState } from 'react';
import type { SeatId } from '../types';
import { NUMBER_OBJECT_HERO, SCENARIOS, type ScenarioKey } from '../data/mockForecast';
import { ForecastFan } from './ForecastFan';

interface Props {
  seat: SeatId;
}

/**
 * The Pit Wall workbench — main forecast cockpit.
 *
 * Left: number-object hero + quantile fan + scenario compare.
 * Right: action panel that swaps based on active seat
 *   (Analyst: override · Leadership: approval queue · SME: challenge inbox · Ops: pipeline · GovOps: promote)
 */
export function PitWall({ seat }: Props) {
  const [scenario, setScenario] = useState<ScenarioKey>('base');

  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'minmax(0, 1.4fr) minmax(0, 1fr)',
        gap: 22,
        marginTop: 18,
      }}
    >
      {/* LEFT — chart + scenarios */}
      <div className="panel">
        <div className="panel-head">
          <div>
            <h3>{NUMBER_OBJECT_HERO.id} · U.S. Full-Size Trucks · Q3 2026</h3>
            <div className="sub">Forecast Set · v2026.05A</div>
          </div>
          <span
            style={{
              display: 'inline-flex',
              alignItems: 'center',
              gap: 6,
              padding: '5px 12px',
              borderRadius: 999,
              fontFamily: 'var(--mono)',
              fontSize: 10,
              textTransform: 'uppercase',
              letterSpacing: '0.14em',
              fontWeight: 700,
              background: 'rgba(255,149,0,0.14)',
              color: 'var(--warn)',
              border: '1px solid rgba(255,149,0,0.32)',
            }}
          >
            <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--warn)' }} />
            Challenged · Owner review
          </span>
        </div>

        {/* number hero */}
        <div
          style={{
            display: 'flex',
            alignItems: 'baseline',
            gap: 18,
            flexWrap: 'wrap',
            padding: '20px 22px',
            background:
              'radial-gradient(400px 200px at 0% 0%, rgba(255,107,0,0.08), transparent 60%), rgba(255,255,255,0.02)',
            border: '1px solid var(--line)',
            borderRadius: 12,
            marginBottom: 18,
          }}
        >
          <div style={{ width: '100%', marginBottom: 6 }}>
            <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.2em', textTransform: 'uppercase', color: 'var(--muted)' }}>
              Consensus volume — Q3 2026
            </span>
          </div>
          <div style={{ fontFamily: 'var(--serif)', fontWeight: 700, fontSize: 48, lineHeight: 1, letterSpacing: '-0.02em' }}>
            {NUMBER_OBJECT_HERO.consensus.toLocaleString()}{' '}
            <span style={{ color: 'var(--muted)', fontSize: 14, fontFamily: 'var(--mono)' }}>units</span>
          </div>
          <div
            style={{
              fontFamily: 'var(--mono)',
              fontSize: 13,
              fontWeight: 700,
              padding: '5px 10px',
              borderRadius: 8,
              background: 'rgba(255,149,0,0.12)',
              color: 'var(--warn)',
              border: '1px solid rgba(255,149,0,0.28)',
            }}
          >
            Δ -8,100 vs prior commit
          </div>
        </div>

        {/* fan chart */}
        <ForecastFan scenario={scenario} />

        {/* legend */}
        <div style={{ display: 'flex', gap: 14, flexWrap: 'wrap', marginTop: 10, fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)' }}>
          <LegendSwatch color="rgba(0,229,255,0.18)" label="P10–P90 band" />
          <LegendSwatch color="var(--f1-cyan)" label="P50 median model" />
          <LegendSwatch color="var(--cad-champagne)" label="Consensus override" dashed />
          <LegendSwatch color="var(--chevy-yellow)" label="Actuals · YTD" />
        </div>

        {/* scenario compare */}
        <h4 style={{ marginTop: 24, marginBottom: 10, fontSize: 14, fontWeight: 700, letterSpacing: '0.04em', textTransform: 'uppercase' }}>
          Scenario compare
        </h4>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 10 }}>
          {SCENARIOS.map((s, i) => {
            const key: ScenarioKey = i === 0 ? 'base' : i === 1 ? 'incentive' : 'tariff';
            const isActive = scenario === key;
            return (
              <button
                key={s.id}
                type="button"
                onClick={() => setScenario(key)}
                style={{
                  padding: 14,
                  borderRadius: 12,
                  border: `1px solid ${isActive ? 'var(--f1-cyan)' : 'var(--line)'}`,
                  background: isActive ? 'rgba(0,229,255,0.06)' : 'rgba(255,255,255,0.02)',
                  boxShadow: isActive ? 'inset 0 0 0 1px rgba(0,229,255,0.2)' : 'none',
                  cursor: 'pointer',
                  textAlign: 'left',
                  color: 'var(--ink)',
                }}
              >
                <div style={{ fontFamily: 'var(--serif)', fontWeight: 600, fontSize: 16, marginBottom: 4 }}>{s.name}</div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 13, color: 'var(--ink-2)' }}>
                  {s.value.toLocaleString()} units
                </div>
                <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)' }}>
                  P10 {(s.p10 / 1000).toFixed(1)}k / P90 {(s.p90 / 1000).toFixed(1)}k · confidence {s.confidence}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* RIGHT — action panel (swaps by seat) */}
      <div className="panel">
        <SeatActionPanel seat={seat} />
      </div>
    </div>
  );
}

function LegendSwatch({ color, label, dashed }: { color: string; label: string; dashed?: boolean }) {
  return (
    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}>
      <span
        style={{
          width: 14,
          height: dashed ? 2 : 8,
          borderRadius: dashed ? 0 : 2,
          background: color,
          borderTop: dashed ? `2px dashed ${color}` : 'none',
        }}
      />
      {label}
    </span>
  );
}

/** Swaps based on seat. See PRD FR-3 (override), FR-4 (challenge), FR-6 (POR commit), etc. */
function SeatActionPanel({ seat }: { seat: SeatId }) {
  const titles: Record<SeatId, { title: string; sub: string; body: string }> = {
    leadership: {
      title: 'Approval queue',
      sub: 'Promote a scenario to plan-of-record',
      body: 'Scenario B (+$1,500 incentive · 324.8k) has analyst + SME alignment. Exec brief pre-drafted by narrative-drafter-v2.3. Edit, sign, commit.',
    },
    analyst: {
      title: 'Submit an override',
      sub: 'Reason coded · evidence required · staging-only write path',
      body: 'Structured override on Silverado HD: -2.1k units, reason R-18 (competitive launch), evidence linked to /MIA/dealer-pulse-week19.pptx. Confidence: Medium. Lineage preserved.',
    },
    sme: {
      title: 'Challenge inbox · MIA',
      sub: 'Adversarial-but-positive · evidence attached · stays on the number',
      body: '3 active challenges: Silverado HD over-forecast (recommend -3.4k) · Sierra 1500 incentive elasticity · Tariff exposure Mexico imports. New challenge in <90s.',
    },
    ops: {
      title: 'Pipeline health · Ops Control',
      sub: 'Freshness SLAs · stale-state guardrails · release readiness',
      body: '5 of 6 pipelines green. 1 amber: avista cross_shop_index stale 38m. PBI exec_trucks_tile auto-paused by guardrail-classifier. Retry queued.',
    },
    govops: {
      title: 'Agent promotion · NAMA-certified gate',
      sub: 'Eval gates · prompt diffs · canary windows · replay archive',
      body: 'workbench-anomaly v3.4 → v3.5 ready to promote (96.4% eval, canary 24h clean). narrative-drafter v2.3 on hold (eval slipped 82→78). intake-agent v2.0 in canary (5% traffic).',
    },
  };

  const c = titles[seat];

  return (
    <>
      <div className="panel-head">
        <div>
          <h3>{c.title}</h3>
          <div className="sub">{c.sub}</div>
        </div>
      </div>
      <p style={{ fontSize: 14, color: 'var(--ink-2)', lineHeight: 1.6 }}>{c.body}</p>

      <div style={{ marginTop: 18, display: 'flex', gap: 10, flexWrap: 'wrap' }}>
        <button className="btn primary" type="button">Take action</button>
        <button className="btn" type="button">Open replay-ledger</button>
        <button className="btn" type="button">Discuss in Teams</button>
      </div>

      <div style={{ marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--line)' }}>
        <div style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: 'var(--muted)', fontWeight: 700, marginBottom: 10 }}>
          Decision rights (this seat)
        </div>
        <RightsLadder seat={seat} />
      </div>
    </>
  );
}

function RightsLadder({ seat }: { seat: SeatId }) {
  const rights: Record<SeatId, { granted: string[]; denied: string[] }> = {
    leadership: {
      granted: ['Promote plan-of-record', 'Approve scenario', 'Sign exec brief'],
      denied: ['Author override', 'Certify agent'],
    },
    analyst: {
      granted: ['Author override', 'Stage scenario', 'Comment · challenge response'],
      denied: ['Promote plan-of-record', 'Certify agent'],
    },
    sme: {
      granted: ['Raise challenge', 'Attach evidence', 'Comment'],
      denied: ['Author override', 'Promote plan-of-record'],
    },
    ops: {
      granted: ['Pause / retry pipelines', 'Release-readiness signoff', 'Escalate incidents'],
      denied: ['Author override', 'Promote plan-of-record'],
    },
    govops: {
      granted: ['Promote / rollback agent', 'Curate memory', 'Audit replay-ledger'],
      denied: ['Author forecast override', 'Commit plan-of-record'],
    },
  };

  const r = rights[seat];

  return (
    <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' }}>
      {r.granted.map((g) => (
        <span
          key={g}
          style={{
            fontFamily: 'var(--mono)',
            fontSize: 10.5,
            padding: '6px 11px',
            borderRadius: 8,
            background: 'rgba(35,209,139,0.1)',
            color: 'var(--good)',
            border: '1px solid rgba(35,209,139,0.32)',
            letterSpacing: '0.06em',
          }}
        >
          ✓ {g}
        </span>
      ))}
      {r.denied.map((d) => (
        <span
          key={d}
          style={{
            fontFamily: 'var(--mono)',
            fontSize: 10.5,
            padding: '6px 11px',
            borderRadius: 8,
            background: 'rgba(94,99,115,0.08)',
            color: 'var(--muted)',
            border: '1px solid rgba(94,99,115,0.18)',
            letterSpacing: '0.06em',
            textDecoration: 'line-through',
          }}
        >
          ✕ {d}
        </span>
      ))}
    </div>
  );
}
