import { AGENTS } from '../data/mockAgents';

/**
 * Agent Studio · AI GovOps console.
 *
 * Lean version of the full Agent Studio (full implementation in the v2.4 demo).
 * Roster of NAMA-certified agents · message-bus placeholder · human-in-loop queue stub.
 *
 * TODO (v3.0): wire SVG message bus and 7-card work queue from the demo artifact.
 */
export function AgentStudio() {
  return (
    <div style={{ marginTop: 18, display: 'grid', gridTemplateColumns: '300px 1fr 320px', gap: 18 }}>
      {/* Roster */}
      <div className="panel">
        <div className="panel-head">
          <div>
            <h3>Agent roster</h3>
            <div className="sub">{AGENTS.length} NAMA-certified · live</div>
          </div>
        </div>
        <div style={{ display: 'grid', gap: 10 }}>
          {AGENTS.map((a) => (
            <div
              key={a.id}
              style={{
                padding: 14,
                borderRadius: 12,
                border: `1px solid ${a.status === 'busy' ? 'rgba(0,229,255,0.32)' : 'var(--line)'}`,
                background: a.status === 'busy' ? 'rgba(0,229,255,0.04)' : 'rgba(255,255,255,0.025)',
              }}
            >
              <div style={{ fontFamily: 'var(--mono)', fontSize: 12, fontWeight: 700, letterSpacing: '0.04em' }}>{a.id}</div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 9.5, color: 'var(--muted)', marginTop: 3 }}>
                {a.version} · serves {a.seatAssignments.join(', ')}
              </div>
              <div style={{ fontSize: 11.5, color: 'var(--ink-2)', marginTop: 8, lineHeight: 1.45 }}>{a.currentTask}</div>
              <span
                style={{
                  display: 'inline-flex',
                  alignItems: 'center',
                  gap: 5,
                  marginTop: 8,
                  fontFamily: 'var(--mono)',
                  fontSize: 9.5,
                  letterSpacing: '0.14em',
                  textTransform: 'uppercase',
                  fontWeight: 700,
                  color: a.status === 'busy' ? 'var(--f1-cyan)' : 'var(--muted)',
                }}
              >
                <span
                  style={{
                    width: 6,
                    height: 6,
                    borderRadius: '50%',
                    background: a.status === 'busy' ? 'var(--f1-cyan)' : 'var(--muted)',
                    boxShadow: a.status === 'busy' ? '0 0 6px var(--f1-cyan)' : 'none',
                  }}
                />
                {a.status}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* Message bus placeholder */}
      <div className="panel">
        <div className="panel-head">
          <div>
            <h3>Live message bus</h3>
            <div className="sub">Agent ↔ agent · agent ↔ human · all replayable</div>
          </div>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10, padding: '4px 10px', borderRadius: 999, background: 'rgba(0,229,255,0.1)', color: 'var(--f1-cyan)', border: '1px solid rgba(0,229,255,0.32)', fontWeight: 700, letterSpacing: '0.06em' }}>
            live
          </span>
        </div>
        <div
          style={{
            height: 520,
            background: 'radial-gradient(circle at 50% 50%, rgba(0,229,255,0.04), transparent 70%)',
            borderRadius: 12,
            display: 'grid',
            placeItems: 'center',
            color: 'var(--muted)',
            fontFamily: 'var(--mono)',
            fontSize: 12,
            letterSpacing: '0.1em',
            textTransform: 'uppercase',
            border: '1px dashed var(--line-strong)',
          }}
        >
          ◯&nbsp;&nbsp; SVG message-bus placeholder · see v2.4 demo for full animated implementation
        </div>
      </div>

      {/* Work queue stub */}
      <div className="panel">
        <div className="panel-head">
          <div>
            <h3>Human-in-the-loop</h3>
            <div className="sub">Approve · Reject · Edit</div>
          </div>
          <span style={{ fontFamily: 'var(--mono)', fontSize: 10, padding: '4px 10px', borderRadius: 999, background: 'rgba(255,107,0,0.08)', color: 'var(--f1-amber)', border: '1px solid rgba(255,107,0,0.32)', fontWeight: 700 }}>
            5 awaiting
          </span>
        </div>
        <div style={{ display: 'grid', gap: 10 }}>
          <QueueCard agent="workbench-anomaly · v3.5" persona="Krisztina · Analyst" action="Stage override on Silverado HD: -2.1k (R-18)" />
          <QueueCard agent="narrative-drafter · v2.3" persona="Ramzi · Leadership" action="Approve exec brief draft for Scenario B commit" />
          <QueueCard agent="hibt-ledger · v2.0" persona="Don · GovOps" action="Promote workbench-anomaly v3.5 → v3.6" />
          <QueueCard agent="guardrail-classifier · v1.4" persona="Govinda · Ops" action="Confirm avista pipeline retry, lift PBI pause" />
        </div>
      </div>
    </div>
  );
}

function QueueCard({ agent, persona, action }: { agent: string; persona: string; action: string }) {
  return (
    <div
      style={{
        padding: 14,
        borderRadius: 12,
        background: 'rgba(255,255,255,0.025)',
        border: '1px solid var(--line)',
        borderLeft: '3px solid var(--f1-cyan)',
      }}
    >
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.16em', textTransform: 'uppercase', color: 'var(--f1-cyan)', fontWeight: 700 }}>{agent}</span>
        <span style={{ fontFamily: 'var(--mono)', fontSize: 9.5, letterSpacing: '0.12em', textTransform: 'uppercase', color: 'var(--muted)', fontWeight: 700 }}>→ {persona}</span>
      </div>
      <div style={{ fontFamily: 'var(--serif)', fontWeight: 600, fontSize: 14, marginBottom: 10, lineHeight: 1.25 }}>{action}</div>
      <div style={{ display: 'flex', gap: 6 }}>
        <button style={qBtn('good')}>✓ Approve</button>
        <button style={qBtn('amber')}>✎ Edit</button>
        <button style={qBtn('risk')}>✕ Reject</button>
      </div>
    </div>
  );
}

function qBtn(kind: 'good' | 'amber' | 'risk'): React.CSSProperties {
  const colors = {
    good: { bg: 'rgba(35,209,139,0.1)', color: 'var(--good)', border: 'rgba(35,209,139,0.32)' },
    amber: { bg: 'rgba(255,107,0,0.08)', color: 'var(--f1-amber)', border: 'rgba(255,107,0,0.32)' },
    risk: { bg: 'rgba(255,69,58,0.08)', color: 'var(--risk)', border: 'rgba(255,69,58,0.32)' },
  };
  return {
    flex: 1,
    padding: '7px 10px',
    borderRadius: 7,
    fontFamily: 'var(--sans)',
    fontWeight: 600,
    fontSize: 11,
    background: colors[kind].bg,
    color: colors[kind].color,
    border: `1px solid ${colors[kind].border}`,
    cursor: 'pointer',
    letterSpacing: '0.02em',
  };
}
