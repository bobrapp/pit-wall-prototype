import { useEffect, useRef, useState } from 'react';

interface Stop {
  stage: string;
  min: string;
  title: string;
  desc: string;
  baton: string;
  color: string;
  bullets: string[];
}

const STOPS: Stop[] = [
  {
    stage: 'Pit stop 1 · Trigger',
    min: 'Minute 0–2',
    title: 'Signal arrives',
    desc: 'Anomaly or market event triggers an urgent refresh. The wall lights up.',
    baton: 'Ops',
    color: 'var(--chevy-yellow)',
    bullets: ['Teams / Slack alert', 'Ops event from stale source', 'Exec request from Outlook'],
  },
  {
    stage: 'Pit stop 2 · Agent prep',
    min: 'Minute 2–5',
    title: 'Agent first pass',
    desc: 'Retrieve freshest sources, validate trust state, assemble draft explanation.',
    baton: 'Analyst',
    color: 'var(--f1-cyan)',
    bullets: ['Databricks refresh check', 'Glean source retrieval', 'Anomaly + freshness summary'],
  },
  {
    stage: 'Pit stop 3 · Review',
    min: 'Minute 5–9',
    title: 'Analyst + SME review',
    desc: 'Analyst inspects compare mode; SME challenges or confirms.',
    baton: 'SME',
    color: 'var(--buick-teal)',
    bullets: ['Forecast Workbench', 'Excel quick compare', 'Teams challenge card'],
  },
  {
    stage: 'Pit stop 4 · Decision',
    min: 'Minute 9–12',
    title: 'Owner commits',
    desc: 'Owner approves updated number and selects communication mode.',
    baton: 'Leadership',
    color: 'var(--cad-champagne)',
    bullets: ['Outlook summary', 'Teams approval', 'Number Room state change'],
  },
  {
    stage: 'Pit stop 5 · Released',
    min: 'Minute 12–15',
    title: 'Release + replay',
    desc: 'Updated number ships to all surfaces with trust chips. HIBT entry written.',
    baton: 'GovOps',
    color: 'var(--chevy-red)',
    bullets: ['PBI tile refresh', 'Executive brief sent', 'HIBT replay logged'],
  },
];

/**
 * 15-minute urgent race flow visualization.
 *
 * Click "Run race" to simulate baton-pass progression at 30s wall-clock
 * representing the full 15-min flow.
 */
export function RaceFlow() {
  const [activeStop, setActiveStop] = useState(2);
  const [running, setRunning] = useState(false);
  const [clock, setClock] = useState('06:47');
  const startRef = useRef<number | null>(null);
  const intervalRef = useRef<number | null>(null);

  function fmt(ms: number) {
    const totalSec = Math.floor(ms / 1000);
    return `${String(Math.floor(totalSec / 60)).padStart(2, '0')}:${String(totalSec % 60).padStart(2, '0')}`;
  }

  function run() {
    if (running) return;
    setRunning(true);
    const demoMs = 30_000; // 30 sec demo of the 15-min flow
    const totalSim = 15 * 60 * 1000;
    startRef.current = Date.now();
    intervalRef.current = window.setInterval(() => {
      const elapsed = Date.now() - (startRef.current ?? Date.now());
      const ratio = Math.min(1, elapsed / demoMs);
      setClock(fmt(ratio * totalSim));
      setActiveStop(Math.min(4, Math.floor(ratio * 5)));
      if (ratio >= 1) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        intervalRef.current = null;
        setRunning(false);
      }
    }, 100);
  }

  function reset() {
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = null;
    setRunning(false);
    setActiveStop(2);
    setClock('06:47');
  }

  useEffect(() => () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
  }, []);

  return (
    <div style={{ marginTop: 24, borderRadius: 'var(--radius-lg)', background: 'linear-gradient(180deg, var(--carbon), var(--pit))', border: '1px solid var(--line)', overflow: 'hidden' }}>
      <div style={{ padding: '22px 26px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderBottom: '1px solid var(--line)', flexWrap: 'wrap', gap: 18, background: 'radial-gradient(600px 200px at 0% 0%, rgba(255,107,0,0.1), transparent 60%)' }}>
        <div>
          <h3 style={{ fontFamily: 'var(--serif)', fontSize: 24, fontWeight: 600 }}>Urgent forecast · Q3 Trucks revision</h3>
          <div style={{ fontFamily: 'var(--mono)', fontSize: 11, textTransform: 'uppercase', letterSpacing: '0.18em', color: 'var(--muted)', marginTop: 4 }}>
            Trigger: Texas dealer pulse delta · started 14:02:11 ET
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <div style={{ display: 'flex', gap: 4 }}>
            {[0, 1, 2, 3, 4].map((i) => (
              <span
                key={i}
                style={{
                  width: 14,
                  height: 14,
                  borderRadius: '50%',
                  background: i <= activeStop ? 'var(--start-green)' : '#26282f',
                  boxShadow: i <= activeStop ? '0 0 16px var(--start-green)' : 'none',
                  border: '1px solid var(--line)',
                }}
              />
            ))}
          </div>
          <div
            style={{
              fontFamily: 'var(--mono)',
              fontWeight: 700,
              fontSize: 28,
              letterSpacing: '0.06em',
              padding: '8px 16px',
              borderRadius: 10,
              background: '#000',
              border: '1px solid var(--line-strong)',
              color: 'var(--f1-amber)',
              textShadow: '0 0 12px rgba(255,107,0,0.6)',
            }}
          >
            {clock}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10 }}>
          <button className="btn primary" type="button" onClick={run} disabled={running}>Run race</button>
          <button className="btn" type="button" onClick={reset}>Reset</button>
        </div>
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)' }}>
        {STOPS.map((s, i) => {
          const isActive = i === activeStop;
          const isDone = i < activeStop;
          return (
            <div
              key={s.title}
              style={{
                position: 'relative',
                padding: '24px 22px',
                borderRight: i < STOPS.length - 1 ? '1px solid var(--line)' : '0',
                background: isActive
                  ? 'linear-gradient(180deg, rgba(255,107,0,0.14), rgba(255,107,0,0.06))'
                  : isDone
                  ? 'linear-gradient(180deg, rgba(35,209,139,0.1), rgba(35,209,139,0.03))'
                  : 'linear-gradient(180deg, var(--carbon), var(--pit))',
                borderTop: isActive ? `2px solid ${s.color}` : '0',
              }}
            >
              <div style={{ fontFamily: 'var(--mono)', fontSize: 10, letterSpacing: '0.18em', textTransform: 'uppercase', color: s.color, fontWeight: 700 }}>
                {s.stage.split(' · ')[1]}
              </div>
              <div style={{ fontFamily: 'var(--mono)', fontSize: 11, color: 'var(--muted)', marginTop: 2 }}>{s.min}</div>
              <h5 style={{ fontFamily: 'var(--serif)', fontWeight: 600, fontSize: 20, margin: '10px 0 8px', letterSpacing: '-0.01em' }}>{s.title}</h5>
              <p style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5, marginBottom: 10 }}>{s.desc}</p>
              <span
                style={{
                  display: 'inline-block',
                  marginTop: 8,
                  fontFamily: 'var(--mono)',
                  fontSize: 9,
                  padding: '3px 9px',
                  borderRadius: 999,
                  letterSpacing: '0.18em',
                  textTransform: 'uppercase',
                  fontWeight: 700,
                  background: isActive ? s.color : 'rgba(255,255,255,0.04)',
                  color: isActive ? '#1a0f00' : 'var(--ink-2)',
                  border: `1px solid ${isActive ? s.color : 'var(--line-strong)'}`,
                }}
              >
                Baton · {s.baton}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
}
