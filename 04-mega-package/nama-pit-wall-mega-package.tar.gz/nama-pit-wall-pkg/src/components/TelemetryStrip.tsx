import type { SeatId } from '../types';
import { TELEMETRY } from '../data/mockActivity';

const LED_COLOR: Record<string, string> = {
  good: 'var(--good)',
  warn: 'var(--warn)',
  risk: 'var(--risk)',
  amber: 'var(--f1-amber)',
};

const VAL_COLOR: Record<string, string> = {
  good: 'var(--good)',
  warn: 'var(--warn)',
  risk: 'var(--risk)',
  cyan: 'var(--f1-cyan)',
  amber: 'var(--f1-amber)',
};

interface Props {
  seat: SeatId;
}

/**
 * Race-control telemetry strip. Persona-aware: 9 cells reframe per seat.
 * Sticky under the topbar; horizontally scrollable on narrow screens.
 */
export function TelemetryStrip({ seat }: Props) {
  const cells = TELEMETRY[seat];

  return (
    <div
      style={{
        position: 'sticky',
        top: 65,
        zIndex: 70,
        background: 'linear-gradient(180deg, rgba(6,8,13,0.95), rgba(6,8,13,0.88))',
        borderTop: '1px solid rgba(255,255,255,0.04)',
        borderBottom: '1px solid var(--line)',
        padding: '12px 0',
        backdropFilter: 'blur(14px)',
      }}
    >
      <div
        style={{
          maxWidth: 1480,
          margin: '0 auto',
          padding: '0 24px',
          display: 'flex',
          gap: 8,
          overflowX: 'auto',
          scrollbarWidth: 'none',
        }}
      >
        {cells.map((c) => (
          <div
            key={c.label}
            style={{
              flex: '0 0 auto',
              padding: '8px 16px',
              borderRadius: 10,
              border: '1px solid var(--line)',
              background: 'rgba(255,255,255,0.02)',
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              minWidth: 'max-content',
            }}
          >
            <span
              style={{
                width: 8,
                height: 8,
                borderRadius: '50%',
                background: LED_COLOR[c.ledColor ?? 'good'],
                boxShadow: `0 0 12px ${LED_COLOR[c.ledColor ?? 'good']}`,
              }}
            />
            <span>
              <span
                style={{
                  fontFamily: 'var(--mono)',
                  fontSize: 9.5,
                  textTransform: 'uppercase',
                  letterSpacing: '0.18em',
                  color: 'var(--muted)',
                  display: 'block',
                }}
              >
                {c.label}
              </span>
              <span
                style={{
                  fontFamily: 'var(--mono)',
                  fontWeight: 700,
                  fontSize: 14,
                  letterSpacing: '0.02em',
                  color: VAL_COLOR[c.state ?? ''] ?? 'var(--ink)',
                }}
              >
                {c.value}
              </span>
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}
