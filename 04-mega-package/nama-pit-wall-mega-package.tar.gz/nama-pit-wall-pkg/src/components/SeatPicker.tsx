import type { SeatId } from '../types';
import { SEATS } from '../data/mockActivity';

interface Props {
  seat: SeatId;
  onChange: (seat: SeatId) => void;
}

/**
 * Five-seat picker. Active seat highlighted; click any to switch.
 * The selected seat's color is bound to --accent via [data-persona] on <body>.
 */
export function SeatPicker({ seat, onChange }: Props) {
  return (
    <div
      style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(5, 1fr)',
        gap: 14,
        marginTop: 24,
      }}
    >
      {SEATS.map((s) => {
        const isActive = s.id === seat;
        return (
          <button
            key={s.id}
            type="button"
            onClick={() => onChange(s.id)}
            style={{
              position: 'relative',
              padding: '24px 22px 22px',
              borderRadius: 'var(--radius-lg)',
              border: `1px solid ${isActive ? `var(${s.accentVar})` : 'var(--line)'}`,
              background: isActive
                ? `linear-gradient(180deg, rgba(255,255,255,0.06), rgba(255,255,255,0.01))`
                : `linear-gradient(180deg, rgba(255,255,255,0.03), rgba(255,255,255,0.01))`,
              boxShadow: isActive
                ? `0 0 0 1px var(${s.accentVar}), 0 20px 60px rgba(0,0,0,0.4)`
                : 'none',
              minHeight: 200,
              cursor: 'pointer',
              textAlign: 'left',
              color: 'var(--ink)',
              transition: 'transform var(--t-norm) var(--ease), border-color var(--t-norm) var(--ease)',
              transform: isActive ? 'translateY(-3px)' : 'none',
            }}
          >
            <span
              style={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                height: 3,
                background: `var(${s.accentVar})`,
                opacity: 0.7,
              }}
            />
            <div
              style={{
                fontFamily: 'var(--mono)',
                fontSize: 10,
                letterSpacing: '0.2em',
                color: 'var(--muted)',
                textTransform: 'uppercase',
              }}
            >
              SEAT · {s.number}
            </div>
            <div
              style={{
                fontFamily: 'var(--serif)',
                fontWeight: 700,
                fontSize: 24,
                letterSpacing: '-0.015em',
                margin: '10px 0 6px',
              }}
            >
              {s.name}
            </div>
            <div
              style={{
                fontFamily: 'var(--mono)',
                fontSize: 10,
                letterSpacing: '0.16em',
                textTransform: 'uppercase',
                color: `var(${s.accentVar})`,
                fontWeight: 700,
                marginBottom: 14,
              }}
            >
              {s.brandLine}
            </div>
            <p style={{ fontSize: 13, color: 'var(--ink-2)', lineHeight: 1.5, marginBottom: 14 }}>{s.summary}</p>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {s.tools.map((t) => (
                <span
                  key={t}
                  style={{
                    fontFamily: 'var(--mono)',
                    fontSize: 9.5,
                    padding: '3px 8px',
                    borderRadius: 6,
                    background: 'rgba(255,255,255,0.04)',
                    color: 'var(--ink-2)',
                    border: '1px solid var(--line)',
                    letterSpacing: '0.06em',
                  }}
                >
                  {t}
                </span>
              ))}
            </div>
          </button>
        );
      })}
    </div>
  );
}
