/**
 * Canonical sample forecast — FS-2026Q3-NA-TRK-001
 * U.S. Full-Size Trucks · Q3 2026 horizon
 *
 * Used as the demo data across every artifact in the package.
 * Same numbers in the v2.4 app, the pitch deck, the one-pager, and the design doc.
 */

import type { ForecastSet, NumberObject, Scenario, User } from '../types';

export const USERS: User[] = [
  { id: 'ramzi_a',  name: 'Ramzi Abdelmoula', initials: 'RA', role: 'leadership', team: 'NAMA Exec', onCall: false, avatarColor: 'champagne' },
  { id: 'bob_r',    name: 'Bob Rapp',          initials: 'BR', role: 'analyst',    team: 'Architecture', onCall: false, avatarColor: 'cyan' },
  { id: 'krisztina_g', name: 'Krisztina Gilezan', initials: 'KG', role: 'analyst',  team: 'Forecasting',  onCall: true,  avatarColor: 'cyan' },
  { id: 'jim_k',    name: 'Jim Kyle',          initials: 'JK', role: 'sme',        team: 'MIA',          onCall: true,  avatarColor: 'teal' },
  { id: 'mansoor_a', name: 'Mansoor Alghooneh', initials: 'MA', role: 'ops',       team: 'Data & Ops',   onCall: false, avatarColor: 'yellow' },
  { id: 'govinda_c', name: 'Govinda Chaluvadi', initials: 'GC', role: 'ops',        team: 'Data & Ops',   onCall: true,  avatarColor: 'yellow' },
  { id: 'don_s',    name: 'Don S.',             initials: 'DS', role: 'govops',    team: 'AI GovOps',    onCall: true,  avatarColor: 'red' },
];

export const FORECAST_SET: ForecastSet = {
  id: 'FS-2026Q3-NA-TRK-001',
  name: 'U.S. Full-Size Trucks · Q3 2026',
  horizon: 'Q3 2026',
  scenarioId: 'sc_base_2026q3',
  modelVersion: 'v2026.05A',
  dataSnapshotId: 'snap_2026_w19',
  owner: 'krisztina_g',
  state: 'challenged',
  porStatus: true,
  createdAt: '2026-05-12T13:00:00Z',
  updatedAt: '2026-05-12T14:02:11Z',
};

export const NUMBER_OBJECT_HERO: NumberObject = {
  id: 'NO-TRK-Q3-001',
  forecastSetId: 'FS-2026Q3-NA-TRK-001',
  nameplate: 'us_full_size_trucks',
  monthLabel: '2026-Q3',
  p10: 287_600,
  p50: 312_400,
  p90: 338_900,
  baseline: 312_400,
  consensus: 312_400,
  confidence: 0.71,
  owner: 'krisztina_g',
  freshnessAt: '2026-05-12T13:20:00Z',
  commentsCount: 7,
  state: 'challenged',
};

export const SCENARIOS: Scenario[] = [
  {
    id: 'sc_base_2026q3',
    forecastSetId: 'FS-2026Q3-NA-TRK-001',
    name: 'Base · Plan-of-record',
    description: 'P50 median model output',
    assumptions: { incentive: 0, tariff: 'as-is' },
    compareState: 'active',
    value: 312_400,
    p10: 287_600,
    p90: 338_900,
    confidence: 0.71,
  },
  {
    id: 'sc_incentive_2026q3',
    forecastSetId: 'FS-2026Q3-NA-TRK-001',
    name: '+$1,500 incentive',
    description: 'Pricing-driven scenario with MIA bias',
    assumptions: { incentive: 1500, tariff: 'as-is' },
    compareState: 'draft',
    value: 324_800,
    p10: 298_400,
    p90: 351_200,
    confidence: 0.68,
  },
  {
    id: 'sc_tariff_2026q3',
    forecastSetId: 'FS-2026Q3-NA-TRK-001',
    name: 'Tariff shock',
    description: 'Mexico tariff downside guard',
    assumptions: { incentive: 0, tariff: 'mexico_15pct' },
    compareState: 'draft',
    value: 289_100,
    p10: 263_800,
    p90: 316_500,
    confidence: 0.62,
  },
];

/** monthly series for the D3 quantile fan chart */
export const FAN_SERIES = {
  labels: ['Jan-26', 'Feb-26', 'Mar-26', 'Apr-26', 'May-26', 'Jun-26', 'Jul-26', 'Aug-26', 'Sep-26'],
  actual: [98.1, 102.4, 108.7, 106.2, 104.9, null, null, null, null] as Array<number | null>,
  base: {
    p10:        [95.0,  99.0, 105.0, 102.0, 100.0,  96.0,  91.0,  92.0,  93.5],
    p50:        [98.1, 102.4, 108.7, 106.2, 104.9, 103.1, 102.5, 104.0, 105.9],
    p90:        [101.2,105.6, 112.4, 110.0, 109.4, 110.0, 113.0, 116.0, 118.8],
    consensus:  [98.1, 102.4, 108.7, 106.2, 104.9, 102.0, 100.5, 103.4, 108.5],
  },
  incentive: {
    p10:        [95.0,  99.0, 105.0, 102.0, 100.0,  99.0,  96.0,  99.0, 102.5],
    p50:        [98.1, 102.4, 108.7, 106.2, 104.9, 105.9, 107.0, 110.5, 113.2],
    p90:        [101.2,105.6, 112.4, 110.0, 109.4, 112.0, 115.5, 119.0, 122.4],
    consensus:  [98.1, 102.4, 108.7, 106.2, 104.9, 104.8, 105.4, 109.0, 112.6],
  },
  tariff: {
    p10:        [95.0,  99.0, 105.0, 102.0, 100.0,  92.0,  86.0,  84.0,  84.5],
    p50:        [98.1, 102.4, 108.7, 106.2, 104.9,  99.5,  96.0,  95.4,  97.6],
    p90:        [101.2,105.6, 112.4, 110.0, 109.4, 106.5, 105.5, 107.8, 110.0],
    consensus:  [98.1, 102.4, 108.7, 106.2, 104.9,  99.0,  93.8,  94.0,  96.0],
  },
} as const;

export type ScenarioKey = 'base' | 'incentive' | 'tariff';
