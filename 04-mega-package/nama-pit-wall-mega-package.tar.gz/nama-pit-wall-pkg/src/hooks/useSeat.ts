import { useEffect, useState, useCallback } from 'react';
import type { SeatId } from '../types';

const STORAGE_KEY = 'nama_pit_wall_seat';
const DEFAULT_SEAT: SeatId = 'analyst';

/**
 * Persona seat hook.
 *
 * Persists choice in localStorage. Sets `data-persona` on `<body>` so the
 * CSS accent variables swap automatically.
 */
export function useSeat() {
  const [seat, setSeatState] = useState<SeatId>(() => {
    if (typeof window === 'undefined') return DEFAULT_SEAT;
    try {
      const saved = window.localStorage.getItem(STORAGE_KEY) as SeatId | null;
      if (saved && ['leadership', 'analyst', 'sme', 'ops', 'govops'].includes(saved)) {
        return saved;
      }
    } catch {
      /* ignore */
    }
    return DEFAULT_SEAT;
  });

  useEffect(() => {
    if (typeof document !== 'undefined') {
      document.body.setAttribute('data-persona', seat);
    }
    try {
      window.localStorage.setItem(STORAGE_KEY, seat);
    } catch {
      /* ignore */
    }
  }, [seat]);

  const setSeat = useCallback((next: SeatId) => {
    setSeatState(next);
  }, []);

  return { seat, setSeat };
}
