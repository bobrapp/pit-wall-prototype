import { useSeat } from './hooks/useSeat';
import { TelemetryStrip } from './components/TelemetryStrip';
import { SeatPicker } from './components/SeatPicker';
import { PitWall } from './components/PitWall';
import { SurfaceRing } from './components/SurfaceRing';
import { ActivityFeed } from './components/ActivityFeed';
import { RaceFlow } from './components/RaceFlow';
import { AgentStudio } from './components/AgentStudio';

export default function App() {
  const { seat, setSeat } = useSeat();

  return (
    <>
      <header className="topbar">
        <div className="topbar-inner">
          <div className="brand">
            <div className="mark">NAMA</div>
            <div className="brand-text">
              <div className="brand-name">NAMA Pit Wall</div>
              <div className="brand-sub">Agentic Ensemble · v2.4</div>
            </div>
          </div>
          <nav style={{ display: 'flex', gap: 12, fontSize: 13, fontWeight: 500 }}>
            <a href="#pit-wall">Pit Wall</a>
            <a href="#ring">Surfaces</a>
            <a href="#race">15-min race</a>
            <a href="#studio">Agent Studio</a>
          </nav>
        </div>
      </header>

      <TelemetryStrip seat={seat} />

      <main className="shell">
        <section className="section" id="seats">
          <div className="eyebrow">Step 01 · Choose your own adventure</div>
          <h1 className="h1">Take your seat on the wall.</h1>
          <p className="lead">
            Five seats. One number. Pick the one that fits how you work — the whole workspace adapts below.
            Your action panel swaps, the activity feed filters, your preferred surfaces get elevated.
            Every action still writes back to the same trusted forecast set.
          </p>
          <SeatPicker seat={seat} onChange={setSeat} />
        </section>

        <section className="section" id="pit-wall">
          <div className="eyebrow">Step 02 · The workbench</div>
          <h2 className="h2">The Pit Wall.</h2>
          <p className="lead">
            Forecast set <span style={{ fontFamily: 'var(--mono)', color: 'var(--ink)' }}>FS-2026Q3-NA-TRK-001</span> ·
            U.S. Full-Size Trucks · Q3 2026. Everyone on the wall sees the same number.
          </p>
          <PitWall seat={seat} />
        </section>

        <section className="section" id="ring">
          <div className="eyebrow">Step 03 · Surface ring</div>
          <h2 className="h2">Same number. Every surface.</h2>
          <SurfaceRing seat={seat} />
        </section>

        <section className="section">
          <h2 className="h2">On the wall · live activity</h2>
          <ActivityFeed seat={seat} />
        </section>

        <section className="section" id="race">
          <div className="eyebrow">Step 04 · Lights out</div>
          <h2 className="h2">The 15-minute race.</h2>
          <RaceFlow />
        </section>

        <section className="section" id="studio">
          <div className="eyebrow">Step 05 · Race director</div>
          <h2 className="h2">Agent Studio · AI GovOps.</h2>
          <AgentStudio />
        </section>
      </main>

      <footer style={{ borderTop: '1px solid var(--line)', padding: '40px 0', textAlign: 'center', color: 'var(--muted)', fontFamily: 'var(--mono)', fontSize: 11, letterSpacing: '0.18em', textTransform: 'uppercase' }}>
        v2.4 · 2026-05-12 · One planning brain. Many surfaces. Human judgment preserved.
      </footer>
    </>
  );
}
