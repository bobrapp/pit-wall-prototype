/**
 * NAMA Pit Wall — Type system
 *
 * Mirrors the Postgres schema in docs/schema/schema.sql and the OpenAPI spec
 * in docs/api/openapi.yaml. Keep these aligned when extending.
 */

export type SeatId = 'leadership' | 'analyst' | 'sme' | 'ops' | 'govops';

export type SurfaceId =
  | 'outlook'
  | 'teams'
  | 'excel'
  | 'sharepoint'
  | 'pbi'
  | 'glean'
  | 'workbench'
  | 'agent-studio';

export type ForecastSetState =
  | 'draft'
  | 'updated'
  | 'challenged'
  | 'committed'
  | 'final'
  | 'reviewed';

export type ActionType =
  | 'override'
  | 'challenge'
  | 'approval'
  | 'prompt'
  | 'tool-call'
  | 'commit'
  | 'rollback'
  | 'release-readiness'
  | 'agent-promotion';

/** ──────────────────────────────────────────────────────────
 *  Domain entities
 *  ────────────────────────────────────────────────────────── */

export interface User {
  id: string;
  name: string;
  initials: string;
  role: SeatId;
  team: string;
  onCall: boolean;
  avatarColor: 'champagne' | 'cyan' | 'teal' | 'yellow' | 'red';
}

export interface ForecastSet {
  id: string;                       // e.g., 'FS-2026Q3-NA-TRK-001'
  name: string;
  horizon: string;                  // e.g., 'Q3 2026'
  scenarioId: string;               // current active scenario
  modelVersion: string;
  dataSnapshotId: string;
  owner: string;                    // user_id
  state: ForecastSetState;
  porStatus: boolean;
  createdAt: string;
  updatedAt: string;
}

export interface NumberObject {
  id: string;
  forecastSetId: string;
  nameplate: string;                // e.g., 'silverado_hd'
  monthLabel: string;               // e.g., '2026-Q3'
  p10: number;
  p50: number;
  p90: number;
  baseline: number;
  consensus: number;
  confidence: number;               // 0..1
  owner: string;
  freshnessAt: string;
  commentsCount: number;
  state: ForecastSetState;
}

export interface Scenario {
  id: string;
  forecastSetId: string;
  name: string;                     // e.g., 'Base · Plan-of-record'
  description: string;
  assumptions: Record<string, unknown>;
  compareState: 'draft' | 'active' | 'promoted' | 'archived';
  value: number;
  p10: number;
  p90: number;
  confidence: number;
}

export interface Override {
  id: string;
  numberObjectId: string;
  actorUserId: string;
  reasonCode: string;               // FK reason_codes (R-XX)
  newValue: number;
  newP10?: number;
  newP90?: number;
  confidence: 'high' | 'medium' | 'low';
  evidenceLinks: string[];
  state: 'draft' | 'staged' | 'applied' | 'dismissed';
  createdAt: string;
}

export interface Challenge {
  id: string;
  numberObjectId: string;
  actorUserId: string;
  reasonCode: string;
  description: string;
  evidenceLinks: string[];
  state: 'open' | 'responded' | 'resolved' | 'dismissed';
  recommendedValue?: number;
  createdAt: string;
}

export interface Agent {
  id: string;                       // e.g., 'workbench-anomaly'
  version: string;                  // e.g., 'v3.5'
  status: 'canary' | 'promoted' | 'rolled-back' | 'idle' | 'busy';
  evalScore: number;                // 0..1
  lastEvaluatedAt: string;
  ownerTeam: string;
  namaCertified: boolean;
  seatAssignments: SeatId[];
  currentTask?: string;
}

export interface ActivityEvent {
  id: string;
  ts: string;
  actor: string;                    // user name OR 'AI'
  actorColor: User['avatarColor'];
  verb: string;
  target: string;
  note?: string;
  kind: 'commit' | 'challenge' | 'override' | 'agent' | 'release';
  visibleTo: SeatId[];              // for activity filtering
}

export interface TelemetryCell {
  label: string;
  value: string;
  state?: 'good' | 'warn' | 'risk' | 'cyan' | 'amber';
  ledColor?: 'good' | 'warn' | 'risk' | 'amber';
}

export interface SeatConfig {
  id: SeatId;
  number: string;                   // '01', '02', etc.
  name: string;                     // 'Leadership'
  brandLine: string;                // 'Cadillac line · Champagne'
  action: string;                   // 'Approve & commit'
  summary: string;
  tools: string[];
  accentVar: string;                // CSS variable name
  telemetry: TelemetryCell[];
  primaryTiles: SurfaceId[];
}

/** ──────────────────────────────────────────────────────────
 *  v3.0 delighter types
 *  ────────────────────────────────────────────────────────── */

export interface SecondOpinionRun {
  id: string;
  forecastSetId: string;
  trigger: 'manual' | 'auto_gate3';
  triggeredBy: string;
  promptPack: string;
  primary: { value: number; p10: number; p90: number };
  secondOpinion: { value: number; p10: number; p90: number };
  delta: number;
  mds: number;                      // 0..1
  mdsComponents: {
    pointDeltaNorm: number;
    bandOverlap: number;
    sourceOverlap: number;
    factorCountNorm: number;
  };
  divergentFactors: DivergentFactor[];
  challengeRaised: boolean;
  challengeId?: string;
  suggestedRoute: {
    smeTeam: string;
    specificSme: string;
    topFactor: string;
    topFactorWeight: number;
  };
  costUsd: number;
  latencyMs: number;
  status: 'running' | 'completed' | 'failed';
  hibtEntryId: string;
}

export interface DivergentFactor {
  factor: string;
  category: 'pricing' | 'mia' | 'ops' | 'tariff' | 'competitive' | 'fleet' | 'macro';
  weight: number;
  evidenceLinks: string[];
}

export interface ChampionshipStanding {
  userId: string;
  league: 'override_value_add' | 'challenge_precision' | 'agent_improvement' | 'mentorship';
  seasonId: string;
  rawScore: number;
  rank: number;
  quartile: 1 | 2 | 3 | 4;
  contributionCount: number;
  qualified: boolean;
}
