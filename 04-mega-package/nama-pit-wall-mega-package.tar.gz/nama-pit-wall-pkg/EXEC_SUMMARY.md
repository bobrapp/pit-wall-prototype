# NAMA Pit Wall — Executive Summary

**v2.4 · 2026-05-12**

## In one line

A co-working forecasting platform that keeps every NAMA persona in the surfaces they prefer (Outlook, Teams, Excel, SharePoint, Power BI, Glean, Workbench) while every comment, challenge, override, and approval lands on the same governed forecast substrate. Agents do the rework. People do the judgment.

## The problem we're solving

NAMA forecasting runs ~22 cycles per month against ~$50B of revenue, but today every seat brings their own spreadsheet. The data is right:

- **38%** of analyst time spent in rework, not analysis
- **14%** of plan-of-record drift attributable to version mismatches between surfaces
- **4–7 days** p50 to close one challenge (best-in-class: < 1 hour)
- **0** replayable agent actions — no HIBT, no audit trail for AI-assisted decisions

Cost of inaction: continued margin leakage from forecast accuracy gaps and unrecoverable analyst hours.

## The vision

**One trusted substrate. Many surfaces. Human judgment preserved.**

Five seats with role-aware decision rights:

| Seat | Surfaces | Decision rights |
|------|----------|-----------------|
| Leadership · *Ramzi* | Outlook · PBI · Teams · Morning Brief | Approve scenario · commit POR · sign exec brief |
| Analyst · *Krisztina* | Workbench · Excel · PA Agent · Compare | Author override · stage scenario · respond to challenge |
| SME · *Jim Kyle* | Teams · Glean · SharePoint · Avista | Raise challenge · attach evidence · comment |
| Ops · *Govinda* | Ops Control · PBI · Incidents · Guardrails | Pause / retry pipelines · release-readiness signoff |
| AI GovOps · *Don S.* | Agent Studio · HIBT · Eval Board · Replay | Promote / rollback agent · curate memory · audit replay |

Eight surfaces. Seven NAMA-certified agents. Two clocks: a 15-minute urgent race and the monthly S&OP cycle. Every action immutable in the HIBT replay-prompt-ledger.

## What ships when

| Version | Window | What ships |
|---------|--------|-----------|
| **v2.4** | live now | 5 seats · 8 surfaces · 7 agents · 15-min race with baton-pass · monthly S&OP swimlane · Agent Studio + HIBT v2.0 |
| **v3.0** | next 90 days | Second-Opinion Agent (adversarial review) · Ghost Lap (temporal overlay) · Championship Table (celebration leaderboard) · Constraint twin |
| **v3.5** | 6 months out | Strategic 3-5y horizon · auto-S&OP pre-read · external signal marketplace · cross-region wall (NAMA + Europe + China) |

## The ask

| Bucket | Ask |
|--------|-----|
| **Funding** | $2.4M committed to v3.0 build (Q3 start) |
| **People** | 4 SMEs and 6 analysts onboarded for Q3 pilot · 1 ML engineer hire (gap closer) |
| **Sponsorship** | Sponsor signoff + brief NAMA exec team |
| **Cert gate** | 3 production agents promoted through GovOps gate |

## Success metrics (v3.0 target, 6 months post-GA)

- MAPE forecast accuracy lift: **+0.6 pts** vs. v2.4 baseline (illustrative)
- Challenge resolution p50: **< 1 hour** (vs. 4–7 days today)
- Surface-consistency SLA: **2.4s** p95 single-value (already meeting in v2.4)
- Override value-add: **+1.9 pts** YTD
- Agent eval pass-rate: **≥ 96%** sustained
- Replay determinism: **≥ 98%** on weekly sample
- Analyst time on rework: **-50%** vs. baseline

## Top risks (with mitigations)

| Risk | Mitigation |
|------|-----------|
| Adoption (analysts cling to Excel) | Excel add-in writes to staging path; same Number Object visible there |
| LLM cost volatility | Per-seat daily budget caps + provider failover plan |
| HIBT v2.0 slip blocks v3.0 | 70% complete; ML engineer hire frees architecture bandwidth |
| Culture: Championship Table feels like performance review | Opt-out default; quartile bands only; never wired to comp; sponsor cultural signoff required |

## Why now

1. Q3 2026 NAMA cycle exposed the rework cost in measurable terms (38% analyst time)
2. Databricks + Unity Catalog substrate is live and stable
3. HIBT v2.0 finalization is 70% complete and gating other v3.0 features
4. Sponsor (Ramzi) is in position with budget authority for one decision cycle
5. The agent technology is now mature enough to pass NAMA-certified eval gates

## Why this team

This is the team that built v2.4. They lived through the manual cycles. They wrote the PRD. They run the S&OP. They own the agent certification gate. There is no learning curve.

## Operating principle

> **Agents do the rework, the research, the toil. Humans do the judgment, the dissent, the commit. The Pit Wall keeps them honest to each other.**

---

**Next step:** Sponsor signoff to ratify the v3.0 PRD addendum and authorize the ML engineer hire. Decision window: 14 days from this brief.

| Sponsor | Decision date | Signed |
|---------|---------------|--------|
| Ramzi Abdelmoula | 2026-05-26 | ☐ |
