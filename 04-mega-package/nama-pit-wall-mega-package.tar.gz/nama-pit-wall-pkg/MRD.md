# Market Requirements Document
## NAMA Pit Wall — Internal Platform
### GM North American Markets Forecasting Organization

**Document version:** 1.0
**Date:** 2026-05-12
**Owner:** Product / Platform Engineering
**Champion:** Ramzi Abdelmoula
**Status:** Draft for investment review

---

## Table of Contents

1. [Market Context](#1-market-context)
2. [Market Requirements](#2-market-requirements)
3. [Competitive Analysis](#3-competitive-analysis)
4. [Buyer and User Analysis](#4-buyer-and-user-analysis)
5. [Market Sizing](#5-market-sizing)
6. [Pricing and Cost Model](#6-pricing-and-cost-model)
7. [Go-to-Market for an Internal Platform](#7-go-to-market-for-an-internal-platform)
8. [Risks and Mitigations](#8-risks-and-mitigations)

---

## 1. Market Context

### 1.1 The Forecasting Organization Today

GM's North American Markets (NAMA) forecasting organization is the connective tissue between production planning and commercial execution. It produces the Plan of Record (POR) — the authoritative volume and revenue forecast used to schedule plants, set incentive budgets, negotiate dealer allocations, and brief executive leadership. At any given time, NAMA is actively managing approximately $50B in annualized revenue, across a portfolio of ~30 nameplates, in cycles that recur roughly 22 times per month across three horizons: urgent/near-term (days to 2 weeks), monthly (the core POR cycle), and strategic (annual and long-range plan).

The work is done by five distinct personas operating across eight surfaces:

| Persona | Role | Primary Surface(s) |
|---|---|---|
| **Demand Analyst** | Builds and maintains volume forecasts by nameplate, region, and segment | Excel workbooks, Power BI dashboards, ad-hoc SQL |
| **SME / Market Specialist** | Owns a market segment (e.g., fleet, rental, retail), challenges or endorses analyst forecasts | Email threads, Excel overlays, occasional BI |
| **Operations / IT** | Runs pipelines, manages data feeds from Databricks/Unity Catalog, monitors SLA | Databricks notebooks, ops dashboards |
| **Leadership / Decision-maker** | Reviews and approves POR; escalates unresolved challenges; communicates to plant planning | PowerPoint, email summaries, ad-hoc briefings |
| **GovOps / Audit** | Ensures SOX compliance, AI-governance, version auditability | Audit trail exports, compliance tooling |

### 1.2 Pain Points — Quantified

These metrics were surfaced through direct observation of NAMA workflow and internal retrospectives. Where indicated, numbers are illustrative approximations based on team estimates; they should be validated through a formal time-study in Q3 2026.

**38% of analyst time spent in rework.** The dominant rework driver is version mismatch: analysts maintain parallel workbook copies shared by email, and changes made by one analyst or SME are not automatically propagated. When a demand signal changes, the analyst must manually reconcile multiple copies, re-run calculations, and re-distribute. This is not a discipline problem — it is a structural absence of a shared state layer.

**14% POR drift from version mismatch (illustrative).** In a sample of monthly POR cycles reviewed internally, final-approved POR figures differed from the last "working draft" by a mean of approximately 14% at the nameplate level. The proximate cause is that challenges and overrides entered late in the cycle were applied to some copies but not others. The business consequence is that plant planning sometimes receives a POR inconsistent with what the commercial team intended to commit.

**4–7 day p50 challenge resolution.** A "challenge" is a formal dissent: an SME or leader disputes a forecast number and requests revision. Today, challenges are raised in email (or verbally), tracked inconsistently, and resolved through bilateral conversation. The median time from challenge initiation to resolution and incorporation into POR is 4 to 7 business days. In a cycle that may have fewer than 10 business days total, this is a structural bottleneck.

**0 replayable agent actions.** When a forecast is questioned after the fact — by a plant planner, an auditor, or executive leadership — there is no mechanism to replay or explain the sequence of decisions that produced it. This is increasingly untenable under AI-governance frameworks and creates material audit exposure under SOX, since material estimates feed financial reporting.

### 1.3 Cost of Inaction — Illustrative Estimates

The following numbers are illustrative, constructed to give the investment review a sense of magnitude. They are not audited figures.

**Rework labor cost.** NAMA has approximately 30 analysts. If 38% of their time is rework at a fully-loaded cost of $150K/year per analyst, that is $1.71M/year in direct rework labor. This is a conservative estimate that excludes SME and leadership time.

**Forecast inaccuracy margin leakage.** The relationship between forecast accuracy and margin is indirect but real. A 1% improvement in volume forecast accuracy across a $50B revenue base can shift incentive spend by tens of millions of dollars in either direction (over-incentivizing to cover shortfalls, or leaving upside on the table). Using a very conservative assumption that 10% of the 14% POR drift is actionable and maps to 0.5% revenue impact, the illustrative leakage is $50B × 0.5% = $250M annually. This figure is intentionally conservative and illustrative; the actual figure could be higher or lower depending on where in the POR the drift concentrates.

**Challenge resolution delay cost.** A 4–7 day challenge resolution window in a fast-moving market means that bad forecasts ride for longer than necessary. Using the Q3 Trucks scenario as a reference — where a mid-cycle challenge on full-size truck demand was unresolved for 6 days, during which the team continued planning against an acknowledged-stale number — the cost is primarily in suboptimal allocation decisions that are difficult to reverse once plant schedules are locked.

**Audit and governance risk.** This is not monetized here, but zero replayability of AI-assisted or analyst-assisted decisions creates real regulatory and reputational exposure as GM moves toward AI-assisted forecasting.

---

## 2. Market Requirements

These requirements define what the NAMA Pit Wall platform must do to be viable in this market. They are not feature specifications. Each MR should be treated as an acceptance criterion for the platform as a whole.

**MR-1: Support multi-horizon planning with shared state.**
The platform must support urgent (days), monthly (POR), and strategic (annual) planning horizons simultaneously, with a single authoritative state layer. Analysts must be able to work on a near-term adjustment without contaminating the current monthly POR, and vice versa. Branching, merging, and horizon tagging are implied.

**MR-2: Let each persona work in their preferred surface.**
The platform must expose its capabilities through multiple interfaces: a structured web UI for analysis and review, an Excel/spreadsheet integration for analysts who require cell-level interaction, an API for programmatic access by Ops/IT, and a natural-language interface for leadership and SME personas who cannot or will not use structured UIs. No persona should be forced to adopt an unfamiliar surface as a condition of participation.

**MR-3: Make challenge, dissent, and override structured and fast.**
Any user must be able to raise a challenge against any forecast value in under 30 seconds, with mandatory fields for rationale, supporting data reference, and urgency. Challenges must be tracked, assigned, time-stamped, and escalatable. The platform must target p50 challenge resolution of ≤ 2 business days, measured from submission to POR incorporation.

**MR-4: Expose probabilistic forecasts (P10/P50/P90) everywhere.**
Every forecast surface — charts, exports, API responses, briefing exports — must display P10, P50, and P90 estimates alongside point forecasts. The distribution must be computable on demand and must reflect the current state of open challenges and applied overrides. "Everywhere" means: no path through the system should deliver only a point forecast.

**MR-5: Preserve full replayability and lineage.**
Every state transition — analyst edit, SME override, model-generated suggestion, challenge submission, challenge resolution, POR lock — must be logged with actor identity, timestamp, rationale (if provided), and the before/after value. The platform must be able to reconstruct any prior POR state from this log. Replay must be available to authorized users and exportable for audit.

**MR-6: Honor decision-rights at the API layer.**
The platform's permission model must enforce business decision-rights, not just application roles. Specifically: an SME can override within their segment but not outside it; an analyst can propose but not unilaterally lock; a leader can lock but must acknowledge open challenges first. These rules must be enforced in the API layer, not just the UI, so that programmatic integrations cannot bypass them.

**MR-7: Surface SLA ≤ 2.4 seconds.**
Any user-facing operation — loading a forecast view, submitting a challenge, running a scenario, generating a narrative summary — must return a response or a progress indicator within 2.4 seconds at p95. This is not an aspirational target; it is a viability threshold. Analysts who encounter a 5-second spinner will revert to Excel.

**MR-8: Cost target ≤ $50K/month at v3.0 run-rate.**
Total platform operating cost — LLM compute, Databricks compute, storage, monitoring, and engineering ops — must be achievable at ≤ $50K/month at the v3.0 run-rate (approximately 80 seats, full feature set, steady-state usage). This translates to approximately $625/seat/year. Per-seat costs must be modeled by persona, since LLM-heavy workflows (analyst narrative generation, SME challenge synthesis) cost more than ops/dashboard workflows.

**MR-9: Compatible with GM IT security and governance standards.**
The platform must operate within GM's approved cloud infrastructure (Azure-primary). All data must remain within GM's data perimeter. LLM inference must use approved model providers with data-residency guarantees. The platform must pass GM IT security review before production deployment and must not require exceptions to GM's standard data classification policy.

**MR-10: Phased rollout with per-feature kill-switch.**
No feature — including AI-generated forecast suggestions, automated challenge routing, and probabilistic overlays — may be deployed to production without a configuration flag that allows it to be disabled without a code deploy. The pilot cohort (MR-10a) must be operable on a strict feature subset. This is not optional; it is the mechanism that makes the pilot reversible and gives the champion and sponsor the ability to manage organizational change at their own pace.

**MR-11: Native integration with Databricks and Unity Catalog.**
The planning fabric for NAMA is Databricks with Unity Catalog for data governance. The platform must read from and write to Unity Catalog as its primary data layer. It must not introduce a parallel data store that diverges from the catalog. Forecast outputs, challenge logs, POR snapshots, and lineage records must all be materialized as catalog-governed tables. The platform must support Databricks-native compute for model inference where applicable.

**MR-12: Audit-ready for SOX and AI-governance review.**
The platform must produce audit artifacts sufficient to satisfy a SOX Type II review of the financial forecasting process. Specifically: complete change logs (MR-5), role-based access controls (MR-6), data lineage to source systems, and documentation of any AI-generated inputs to the forecast. As GM's AI-governance framework matures, the platform must be able to demonstrate that AI suggestions were reviewed by a human before incorporation into the locked POR.

---

## 3. Competitive Analysis

The relevant competitive set for NAMA Pit Wall is not the commercial SaaS market — it is the set of tools and practices that would otherwise absorb the budget and organizational energy that Pit Wall is requesting. The honest framing is: what does each alternative actually deliver for NAMA, and where does it fail?

| Dimension | Status Quo (Excel + Email) | Anaplan / Oracle EPM / SAP IBP | o9 Solutions / Kinaxis | AI-Native Planning (emerging) | NAMA Pit Wall |
|---|---|---|---|---|---|
| **Multi-horizon support** | Manual; risky | Strong | Strong | Variable | Designed-in (MR-1) |
| **Persona surface flexibility** | High (Excel is universal) | Medium (UI-primary) | Medium | Low-medium | Designed-in (MR-2) |
| **Structured challenge workflow** | None | Partial (workflow modules) | Partial | Variable | First-class (MR-3) |
| **Probabilistic forecasts** | Manual; rare | Available but complex to configure | Available | Often native | Designed-in (MR-4) |
| **Full lineage/replayability** | None | Partial (audit log) | Partial | Variable | Designed-in (MR-5) |
| **Decision-rights enforcement** | None | Strong (mature access model) | Strong | Variable | Designed-in (MR-6) |
| **Surface SLA** | Instant (local) | Slow (3-8s typical) | Moderate | Variable | Targeted ≤ 2.4s (MR-7) |
| **GM IT compatibility** | Fully compatible | Requires negotiation | Requires negotiation | Requires negotiation | Designed-in (MR-9) |
| **Databricks/UC integration** | None | Via ETL connectors | Via ETL connectors | Variable | Native (MR-11) |
| **SOX audit readiness** | Inadequate | Strong | Strong | Emerging | Designed-in (MR-12) |
| **Cost at 80 seats** | Near-zero direct | $500K–$2M/year license | $500K–$1.5M/year license | $200K–$800K/year | Target $600K/year |

**Status quo (Excel + Email + ad-hoc Power BI).** The status quo's primary strength is that it requires no adoption curve — analysts already know how to use it. It is also infinitely flexible and costs almost nothing in direct licensing. Its weaknesses are precisely the pain points quantified in Section 1.2: no shared state, no structured challenge workflow, no lineage, no probabilistic output. Power BI mitigates the visualization gap but does not address the upstream data consistency problem.

**Anaplan / Oracle EPM / SAP IBP.** These are mature, enterprise-grade planning suites with strong capabilities in multi-entity planning, audit logging, and access control. They are well-suited to large, relatively stable planning processes. Their weaknesses for NAMA are: (1) they are designed for general-purpose planning, not automotive demand forecasting specifically; (2) configuration and implementation costs are high, typically $1–3M for a deployment of NAMA's complexity; (3) they do not natively integrate with Databricks/Unity Catalog and require ETL connectors that introduce latency and data-copy risk; (4) their AI capabilities are bolt-on rather than architectural; and (5) their surface flexibility is limited — analysts who want to work in Excel-like interfaces face friction.

**o9 Solutions / Kinaxis.** These are next-generation planning suites that have invested more heavily in visualization, scenario modeling, and supply chain integration. Kinaxis in particular has strong automotive references. Their weaknesses for NAMA are similar to the legacy suite set but with better UX: still not native to Databricks, still require significant implementation investment, and their AI-native story is not yet fully realized. They are strong competitors if NAMA's requirements were purely commercial — but as an internal platform, build costs are offset by the absence of license fees, and the ability to instrument the platform for NAMA-specific workflows (e.g., the Q3 Trucks challenge scenario) is a meaningful advantage.

**Emerging AI-native planning tools.** A category of newer entrants (commercial and open-source) is beginning to offer LLM-native planning workflows: natural-language forecast interrogation, AI-generated scenario synthesis, automated anomaly flagging. These tools are moving quickly and represent a real competitive threat to any internal build. Their current weaknesses are: data-residency guarantees are not yet enterprise-grade for GM's requirements; they are not Databricks-native; their audit trail capabilities are immature; and their access control models are not sophisticated enough for NAMA's decision-rights requirements. The risk that a sufficiently mature AI-native commercial tool renders Pit Wall redundant is real and is addressed in Section 8.

---

## 4. Buyer and User Analysis

### 4.1 Economic Buyer

The economic buyer is the NAMA executive team, with the CFO function as the ultimate budget authority. The investment review framing is: does Pit Wall reduce the cost of producing the POR (labor efficiency), reduce the cost of forecast error (margin protection), and reduce governance risk (audit exposure)? All three must be addressed. The CFO function will be particularly attentive to the cost model (Section 6) and the SOX/AI-governance requirements (MR-12).

### 4.2 Champion

Ramzi Abdelmoula holds the champion role. The champion's job is to maintain organizational momentum through the pilot, escalate blockers to the economic buyer, and translate analyst feedback into platform prioritization. A champion who is not an active user of the platform has limited credibility with the analyst community; Ramzi should be positioned as a participant in the pilot cohort, not only a sponsor of it.

### 4.3 Implementer

Bob Rapp and Mansoor Alghooneh lead the implementation function. Their concerns are practical: GM IT security review, Databricks integration, pipeline reliability, and SLA monitoring. They are the primary audience for MR-7 through MR-12. Implementation success depends on their ability to operate the platform without a standing dependency on the Pit Wall engineering team — documentation, runbooks, and observability tooling are not optional.

### 4.4 End Users by Persona

| Persona | Primary Need | Success Condition | Adoption Risk |
|---|---|---|---|
| **Demand Analyst** | Faster, less-rework forecast production | Rework time < 15% of workflow | High — Excel proficiency is an identity |
| **SME / Market Specialist** | Fast, credible way to challenge without email overhead | Challenge resolved in ≤ 2 days | Medium — email is familiar |
| **Ops / IT** | Reliable pipelines, observable SLAs, no on-call toil | Zero unplanned outages in pilot quarter | Low — they want better tooling |
| **Leadership** | Crisp, on-demand forecast briefings without manual prep | Briefing auto-generated before every review | Low — they want less manual work |
| **GovOps / Audit** | Complete, exportable audit trail | Audit artifact generated in < 1 hour | Low — current state is manual |

### 4.5 Saboteur Risks

This section is intentionally honest. Any platform that eliminates shadow spreadsheets and manual override workflows redistributes power. Analysts who have built personal influence through being the keeper of a key workbook may resist a platform that makes that workbook redundant. SMEs who prefer informal challenge resolution (bilateral conversation with a trusted analyst) may view the structured challenge workflow as a bureaucratic imposition. These are not bad-faith actors — they are people rationally protecting working arrangements that have served them. The mitigation is not to dismiss these concerns but to (a) involve potential saboteurs in the pilot cohort design, (b) make their specific workflows demonstrably faster in the platform than outside it, and (c) ensure that the champion actively manages the narrative that Pit Wall is a capability upgrade, not a surveillance or control tool.

---

## 5. Market Sizing

### 5.1 Internal Addressable Surface

The immediate addressable market is the NAMA forecasting organization and its direct interface functions.

| Segment | Headcount (est.) | Seat Type | Notes |
|---|---|---|---|
| Demand Analysts | 30 | Full / LLM-heavy | Core workflow users |
| SMEs / Market Specialists | 20 | Standard | Challenge and review |
| Leadership | 10 | Read + Approve | Briefing and lock workflow |
| Ops / IT | 15 | Technical | Pipeline, monitoring |
| GovOps / Audit | 5 | Audit | Compliance exports |
| **Total NAMA** | **80** | | |

At a target cost of $200–$400 per seat per month (see Section 6), the internal addressable cost base is $16K–$32K/month, or $192K–$384K/year. This is the "floor" of Pit Wall's market relevance.

### 5.2 Adjacent Expansion

If the NAMA pilot succeeds, the platform architecture is reusable for GM's European and China market organizations, which run analogous POR processes with analogous pain points. A conservative estimate of adjacent seats:

| Region | Est. Seats | Dependency |
|---|---|---|
| GM Europe | 100 | NAMA success + architecture generalization |
| GM China JV | 80 | Regulatory and data-residency review required |
| Global ops (supply chain, finance) | 70 | Platform API maturity |
| **Adjacent total** | **250** | |

Combined with NAMA's 80 seats, the global addressable surface is approximately 330 seats. At $300/seat/month (midpoint), this represents $1.19M/month or $14.3M/year in operating cost that would otherwise be absorbed by legacy tools or manual labor.

### 5.3 Value Density by Segment

Not all seats deliver equal value. The highest value concentration is in the 30 Demand Analyst seats, where the 38% rework reduction and POR accuracy improvement are directly realized. A rough illustrative attribution:

- 30 analyst seats × 38% rework reduction × $150K/year loaded cost = $1.71M/year labor value
- Forecast accuracy improvement: illustrative $50M–$250M/year margin protection (see Section 1.3)
- Audit risk reduction: not quantified, but material

The platform's investment case does not depend on realizing the full margin protection figure. Even if only the labor efficiency case holds, the ROI is strongly positive at the proposed cost structure.

---

## 6. Pricing and Cost Model

### 6.1 Internal Chargeback Model

NAMA Pit Wall will operate under an internal chargeback model: platform costs are allocated to consuming business units based on seat count and usage tier. This is the standard GM IT chargeback framework and ensures that the platform's costs are visible to the economic buyer and do not disappear into a shared IT overhead pool.

### 6.2 Cost Categories

| Category | Est. Monthly Cost (v3.0, 80 seats) | Notes |
|---|---|---|
| LLM compute (inference) | $18,000 | Analyst narrative generation, challenge synthesis, scenario Q&A — highest per-seat cost for analyst tier |
| Databricks compute | $12,000 | Pipeline runs, model training/refresh, catalog queries |
| Storage (Delta Lake, audit logs) | $3,000 | Audit logs are append-only and grow linearly |
| Engineering ops (on-call, incident response) | $8,000 | 0.5 FTE equivalent; scales with incident rate |
| Monitoring and observability | $2,000 | Datadog or equivalent |
| Miscellaneous (CDN, auth, CI/CD) | $1,500 | |
| **Total** | **$44,500** | Within MR-8 target of $50K/month |

### 6.3 Per-Seat Cost by Persona

| Persona | Monthly Cost/Seat | Driver |
|---|---|---|
| Demand Analyst | $380 | LLM-heavy: narrative generation, anomaly explanation, scenario Q&A |
| SME / Market Specialist | $280 | Moderate LLM: challenge synthesis, briefing reads |
| Ops / IT | $120 | Low LLM: pipeline monitoring, technical dashboards |
| Leadership | $220 | Moderate LLM: briefing generation, summary reads |
| GovOps / Audit | $150 | Low LLM: audit export, compliance dashboard |
| **Blended average** | **~$256** | At 80-seat mix above |

The blended average of $256/seat/month is within the illustrative $200–$400 target range. Analyst-tier costs are higher because they interact with LLM-powered features (forecast narrative generation, challenge drafting assistance, scenario interrogation) far more frequently than other personas.

### 6.4 Cost Sensitivity

LLM compute is the highest-volatility cost category. A shift from current-generation models to next-generation models could increase or decrease per-token costs by 30–50%. The platform architecture must support model switching without application changes (MR-9 implies model provider flexibility within GM's approved set). Cost monitoring must be persona-tiered so that anomalous usage is visible before it blows the monthly budget.

---

## 7. Go-to-Market for an Internal Platform

Internal platform go-to-market is different from commercial SaaS in one critical way: the product cannot walk away from a bad customer. If NAMA analysts reject Pit Wall, the platform team still has to work in the same organization. This creates both a higher bar for quality and a higher bar for political navigation.

### 7.1 Pilot Cohort — Q3 2026

The pilot cohort will consist of 10 demand analysts and 4 SMEs, selected by the champion to represent a cross-section of experience levels and nameplate coverage. The pilot will operate for one full POR cycle (approximately 4 weeks) using Pit Wall as the primary forecasting surface, with Excel available as fallback. The pilot scope will be limited to a defined set of features (per MR-10: phased rollout with kill-switch), specifically:

- Core forecast view and edit (MR-1, MR-2)
- Challenge submission and tracking (MR-3)
- P10/P50/P90 display (MR-4)
- Lineage view (read-only) (MR-5)

Features not included in the pilot: AI-generated narrative summaries, automated scenario generation, leadership briefing export. These require additional LLM cost validation and organizational readiness that should not be assumed at pilot launch.

### 7.2 Champion Program

The champion (Ramzi Abdelmoula) should be equipped with:
- Weekly status briefing from the platform team, 30 minutes, covering adoption metrics, blocking issues, and upcoming releases
- Direct escalation path to the economic buyer for issues that require executive intervention
- A pre-scripted narrative for internal communication that positions Pit Wall as a capability investment, not a process mandate

### 7.3 Internal Evangelism and Training

Training must be embedded in workflow, not classroom-style. Each analyst in the pilot cohort should receive a 90-minute onboarding session covering only the features they will use in the pilot. A Slack channel (or Teams equivalent) with direct access to the platform engineering team should be the primary support channel during the pilot. User feedback must be collected weekly through a structured 5-question survey, and feedback should be visibly incorporated into the platform during the pilot — analysts who see their feedback acted on in real-time become advocates.

A "roadshow" for leadership and SMEs — 30-minute demonstration of the challenge workflow and P10/P50/P90 view — should be scheduled in the first two weeks of the pilot to build upstream and downstream awareness before the pilot cohort goes live.

### 7.4 Success Metric Review Cadence

The following metrics will be reviewed with the sponsor on a defined cadence:

| Metric | Target | Review Cadence |
|---|---|---|
| Pilot DAU (daily active users) | ≥ 80% of cohort on workdays | Weekly |
| Challenge resolution time (p50) | ≤ 3 days (pilot), ≤ 2 days (v1.0) | Per POR cycle |
| Rework time self-reported | ≤ 25% of workflow (pilot), ≤ 15% (v1.0) | Monthly survey |
| SLA compliance (p95 ≤ 2.4s) | ≥ 99% of operations | Weekly |
| NPS (analyst cohort) | ≥ +20 by end of pilot | End of pilot |
| Sponsor review | Qualitative go/no-go | End of pilot |

A formal go/no-go decision for v1.0 full rollout will be made at the end of the pilot quarter based on these metrics. The go/no-go is a real decision — the platform team must be prepared to hear "no" and respond with a revised plan rather than lobbying for a continuation.

---

## 8. Risks and Mitigations

### Risk 1: Analyst Adoption — Clinging to Excel

**Description.** Excel is deeply embedded in analyst identity and workflow. A platform that requires analysts to change how they work will face resistance, even if it is objectively better. The risk is a pilot where analysts participate nominally but continue doing their real work in Excel and submit outputs to Pit Wall at the end.

**Mitigation.** Design the Excel integration (MR-2) first, not last. If analysts can interact with Pit Wall through an Excel add-in that syncs to the shared state layer, they are not being asked to abandon their tool — they are being offered a version of their tool that no longer requires manual reconciliation. The pilot cohort selection should include at least two "Excel power users" who can become advocates if the platform earns their trust.

### Risk 2: IT Security and SOX Gating

**Description.** GM IT security review for a new internal platform can take 3–6 months, and SOX-related control validation can take another 1–2 quarters. If these reviews are initiated late, the Q3 2026 pilot date is at risk.

**Mitigation.** IT security review must be initiated no later than Q1 2026, in parallel with platform development. The implementer team (Bob Rapp, Mansoor Alghooneh) should own the IT security engagement, with the platform engineering team providing architecture documentation on demand. SOX control design should be treated as a v1.0 requirement, not a v2.0 nice-to-have.

### Risk 3: LLM Cost Volatility

**Description.** LLM inference costs are volatile. Prices have generally trended down, but usage can spike unexpectedly (a complex mid-cycle challenge that triggers many LLM calls, for example), and new model releases may change the cost-capability frontier in either direction.

**Mitigation.** Implement per-persona, per-feature cost budgets with alerting at 80% of budget. Architect the LLM layer to support model switching (e.g., from a frontier model to a cheaper distilled model for lower-stakes operations like challenge categorization). Monthly cost review is part of the success metric cadence.

### Risk 4: Microsoft Copilot Eats the Category

**Description.** Microsoft's Copilot for M365 and Copilot Studio are moving rapidly into structured workflow automation. If Microsoft releases a sufficiently capable "Copilot for Excel/Teams + Databricks" integration, it could address several of NAMA's pain points without requiring a custom platform. GM's existing M365 investment makes this a real alternative.

**Mitigation.** Monitor the Microsoft roadmap quarterly. Pit Wall's defensible moat is not "AI in Excel" — it is the NAMA-specific workflow: multi-horizon branching, structured challenge workflow, probabilistic output, and Unity Catalog-native lineage. A generic Copilot integration cannot replicate these without significant custom configuration that approaches the cost of building Pit Wall. The risk should be reviewed at the end of the pilot: if Microsoft's capabilities have materially converged, the v1.0 investment decision should be revisited.

### Risk 5: Sponsor Turnover

**Description.** Internal platforms are vulnerable to sponsor turnover. If Ramzi Abdelmoula's role changes before v1.0 is fully adopted, the platform loses its organizational champion and risks being defunded or deprioritized.

**Mitigation.** The champion program (Section 7.2) must build a coalition, not a single-threaded dependency. By the end of the pilot, at least 3 people in addition to Ramzi should be on record as advocates — ideally including one senior analyst and one member of the leadership persona group. The success metrics (Section 7.4) should be published to the economic buyer directly, so the platform's value is visible independently of the champion.

### Risk 6: Plant Planning Integration Complexity

**Description.** NAMA's forecast is consumed by plant planning, supply chain, and dealer operations. If Pit Wall becomes the system of record for POR but does not integrate cleanly with the downstream systems that consume it, it creates a new data consistency problem rather than solving the existing one.

**Mitigation.** Define the POR export specification before the pilot begins. Plant planning's data format and delivery cadence requirements must be documented and honored. The Unity Catalog integration (MR-11) should include a "POR publish" table that is the authoritative downstream feed, replacing whatever ad-hoc exports currently exist. Integration testing with a plant planning counterpart should be part of the pilot scope.

### Risk 7: Over-Engineering for the Pilot

**Description.** Platform teams building internal tools frequently over-engineer for scale before proving value. A Pit Wall that takes 18 months to build before the first analyst touches it is a failure mode, even if the eventual product is excellent.

**Mitigation.** The pilot scope (Section 7.1) is deliberately narrow. The platform team must resist the temptation to build features not included in the pilot before the pilot succeeds. A strict feature freeze for the pilot period — with a visible, prioritized backlog for v1.0 — is the structural mitigation.

### Risk 8: Data Quality in Unity Catalog

**Description.** Pit Wall is only as good as the data it reads. If the upstream data in Unity Catalog is inconsistent, late, or incomplete, the platform will surface bad forecasts with high confidence — which is worse than surfacing uncertain forecasts with low confidence.

**Mitigation.** Data quality validation must be a first-class feature of the Ops/IT persona workflow (MR-2, MR-11). Data freshness, completeness, and consistency checks should be visible on the platform's operations dashboard before the forecast surface renders. The platform should propagate data quality warnings to analyst users when source data is flagged, rather than silently presenting potentially stale numbers.

---

*Document ends.*

*Prepared for GM NAMA Pit Wall investment review. All illustrative figures should be replaced with validated estimates prior to final executive presentation.*
