# Export to OpenAI Codex

OpenAI Codex (the agentic coding tool, not the legacy completion model) handles structured repos well. This package is built to be Codex-ready.

## Step 1 — Open in Codex

```bash
cd nama-pit-wall-pkg
codex
```

Or open the folder in your Codex-enabled editor (e.g., Cursor with Codex backend).

## Step 2 — Initial onboarding prompt

```
Please familiarize yourself with this codebase. Specifically read:

1. README.md
2. ARCHITECTURE.md (high-level technical)
3. PRD.md (full requirements, focus on § 5 functional requirements FR-1 through FR-18)
4. DESIGN_SPEC.md (brand and component patterns)
5. docs/adr/*.md (5 architecture decision records)
6. src/types/index.ts (type system)
7. docs/api/openapi.yaml (Layer C API contract)
8. docs/schema/schema.sql (Layer A data model)

Once read, give me a 5-bullet summary of:
1. The project's operating principle
2. The 4-layer architecture
3. The 5 personas
4. The current scaffold state (what's implemented, what's mocked)
5. The next 3 milestones from ROADMAP.md

Then I'll send you a task.
```

## Step 3 — Task templates

### Task A — Add real backend

```
Build a Node + Fastify backend at `src-backend/` that implements the Layer C
Access API per docs/api/openapi.yaml. Use Postgres with the schema at
docs/schema/schema.sql.

Requirements:
- TypeScript with strict mode
- Generate types from the OpenAPI spec
- JWT auth (jose library) with scope-based authorization
- HIBT ledger writes on every mutating endpoint
- All endpoints return within 200ms p95 (excluding LLM calls)
- Pino logging
- Health endpoint for k8s readiness probe

Wire the existing frontend's mock data calls (in src/data/*.ts) to real
HTTP calls to this backend. Keep the mock files as fallback for offline dev.

Generate a docker-compose.yml that brings up Postgres + the backend +
the frontend with a single command.

Write integration tests for each endpoint.
```

### Task B — Implement Second-Opinion Agent

```
Implement the Second-Opinion Agent service as specified in:
- PRD.md § 5 FR-16
- ROADMAP.md v3.0 section
- The locked decisions and design doc referenced in ARCHITECTURE.md

Service: `src-backend/services/second-opinion-svc/` (FastAPI Python OR Fastify TS - your call, pick the one that better fits the existing stack).

Components needed:
1. Handler (HTTP entry)
2. Async runner (orchestrator)
3. Budget enforcer (per-seat $4/day)
4. Prompt pack loader (cache)
5. LLM client (Litellm wrapper)
6. MDS calculator (formula in design doc)
7. SME router (factor → category → on-call rota lookup)
8. HIBT writer

Honor:
- Service failure NEVER blocks primary forecasting path
- MDS ≥ 0.3 raises challenge
- ≥98% replay determinism
- Different LLM provider than primary
- p95 latency ≤ 90s

Write the eval harness (5 suites: golden_set, adversarial, calibration,
perf, replay) per the design doc. Wire it into CI as a GitHub Actions
workflow. Block PR merge on golden_set or adversarial failures.
```

### Task C — Refactor styling to a CSS-in-JS solution

```
Currently src/components/*.tsx uses inline styles + token CSS variables.
I want to refactor to a maintainable CSS solution.

Pick ONE of these and apply consistently:
- vanilla-extract (type-safe, zero-runtime, file colocation)
- CSS Modules (simple, well-supported)
- StyleX (Meta's solution, growing)

Migrate src/components/PitWall.tsx, SeatPicker.tsx, TelemetryStrip.tsx,
SurfaceRing.tsx, ActivityFeed.tsx, RaceFlow.tsx, AgentStudio.tsx,
HandoffToast.tsx.

Keep the design tokens as CSS variables; just move component-specific
styles out of inline `style={{}}` props.

Don't change visual behavior. Add a visual regression test (Chromatic
or Percy) snapshot to prove parity.
```

## Step 4 — How Codex does its best work

Codex works best with:

1. **Hierarchical context.** Point it at README → ARCHITECTURE → specific docs/adr/ before any task. The package is organized for this.
2. **Pre-defined contracts.** OpenAPI spec + Postgres schema mean Codex doesn't have to invent shapes.
3. **Explicit "honor X" constraints.** The 6 locked decisions from the Second-Opinion design doc are good examples — they're guardrails Codex respects.
4. **Test-first when possible.** "Write tests as you implement" produces cleaner output than "implement, then test."

## Step 5 — Recommended `.codexrc` (or similar)

Drop at repo root:

```json
{
  "primary_context": [
    "README.md",
    "ARCHITECTURE.md",
    "PRD.md",
    "docs/adr/*.md"
  ],
  "code_style": {
    "language_primary": "typescript",
    "strict_mode": true,
    "test_framework": "vitest",
    "package_manager": "npm"
  },
  "guardrails": [
    "Honor the 4 operating principles in ARCHITECTURE.md § 1",
    "Honor the 5 ADRs in docs/adr/",
    "Honor the operating principle: agents do toil, humans do judgment",
    "Service failure NEVER blocks primary forecasting path",
    "All persona-surface writes go through Layer C API — no direct Layer A writes",
    "HIBT entries written within 5s p95 of every mutating action",
    "Decision-rights enforced at API edge, not at UI"
  ]
}
```

## Step 6 — Specific patterns Codex follows well in this codebase

- **Component name** ↔ **file name** ↔ **default export**. Codex propagates this.
- **Types in src/types/index.ts**. Codex extends here when new entities are added.
- **Mock data in src/data/*.ts** by domain (mockForecast, mockAgents, mockActivity). New domains get new files.
- **CSS tokens in tokens.css**. No new colors get hardcoded; they go in tokens.
- **One feature, one ADR**. When Codex makes an architectural call, ask for an ADR.

## What to do at session end

```
Before we wrap, please:
1. Update README.md if new top-level dirs were added
2. Update ARCHITECTURE.md if a new service was introduced
3. Add a HIBT entry to docs/HIBT_LOG.md noting what was built
4. Update the relevant ADR if a decision was made or revisited
5. Run typecheck + lint + tests; report results
```
